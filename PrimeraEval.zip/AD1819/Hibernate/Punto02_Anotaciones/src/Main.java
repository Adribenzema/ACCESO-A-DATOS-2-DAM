
import entidades.Contacto;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    private static ContactosDAO cdao;
    private static List<Contacto> contactos = new ArrayList();
    private static List<Long> ids = new ArrayList<>();

    public static void main(String[] args) {

        cdao = new ContactosDAO();

        crearUsuarios();
        actualizarContacto();
        obtenerTodosUsuarios();
        obtenerContacto();
        eliminarContacto();

        cdao.desconectarHibernate();
    }   

    //Si existen, sobrescribe las filas
    private static void crearUsuarios() {
        contactos = (Arrays.asList(
                new Contacto("Ana", "ana@gmail.com", "666777888"),
                new Contacto("Jose", "jose@gmail.com", "666777888"),
                new Contacto("Andrea", "andrea@gmail.com", "666777888"),
                new Contacto("Santiago", "santiago@gmail.com", "666777888")
        ));
        for (Contacto contacto : contactos) {
                cdao.crearContacto(contacto);
            }
        comprobarExistenciaUsuarios();
        if (ids.isEmpty()) {
            System.out.println("No se han podido crear los contactos");
        } else {
            System.out.println("Contactos creados: " + ids.size());
            for (Contacto contacto : contactos) {
                System.out.println(contacto);
            }
        }
    }

    private static void obtenerTodosUsuarios() {
        if (comprobarExistenciaUsuarios()) {
            System.out.println("Contactos recuperados: " + contactos.size());
            for (Contacto contacto : contactos) {
                System.out.println(contacto.toString());
            }
        } else {
            System.out.println("No hay contactos que mostrar");
        }
    }

    private static void actualizarContacto() {
        if (comprobarExistenciaUsuarios()) {
            try {
                obtenerTodosUsuarios();
                Contacto c = contactos.get(1);
                c.setNombre("Virginia");
                c.setEmail("virginia@yahoo.com");
                cdao.modificarContacto(c);
                comprobarExistenciaUsuarios();
                System.out.println(System.lineSeparator() + "LISTA ACTUALIZADA" + System.lineSeparator());
                for (Contacto contacto : contactos) {
                    System.out.println(contacto.toString());
                }
            } catch (IndexOutOfBoundsException ioobe) {
                System.out.println("El índice de búsqueda debe estar comprendido entre  0 y " + (contactos.size() - 1));
            }
        } else {
            System.out.println("No hay contactos que mostrar");
        }
    }

    private static void obtenerContacto() {
        long idBusqueda = 2;
        if (comprobarExistenciaUsuarios()) {
            Contacto contacto = cdao.buscarContacto(idBusqueda);
            if (contacto != null) {
                System.out.println("Contacto localizado para el id " + idBusqueda + ":" + System.lineSeparator() + contacto.toString());
            } else {
                System.out.println("No existe ningún Contacto el ID " + idBusqueda);
            }
        } else {
            System.out.println("No hay contactos que mostrar");
        }
    }
    
    private static void eliminarContacto() {
        if (comprobarExistenciaUsuarios()) {
            try {
                obtenerTodosUsuarios();
                Contacto c = contactos.get(1);
                cdao.eliminarContacto(c);
                comprobarExistenciaUsuarios();
                System.out.println(System.lineSeparator() + "LISTA ACTUALIZADA" + System.lineSeparator());
                for (Contacto contacto : contactos) {
                    System.out.println(contacto.toString());
                }
            } catch (IndexOutOfBoundsException ioobe) {
                System.out.println("El índice de búsqueda debe estar comprendido entre  0 y " + (contactos.size() - 1));
            }
        } else {
            System.out.println("No hay contactos que mostrar");
        }
    }

    private static boolean comprobarExistenciaUsuarios() {
        contactos = cdao.obtenerListaContactos();
        ids.clear();
        for (Contacto contacto : contactos) {
            ids.add(contacto.getId());
        }
        return !contactos.isEmpty();
    }

}
