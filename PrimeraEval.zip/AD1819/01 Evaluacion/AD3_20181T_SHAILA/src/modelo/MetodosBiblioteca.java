package modelo;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamSource;
import jaxb.bibliotecaBinding.Biblioteca;
import jaxb.bibliotecaBinding.PrestamoType;
import jaxb.bibliotecaBinding.SocioType;
import modelo.ExcepcionesBiblioteca.FechaIncorrectaException;
import modelo.ExcepcionesBiblioteca.MarshalExcepcion;
import modelo.ExcepcionesBiblioteca.NoExisteSocioExcepcion;
import modelo.ExcepcionesBiblioteca.UnmarshalExcepcion;

/**
 *
 * @author Shaila
 */
public class MetodosBiblioteca implements InterfaceBiblioteca {

    private JAXBContext jaxbCtx = null;

    public MetodosBiblioteca(String packageName) {
        try {
            jaxbCtx = JAXBContext.newInstance(packageName);
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Método unmarshalizador. Obtenemos un objeto de la etiqueta padre del XML,
     * obteniendo todos sus hijos (su contenido).
     *
     * @param documentoXML
     * @return
     * @throws modelo.ExcepcionesBiblioteca.UnmarshalExcepcion
     */
    @Override
    public JAXBElement unMarshall(File documentoXML) throws UnmarshalExcepcion {
        JAXBElement jaxbElement = null;
        try {
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = unmarshaller.unmarshal(new StreamSource(new java.io.File(documentoXML.toString())), Biblioteca.class);

        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }

        return jaxbElement;
    }

    /**
     * Método marshalizador. Genera un XML a partir del JAXB
     *
     * @param jaxbElement
     * @param ficheroSalida donde volcamos los datos
     * @return true si esta todo correcto; false si hay algun problema
     * @throws jaxb_albaran.Excepciones.MarshalExcepcion
     */
    public boolean marshall(JAXBElement jaxbElement, File ficheroSalida) throws MarshalExcepcion {

        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.bibliotecaBinding");
            Marshaller marshaller;
            marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);//Controla si hay que formatear el XML para leerlo mejor      
            marshaller.marshal(jaxbElement, ficheroSalida);//Muestra el contenido del objeto en salida estandar
            return true;
        } catch (javax.xml.bind.JAXBException ex) {

            return false;
        }
    }

    /**
     * Método para generar un PrestamoType.
     *
     * @param ISBN
     * @param titulo
     * @param codigoSocio
     * @param nombreSocio
     * @param apellidoSocio
     * @param fechaDevolucion
     * @return PrestamoType
     */
    public PrestamoType crearPrestamoType(String ISBN, String titulo, String codigoSocio, String nombreSocio, String apellidoSocio, int dia, int mes, int anio) throws FechaIncorrectaException {

        PrestamoType prestamoType = new PrestamoType();
        prestamoType.setISBN(ISBN);
        prestamoType.setTitulo(titulo);
        prestamoType.setCodigoSocio(codigoSocio);
        prestamoType.setNombreSocio(nombreSocio);
        prestamoType.setApellidoSocio(apellidoSocio);

        try {
            XMLGregorianCalendar fecha = DatatypeFactory.newInstance().newXMLGregorianCalendar();

            fecha.setDay(dia);
            fecha.setMonth(mes);
            fecha.setYear(anio);
//Comprobamos que la fecha sea correcta
            if ((dia < 1 || dia > 31) || (mes < 1 || mes > 12) || (anio < 1890 || anio > 2018)) {
                throw new ExcepcionesBiblioteca.FechaIncorrectaException("La fecha " + dia + "-" + mes + "-" + anio + " es incorrecta");
            }
            prestamoType.setFechaDevolucion(fecha);
        } catch (DatatypeConfigurationException ex) {
            ex.printStackTrace();
        }

        return prestamoType;

    }

    /**
     * Método para insertar un prestamos en la biblioteca.
     *
     * @param prestamoType
     * @return true si esta todo correcto; false si hay algun problema.
     */
    @Override
    public boolean insertarPrestamosEnBiblioteca(PrestamoType prestamoType) {
       
        Biblioteca.Prestamos biblioteca = new Biblioteca.Prestamos();
        List<PrestamoType> listaPrestamos = biblioteca.getPrestamo();
        listaPrestamos.add(prestamoType);

        return true;
    }

    /**
     * Método que da de baja a un socio en la biblioteca si el socio existe y no
     * tiene ningún préstamos en su lista.
     *
     * @param biblioteca
     * @param codigoSocio
     * @return
     * @throws modelo.ExcepcionesBiblioteca.NoExisteSocioExcepcion
     */
    @Override
    public boolean darDeBajaUnSocioEnBiblioteca(Biblioteca biblioteca, String codigoSocio) throws ExcepcionesBiblioteca.NoExisteSocioExcepcion {

        List<SocioType> listaDeSocios = biblioteca.getSocios().getSocio();
        Iterator<SocioType> iterator = listaDeSocios.iterator();
        SocioType socio = new SocioType();

        if (socio.getCodigoSocio() == null || socio.getCodigoSocio().isEmpty()) {
            try {
                throw new ExcepcionesBiblioteca.NoExisteSocioExcepcion(codigoSocio + " no existe el codigo Socio.");
            } catch (NoExisteSocioExcepcion ex) {
                System.out.println(ex.getMessage());
            }
        }
        while (iterator.hasNext()) {
            socio = iterator.next();
            if (socio.getLibrosPrestados().getPrestamo().size() == 0) {
                iterator.remove();
            }
        }

        return true;
    }

    /**
     * Método que genera un Map cuya clave es el código del socio y su value es
     * una lista con los títulos de los libros prestados.
     *
     * @param biblioteca
     * @return
     */
    @Override
    public Map<String, List<String>> generarMapCodigoSocioConListaLibrosPrestados(Biblioteca biblioteca) {
        List<String> listaTitulosLibrosPrestados = new ArrayList<>();
        Map<String, List<String>> informacionSociosYlibrosPrestadosEnBiblioteca = new HashMap<>();
        String codigoSocio, titulo;
        for (int contadorSociosEnBiblioteca = 0; contadorSociosEnBiblioteca < biblioteca.getPrestamos().getPrestamo().size(); contadorSociosEnBiblioteca++) {
            codigoSocio = biblioteca.getPrestamos().getPrestamo().get(contadorSociosEnBiblioteca).
                    getCodigoSocio();
            for (int contadorLibrosPrestadosAsocio = 0; contadorLibrosPrestadosAsocio
                    < biblioteca.getSocios().getSocio().get(contadorSociosEnBiblioteca).
                            getLibrosPrestados().getPrestamo().size(); contadorLibrosPrestadosAsocio++) {
                titulo = biblioteca.getSocios().getSocio().get(contadorSociosEnBiblioteca).
                        getLibrosPrestados().getPrestamo().get(contadorSociosEnBiblioteca).getTitulo();
                listaTitulosLibrosPrestados.add(titulo);

                if (!informacionSociosYlibrosPrestadosEnBiblioteca.containsKey(codigoSocio)) {
                    informacionSociosYlibrosPrestadosEnBiblioteca.put(codigoSocio, listaTitulosLibrosPrestados);
                }
            }
        }

        return informacionSociosYlibrosPrestadosEnBiblioteca;

    }

    /**
     * Método para comprobar la lista de retrasos en la entrega de libros de un
     * socio.
     *
     * @param biblioteca
     * @param dia
     * @param mes
     * @param anio
     * @return Lista con el ISBN de los préstamos.
     * @throws modelo.ExcepcionesBiblioteca.FechaIncorrectaException
     */
    @Override
    public List<String> retrasosSocios(Biblioteca biblioteca, int dia, int mes, int anio) throws FechaIncorrectaException {
        List<String> listaISBN = new ArrayList();
        String fechaDevolucion;
        if ((dia < 1 || dia > 31) || (mes < 1 || mes > 12) || (anio < 1890 || anio > 2018)) {
            throw new ExcepcionesBiblioteca.FechaIncorrectaException("La fecha " + dia + "-" + mes + "-" + anio + " es incorrecta");
        }
        for (int contadorSociosEnBiblioteca = 0; contadorSociosEnBiblioteca < biblioteca.getSocios().getSocio()
                .size(); contadorSociosEnBiblioteca++) {
            for (int contadorPrestamosEnBiblioteca = 0; contadorPrestamosEnBiblioteca < biblioteca.getSocios()
                    .getSocio().get(contadorSociosEnBiblioteca).getLibrosPrestados().getPrestamo().size(); contadorPrestamosEnBiblioteca++) {

                fechaDevolucion = biblioteca.getSocios().getSocio().get(contadorSociosEnBiblioteca).
                        getLibrosPrestados().getPrestamo().get(contadorPrestamosEnBiblioteca).getFechaDevolucion().toString();
                String[] split = fechaDevolucion.split("-");

                int diferenciaDias = Integer.parseInt(split[2]) - dia;
                int diferenciaMes = Integer.parseInt(split[1]) - mes;
                int diferenciaAnio = Integer.parseInt(split[0]) - anio;
                if (diferenciaDias > 1 && diferenciaMes >= 0) {
                    if (diferenciaAnio >= 0) {
                        listaISBN.add(fechaDevolucion);
                    }
                }

            }
        }

        return listaISBN;

    }

}
