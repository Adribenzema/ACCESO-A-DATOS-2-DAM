package modelo;

/**
 *
 * @author Shaila
 */
public class ExcepcionesClientes {

    public static class PisoIncorrecto extends Exception {

        public PisoIncorrecto() {

        }

        public PisoIncorrecto(String msg) {
            super(msg);
        }
    }

    public static class CodigoPostalException extends Exception {

        public CodigoPostalException() {

        }

        public CodigoPostalException(String msg) {
            super(msg);
        }
    }

    public static class NoExisteElProducto extends Exception {

        public NoExisteElProducto() {

        }

        public NoExisteElProducto(String msg) {
            super(msg);
        }
    }

    public static class ErrorFecha extends Exception {

        public ErrorFecha() {

        }

        public ErrorFecha(String msg) {
            super(msg);
        }
    }

    public static class NumeroMaximoDirecciones extends Exception {

        public NumeroMaximoDirecciones() {
        }

        public NumeroMaximoDirecciones(String msg) {
            super(msg);
        }
    }
}
