
import entidades.Contacto;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Shaila
 */
public class ContactosDAO {

    /**
     * Creamos dos atributos, uno llamado "sesion" de tipo
     * "org.hibernate.Session", y otro llamado "tx" de tipo
     * "org.hibernate.Transaction".
     */
    private Session sesion;
    private Transaction tx;

    /**
     * Método que nos ayudará a iniciar una sesión y una transacción en la base
     * de datos. En el método anterior obtenemos una referencia a
     * "SessionFactory" usando nuestra clase de utilidad "HibernateUtil". Una
     * vez que tenemos la "SessionFactory" creamos una conexión a la base de
     * datos e iniciamos una nueva sesión con el método "openSession()". Una vez
     * teniendo la sesión iniciamos una nueva transacción y obtenemos una
     * referencia a ella con "beginTransaction()".
     *
     * @throws HibernateException
     */
    private void iniciaOperacion() throws HibernateException {
        sesion = HibernateUtil.getSessionFactory().openSession();
        tx = sesion.beginTransaction();
    }

    /**
     * Método que nos ayudará a manejar las cosas en caso de que ocurra una
     * excepción. Si esto pasa queremos que la transacción que estamos
     * ejecutando se deshaga y se relance la excepción (o podríamos lanzar una
     * propia).
     *
     * @param he
     * @throws HibernateException
     */
    private void manejaExcepcion(HibernateException he) throws HibernateException {
        tx.rollback();
        throw new HibernateException("Ocurrió un error en la capa de acceso a datos", he);
    }

    /**
     * Método que permite realizar las tareas de persistencia de una entidad
     * "Contacto", (CRUD: guardarla, actualizarla, eliminarla, buscar un entidad
     * "Contacto") y obtener los contactos que existen en la base de datos.
     *
     * Método "save" (de Hibernate) en el objeto de tipo
     * "org.hibernate.Session", generará el "INSERT" apropiado para la entidad
     * que estamos tratando de guardar.
     *
     * @param contacto
     * @return id generado al guardar el "Contacto" para usarlo más adelante en
     * el proceso, o si queremos mostrarle al usuario el identificador del
     * Contacto.
     */
    public long guardaContacto(Contacto contacto) {
        long id = 0;

        try {
            iniciaOperacion();
            id = (Long) sesion.save(contacto);
            tx.commit();
        } catch (HibernateException he) {
            manejaExcepcion(he);
            throw he;
        } finally {
            sesion.close();
        }
        return id;
    }

    /**
     * Método para eliminar un contacto.
     *
     * @param contacto
     * @throws HibernateException
     */
    public void eliminaContacto(Contacto contacto) throws HibernateException {
        try {
            iniciaOperacion();
            sesion.delete(contacto);
            tx.commit();
        } catch (HibernateException he) {
            manejaExcepcion(he);
            throw he;
        } finally {
            sesion.close();
        }
    }

    /**
     * Método para actualizar un "Contacto", método "update" del objeto "sesion"
     * en nuestro método "actualizaContacto".
     *
     * @param contacto
     * @throws HibernateException
     */
    public void actualizaContacto(Contacto contacto) throws HibernateException {
        try {
            iniciaOperacion();
            sesion.update(contacto);
            tx.commit();
        } catch (HibernateException he) {
            manejaExcepcion(he);
            throw he;
        } finally {
            sesion.close();
        }
    }

    /**
     * Método para buscar un contacto a través de su id.
     *
     * La clase "org.hibernate.Session" proporciona dos métodos: "load" y "get".
     * El identificador y tipo de la entidad recuperan la entidad indicada,
     * ("load" lanza una excepción en caso de que la entidad indicada no sea
     * encontrada en la base de datos), ("get" simplemente regresa "null").
     *
     * @param idContacto
     * @return Contacto encontrado a partir de su id.
     * @throws HibernateException
     */
    public Contacto obtenContacto(long idContacto) throws HibernateException {
        Contacto contacto = null;

        try {
            iniciaOperacion();
            contacto = (Contacto) sesion.get(Contacto.class, idContacto);
        } finally {
            sesion.close();
        }
        return contacto;
    }

    /**
     * Método que recupera todos los Contactos que estén guardados en la base de
     * datos. Como en este caso regresaremos una lista de elementos deberemos
     * crear una consulta.
     *
     * @return Lista de Contactos.
     * @throws HibernateException
     */
    public List<Contacto> obtenListaContactos() throws HibernateException {
        List<Contacto> listaContactos = null;

        try {
            iniciaOperacion();
            /**
             * Indicar es de cuál clase queremos recuperar las instancias, por
             * lo que necesitamos la clausula "FROM" y el nombre de la clase.
             */
            listaContactos = sesion.createQuery("from Contacto").list();
        } finally {
            sesion.close();
        }

        return listaContactos;
    }

    /**
     * Método para cerrar la factoria.
     */
    public void cerrarHibernate() {
        HibernateUtil.getSessionFactory().close();

    }

}
