package controlador;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Shaila
 */
public class MySQL01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {

        ControladorPinturas controlador = new ControladorPinturas();

        String usuario = "root";
        String contrasenia = "elentrego1384";

        try {
            controlador.conexion(usuario, contrasenia);
            controlador.retornarTodosPintores(true);
            controlador.insertarPintor(1,"Leonardo Da Vinci", 1575, "Renacentista");
        } catch (SQLException ex) {

            System.err.println("SQLException: " + ex.getMessage());

        }

    }
}
