

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Se hará cargo de inicializar y hacer el acceso al
 * "org.hibernate.SessionFactory" (el objeto encargado de gestionar las sesiones
 * de conexión a la base de datos que configuramos en el archivo
 * "hibernate.cfg.xml") más conveniente.
 *
 * @author Shaila
 */
public class HibernateUtil {

    /**
     * Atributo static de tipo "SessionFactory", así nos aseguraremos de que
     * solo existe una instancia en la aplicación. Además lo declararemos como
     * final para que la referencia no pueda ser cambiada después de que la
     * hayamos asignado.
     */
    private static final SessionFactory sessionFactory;

    /**
     * Bloque de inicialización estático para inicializar esta variable en el
     * momento en el que la clase sea cargada en la JVM.
     *
     * Necesitamos "org.hibernate.cfg.Configuration" que permite a la aplicación
     * especificar las propiedades y documentos de mapeo que se usarán (es aquí
     * donde indicamos todo si no queremos usar un archivo XML o de
     * propiedades). Si usamos el método "configure()" que no recibe parámetros
     * entonces Hibernate busca el archivo "hibernate.cfg.xml" que creamos
     * anteriormente. Una vez que tenemos este objeto, entonces podemos
     * inicializar la instancia de "SessionFactory" con su método
     * "buildSessionFactory()". Además como este proceso puede lanzar
     * "org.hibernate.HibernateException" (que extiende de "RuntimeException")
     * la cachamos y lanzamos como un "ExceptionInInitializarError" (que es lo
     * único que puede lanzarse desde un bloque de inicialización).
     */
    static {
        try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (HibernateException he) {
            System.err.println("Ocurrió un error en la inicialización de la SessionFactory: " + he);
            throw new ExceptionInInitializerError(he);
        }
    }

    /**
     * Modo static llamado "getSessionFactory()" para recuperar la instancia de
     * la "SessionFactory".
     *
     * @return
     */
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}
