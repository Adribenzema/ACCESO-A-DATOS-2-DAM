import entidades.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
    
    private static Session session;

    public static void main(String[] args) {
        
        SessionFactory sessionFactory = HibernateSesion.getSessionFactory();
        session = sessionFactory.openSession();
        
        //crearDatos();
        //borrarDatos(1);
        
        session.close();
        HibernateSesion.cerrarSesion();
    }
    
    private static void crearDatos() {
        Transaction tx =null;
        try {
            tx = session.beginTransaction();
            Estudiante estudiante01 = new Estudiante("Sofía");
            Estudiante estudiante02 = new Estudiante("Manuel");
            Materia materia01 = new Materia("Programación");
            Materia materia02 = new Materia("Acceso a Datos");
            Materia materia03 = new Materia("Bases de datos");
            Materia materia04 = new Materia("Diseño de Interfaces");
            Materia materia05 = new Materia("Empresa");
            //relación
            estudiante01.getMaterias().add(materia01);
            estudiante01.getMaterias().add(materia02);
            estudiante01.getMaterias().add(materia03);
            estudiante02.getMaterias().add(materia04);
            estudiante02.getMaterias().add(materia05);
            //persistencia
            session.save(estudiante01);
            session.save(estudiante02);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        }
    }
    
    private static void borrarDatos(int id) {
            Transaction tx =null;
             try {
            tx = session.beginTransaction();
            Estudiante estudiante = (Estudiante) session.get(Estudiante.class, (long) id);
            session.delete(estudiante);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        }
    }
    
}
