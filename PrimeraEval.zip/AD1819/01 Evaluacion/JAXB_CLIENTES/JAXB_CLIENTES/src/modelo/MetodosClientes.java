/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import excepcionesClientes.ExcepcionesClientes.CaracterInvalidoException;
import excepcionesClientes.ExcepcionesClientes.CodigoPostalExcepcion;
import excepcionesClientes.ExcepcionesClientes.MarshalExcepcion;
import excepcionesClientes.ExcepcionesClientes.NumeroDireccionesExcedidoException;
import excepcionesClientes.ExcepcionesClientes.PisoIncorrectoException;
import excepcionesClientes.ExcepcionesClientes.UnmarshalExcepcion;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.clientes.Clientes;
import jaxb.clientes.Clientes.Cliente;
import jaxb.clientes.TipoDireccion;

/**
 *
 * @author Annie
 */
public class MetodosClientes {

    /**
     * Unmarshalizador
     *
     * @param ficheroEntrada
     * @return un objeto (jaxbElement)
     * @throws excepcionesClientes.Excepciones.UnmarshalExcepcion
     */
    public JAXBElement unMarshalizar(String ficheroEntrada) throws UnmarshalExcepcion {
        try {
            JAXBElement jaxbElement = null;
            javax.xml.bind.JAXBContext jaxbCtx = null;
            jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.clientes");
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();//Creando unmarshalizador
            return ((JAXBElement) unmarshaller.unmarshal(new StreamSource(new File("clientes.xml")), Clientes.class));//Objeto

        } catch (JAXBException ex) {
            throw new UnmarshalExcepcion("Problemas en el binding.");
        } catch (ClassCastException cce) {
            throw new UnmarshalExcepcion("El XML tiene errores o está incompleto.");
        }
    }

    /**
     * Marshalizar
     *
     * @param jaxbElement
     * @param ficheroSalida
     * @return true si todo es correcto, false si ha habido un error
     */
    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws MarshalExcepcion {

        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.clientes");
            Marshaller marshaller;
            marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);//Controla si hay que formatear el XML para leerlo mejor      
            marshaller.marshal(jaxbElement, ficheroSalida);//Muestra el contenido del objeto en salida estandar
            return true;
        } catch (javax.xml.bind.JAXBException ex) {

            return false;
        }
    }

    /**
     * Retorna el numero total de clientes que hay
     *
     * @param clientes
     * @return el tamaño de la lista de clientes
     */
    public int totalClientes(Clientes clientes) {

        List<Clientes.Cliente> listaClientes = clientes.getCliente();
        return listaClientes.size();
    }

    /**
     * Retorna el total de clientes por provicia. Si el codigo postal empieza
     * por los digitos que introduzcamos por parámetro, lo incluirá en la misma
     * provincia
     *
     * @param PrefijoCodigoPostal
     * @return total de clientes de una misma provincia
     */
    public int totalClientesPorProvincia(Clientes clientes, String PrefijoCodigoPostal) {

        int totalClientesDeUnaMismaProvincia = 0;
        List<Clientes.Cliente> listaClientes = clientes.getCliente();

        for (Cliente cliente : listaClientes) {
            List<TipoDireccion> listaDirecciones = cliente.getDireccion();

            for (TipoDireccion direccion : listaDirecciones) {
                if (String.valueOf(direccion.getCp()).startsWith(PrefijoCodigoPostal)) {
                    totalClientesDeUnaMismaProvincia++;
                }
            }
        }
        return totalClientesDeUnaMismaProvincia;
    }

    /**
     * Borra un cliente especificando los apellidos. Si los apellidos
     * introducidos no coinciden con ningun cliente,no se borrará
     *
     * @param clientes
     * @param apellido1
     * @param apellido2
     * @return lista de clientes
     */
    public List borrarClientePorApellidos(Clientes clientes, String apellido1, String apellido2) {

        List<Clientes.Cliente> listaClientes = clientes.getCliente();
        Iterator<Clientes.Cliente> iterator = listaClientes.iterator();
        Clientes.Cliente cliente;
        List<String> listaApellidos = new ArrayList<>();
        List<TipoDireccion> listaDirecciones = new ArrayList<>();

        while (iterator.hasNext()) {
            cliente = iterator.next();

            if (apellido1.equalsIgnoreCase(listaApellidos.get(0)) && apellido2.equalsIgnoreCase(listaApellidos.get(1))) {
                iterator.remove();
            }
        }

        return listaClientes;
    }

    /**
     * Añadir un cliente con todos sus datos.
     *
     * @param clientes
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param calle
     * @param piso
     * @param numero
     * @param escalera
     * @param codigoPostal
     * @param ciudad
     * @param numTelefono
     * @return nuevo cliente
     * @throws CodigoPostalExcepcion
     */
    public Clientes.Cliente anhadirCliente(Clientes clientes, String nombre, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad, String numTelefono) throws CodigoPostalExcepcion {

        if (codigoPostal > 99999 || codigoPostal < 10000) {
            throw new CodigoPostalExcepcion("En codigo:" + String.valueOf(codigoPostal) + " no es válido");
        }

        Clientes.Cliente nuevoCliente = new Clientes.Cliente();
        List<Clientes.Cliente> listaClientes = clientes.getCliente();
        TipoDireccion direccion = new TipoDireccion();
        List<TipoDireccion> listaDirecciones = nuevoCliente.getDireccion();

        nuevoCliente.setNombre(new Clientes.Cliente.Nombre());
        nuevoCliente.setTelefono(numTelefono);

        nuevoCliente.getApellido().add(apellido1);
        nuevoCliente.getApellido().add(apellido2);
        direccion.setCalle(calle);
        direccion.setCiudad(ciudad);
        direccion.setNumero(numero);
        direccion.setEscalera(escalera);
        direccion.setPiso(piso);
        direccion.setCp(codigoPostal);

        listaDirecciones.add(direccion);
        listaClientes.add(nuevoCliente);

        return nuevoCliente;
    }

    /**
     * Introducimos la nueva dirección y el nombre y apellidos de un cliente en
     * concreto. Si coinciden, se le añadirá la dirección. Si ya tiene 3
     * direcciones, no se le añadirá la nueva direccion
     *
     * @param clientes
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param calle
     * @param piso
     * @param numero
     * @param escalera
     * @param codigoPostal
     * @param ciudad
     * @return la nueva direccion añadida
     * @throws PisoIncorrectoException
     */
    public TipoDireccion anhadirDireccionClienteEspecifico(Clientes clientes, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad) throws PisoIncorrectoException, NumeroDireccionesExcedidoException {

        TipoDireccion nuevaDireccion = null;
        Clientes.Cliente clienteDireccion = new Clientes.Cliente();
        List<Clientes.Cliente> listaClientes = clientes.getCliente();
        List<String> listaApellidos = new ArrayList<>();
        List<TipoDireccion> listaDirecciones = clienteDireccion.getDireccion();

        nuevaDireccion.setCalle(calle);
        nuevaDireccion.setCiudad(ciudad);
        nuevaDireccion.setNumero(numero);
        nuevaDireccion.setEscalera(escalera);
        nuevaDireccion.setPiso(piso);
        nuevaDireccion.setCp(codigoPostal);

        if (nuevaDireccion.getCp() < 0) {
            throw new PisoIncorrectoException("El número de piso " + nuevaDireccion.getNumero() + " no puede ser negativo");
        }
        //buscar cliente

        for (Cliente cliente : listaClientes) {
            if (listaDirecciones.size() < 3) {
                if (apellido1.equalsIgnoreCase(listaApellidos.get(0)) && apellido2.equalsIgnoreCase(listaApellidos.get(1))) {
                    listaDirecciones.add(nuevaDireccion);
                } else {
                    throw new NumeroDireccionesExcedidoException ("Sólo se pueden introducir 3 direcciones como máximo");
                }
            }
        }
        return nuevaDireccion;
    }

    /**
     * Modifica los datos de la dirección de un cliente del que introducimos
     * nombre y apellidos. Deberemos de escoger a la vez, que direccion vamos
     * a cambiar (int posicionDireccion: 0 la primera direccion, 1 la segunda o 
     * 2 la tercera)
     *
     * @param clientes
     * @param posicionDireccion
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param calle
     * @param piso
     * @param numero
     * @param escalera
     * @param codigoPostal
     * @param ciudad
     * @return la direccion modificada
     * @throws excepcionesClientes.ExcepcionesClientes.CaracterInvalidoException
     */
    public TipoDireccion modificarDireccionClienteEspecico(Clientes clientes, int posicionDireccion, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad) throws CaracterInvalidoException {

        TipoDireccion direccionExistente = null;
        Clientes.Cliente clienteDireccion = new Clientes.Cliente();
        List<Clientes.Cliente> listaClientes = clientes.getCliente();

        List<TipoDireccion> listaDirecciones = clienteDireccion.getDireccion();

        if (direccionExistente.getCiudad().contains("ñ") || direccionExistente.getCalle().contains("ñ")) {
            throw new CaracterInvalidoException("No puedes introducir una ñ");
        }
        direccionExistente.setCalle(calle);
        direccionExistente.setCiudad(ciudad);
        direccionExistente.setNumero(numero);
        direccionExistente.setEscalera(escalera);
        direccionExistente.setPiso(piso);
        direccionExistente.setCp(codigoPostal);

        List<String> listaApellidos = new ArrayList<>();

        for (Cliente cliente : listaClientes) {

            if (apellido1.equalsIgnoreCase(listaApellidos.get(0)) && apellido2.equalsIgnoreCase(listaApellidos.get(1))) {
                cliente.getDireccion().set(posicionDireccion, direccionExistente);

            }
        }
        return direccionExistente;
    }

    /**
     * Borra las direcciones cuyo codigo postal es 0.
     *
     * @return lista de direcciones
     */
    public List borrarDireccionNoCodPostalDeTodos(Clientes clientes) {

        Clientes.Cliente cliente = new Clientes.Cliente();
        List<TipoDireccion> listaDirecciones = cliente.getDireccion();

        for (TipoDireccion direccion : listaDirecciones) {
            if (direccion.getCp() == 0) {
                listaDirecciones.remove(direccion);
            }
        }
        return listaDirecciones;
    }

    public void crearHTML() {

    }

}
