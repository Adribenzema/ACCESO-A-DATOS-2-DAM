package modelo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;
import jaxb.fotosBinding.AlbumesFotos;

/**
 *
 * @author Shaila
 */
public class JsonMetodosAlbumesFotos {

    /**
     * Método para leer un fichero Json al que se le pasa por parámetro dicho
     * fichero.
     *
     * @param documentoJson
     * @return un objeto JsonObject.
     */
    public static JsonObject leerJson(String documentoJson) {
        JsonObject diccionarioEspanol = null;
        try {
            JsonReader jsonReader;

            InputStream fis = new FileInputStream(documentoJson);
            jsonReader = Json.createReader(fis);
            diccionarioEspanol = jsonReader.readObject();

            jsonReader.close();

            fis.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return diccionarioEspanol;

    }

    /**
     * Método para contar el total de fotografías con una ISO que se le pasa por
     * parámetro.
     *
     * @param jsonObject
     * @param iso
     * @return
     */
    public static int contarTotalFotografias(JsonObject jsonObject, String iso) {

        int contadorFotografias = 0;

        JsonArray jsonArray = jsonObject.getJsonObject("albumesFotos").getJsonArray("albumFotos");

        for (int contadorAlbumes = 0; contadorAlbumes < jsonArray.size(); contadorAlbumes++) {
            JsonArray listaFotos = jsonArray.getJsonObject(contadorAlbumes).getJsonArray("foto");
            for (int contadorFotos = 0; contadorFotos < listaFotos.size(); contadorFotos++) {

                if (iso.equals(listaFotos.getJsonObject(contadorFotos).getJsonNumber("ISO").toString())) {
                    contadorFotografias++;
                }

            }

        }

        return contadorFotografias;
    }

    /**
     * Método que genera un Map donde K es el título del álbum y V es el total
     * de fotos del álbum.
     *
     * @param jsonObject
     * @return
     */
    public static Map<String, Integer> generarMap(JsonObject jsonObject) {
        Map<String, Integer> informacionAlbumes = new HashMap<>();
        JsonArray jsonArray = jsonObject.getJsonObject("albumesFotos").getJsonArray("albumFotos");

        for (int contadorAlbumes = 0; contadorAlbumes < jsonArray.size(); contadorAlbumes++) {
            if (!informacionAlbumes.containsKey(jsonArray.getJsonObject(contadorAlbumes).getString("titulo"))) {
                informacionAlbumes.put(jsonArray.getJsonObject(contadorAlbumes).getString("titulo"), jsonArray.getJsonObject(contadorAlbumes).getJsonArray("foto").size());
            }
        }
        return informacionAlbumes;

    }
}
