/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import excepcionesClientes.ExcepcionesClientes;
import excepcionesClientes.ExcepcionesClientes.MarshalExcepcion;
import excepcionesClientes.ExcepcionesClientes.UnmarshalExcepcion;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBElement;
import jaxb.clientes.Clientes;
import jaxb.clientes.TipoDireccion;
import modelo.MetodosClientes;

/**
 *
 * @author Annie
 */
public class JaxbClientes_Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExcepcionesClientes.CodigoPostalExcepcion, ExcepcionesClientes.PisoIncorrectoException, ExcepcionesClientes.NumeroDireccionesExcedidoException {

        MetodosClientes metodos = new MetodosClientes();
        try {
            //UNMARSHALIZAR
            JAXBElement jaxbElement = metodos.unMarshalizar("clientes.xml");//metodo unmarshalizador

            Clientes clientes = (Clientes) jaxbElement.getValue();//castear al tipo del nodo "raíz"
            //OPERACIONES
            int totalClientes = metodos.totalClientes(clientes);
            System.out.println("total " + totalClientes);

            metodos.totalClientesPorProvincia(clientes, "77");

            metodos.anhadirCliente(clientes, "ana", "Espina", "Cortecero", "Las Cuestas", 1, "13", "A", 33900, "Langreo", "666555444");

            metodos.anhadirDireccionClienteEspecifico(clientes, "Fernandez", "Garcia", "Nueva", 5, "8", "A", 33900, "Langreo");

            metodos.borrarClientePorApellidos(clientes, "Espina", "Cortecero");

            metodos.borrarDireccionNoCodPostalDeTodos(clientes);

            //MARSHALIZAR
            File ficheroSalida = new File("miXMLmodificadoCLIENTES.xml");//xml de salida nuevo modificado
            metodos.marshalizar(jaxbElement, ficheroSalida);//metodo marshalizador
        } catch (UnmarshalExcepcion ex) {
            Logger.getLogger(JaxbClientes_Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MarshalExcepcion ex) {
            Logger.getLogger(JaxbClientes_Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
