package modelo;

import java.io.File;
import java.util.List;
import javax.xml.bind.JAXBElement;
import jaxb.clientes.Clientes;
import jaxb.clientes.TipoDireccion;

/**
 *
 * @author Shaila
 */
public interface MetodosOperacionesClientes {

    public JAXBElement unmarshalDocument(String jaxb, String xml);

    public boolean marshalDocument(JAXBElement jaxbElement,File ficheroSalida);

    public int totalClientes(Clientes clientes);//Dos primeros digitos CP

    public int totalClientesPorProvincia(Clientes clientes, int cp);//Dos primeros digitos CP

    public boolean borrarClientePorApellidos(Clientes clientes, String... apellidos);//Puede haber dos

    public Clientes.Cliente aniadirCliente(Clientes clientes, String nombre,
            String apellido1, String apellido2, String calle, int piso,
            String numero, String escalera, int codigoPostal, String ciudad,
            String numTelefono) throws ExcepcionesClientes.CodigoPostalException;//con todos sus datos.

    public TipoDireccion aniadirDireccionCliente(Clientes clientes,
            String apellido1, String apellido2, String calle,
            int piso, String numero, String escalera, int codigoPostal,
            String ciudad, String numTelefono) throws ExcepcionesClientes.
            CodigoPostalException, ExcepcionesClientes.PisoIncorrecto,
             ExcepcionesClientes.NumeroMaximoDirecciones;

    public TipoDireccion modificarDatosDireccionCliente(Clientes clientes,
            String apellido1, String apellido2, String calle,
            int piso, String numero, String escalera, int codigoPostal,
            String ciudad, String numTelefono);//Por telefono

    public boolean borrarDireccionesSinCodigoPostal();

    //Crear un html5 con los nombres y los apellidos de todos los clientes seguidos de sus direcciones
}
