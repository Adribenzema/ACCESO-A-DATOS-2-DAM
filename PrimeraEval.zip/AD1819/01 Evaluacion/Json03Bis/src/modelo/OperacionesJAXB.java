package modelo;

import java.io.File;
import java.util.List;
import javax.xml.bind.JAXBElement;
import jaxb.clientesBinding.Clientes;
import jaxb.clientesBinding.TipoDireccion;

/**
 *
 * @author Shaila
 */
public interface OperacionesJAXB {

    public JAXBElement unMarshall(File documentoXML);

    public boolean marshall(JAXBElement jaxbElement);

    public int totalClientes(Clientes clientes);

    public int totalClientesProvincia(Clientes clientes, int cp);

    public boolean borrarCliente(Clientes clientes, String primerApellido, String segundoApellido);

    public boolean annadirCliente(Clientes clientes, String primerApellido, String segundoApellido,
            String calle, String ciudad, int cp, String escalera, String numero, int piso, String telf, String lenguaje);

    public boolean annadirClienteDirs(Clientes clientes, String primerApellido, String segundoApellido,
            List<TipoDireccion> listaDirs, String telf, String lenguaje);

    public boolean annadirDirACliente(Clientes clientes, String primerApellido, String segundoApellido,
            String calle, String ciudad, int cp, String escalera, String numero, int piso);

    public boolean modificarDirCliente(Clientes clientes, String primerApellido, String segundoApellido, int dir,
            String calle, String ciudad, int cp, String escalera, String numero, int piso);

    public boolean borrarDirsinCp(Clientes clientes);

    public TipoDireccion crearDirCliente(String calle, String ciudad, int cp,
            String escalera, String numero, int piso);

}
