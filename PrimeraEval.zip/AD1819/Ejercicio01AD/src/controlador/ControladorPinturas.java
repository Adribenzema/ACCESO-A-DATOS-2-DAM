package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Shaila
 */
public class ControladorPinturas {

    Connection conexion;
    String cadenaConexion = "jdbc:mysql://localhost:3306/galeria?serverTimezone=UTC";

    /**
     * Método que permite conectarse a la BBDD.
     *
     * @param username
     * @param passwd
     */
    public void conexion(String username, String passwd) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(cadenaConexion, username, passwd);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ControladorPinturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Método que permite retornar todos los pintores, pasándole por parámetro
     * un booleano para ordenar por nombre si el usuario quiere.
     *
     * @param opcion boolean con decisión.
     * @return ResultSet
     */
    public ResultSet retornarTodosPintores(boolean opcion) {
        ResultSet resulset = null;
        String sentencia;
        if (opcion) {
            sentencia = "SELECT nombre FROM pintor";
        } else {
            sentencia = "SELECT nombre FROM pintor ORDER BY nombre";
        }
        try {
            Statement stmt = conexion.createStatement();
            resulset = stmt.executeQuery(sentencia);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorPinturas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resulset;
    }

    //  ALTER TABLE nombre_tabla AUTO_INCREMENT=1
    /**
     * insertarPintor
     *
     * @param nombre
     * @param anno
     * @param estilo
     * @throws SQLException
     */
    public void insertarPintor(int id_pintor, String nombre, int anno, String estilo) throws SQLException {
        ResultSet resultsetPintor = null;
        try {
            conexion.setAutoCommit(false);//Tiene que ir así

            String cadenaSQL = "INSERT INTO `galeria`.`pintor` (`id_pintor`, `nombre`, `anio_nacimiento`, `estilo`) VALUES ('?','?','?','?');";

            PreparedStatement prepareInsertPintor = conexion.prepareStatement(cadenaSQL);
            prepareInsertPintor.setInt(1, id_pintor);
            prepareInsertPintor.setString(2, nombre);
            prepareInsertPintor.setInt(3, anno);
            prepareInsertPintor.setString(4, estilo);

            System.err.println("sql:" + prepareInsertPintor.toString());
            prepareInsertPintor.executeUpdate();

            conexion.commit();

        } catch (SQLException ex) {

            conexion.rollback();
            conexion.setAutoCommit(true);
        }
    }

    public void insertarCuadro(String nombrePintor, String tituloCuadro, int anio) throws SQLException {

        ResultSet resultsetPintor = null;
        try {
            //SACAR EL ID CON EL NOMBRE
            conexion.setAutoCommit(false);
            String cadenaSQL = "SELECT id_pintor FROM galeria.pintor WHERE nombre=?;";
            PreparedStatement stmtId = conexion.prepareStatement(cadenaSQL);
            resultsetPintor = stmtId.getResultSet();
            int id_autor = resultsetPintor.getRow();
            //HACER EL INSERT
            cadenaSQL = "INSERT INTO `pinturas`.`cuadro` (`titulo`, `anio`, `id_autor`) VALUES (?, ?, ?);";

            PreparedStatement prepareInsertPintor = conexion.prepareStatement(cadenaSQL);

            prepareInsertPintor.setString(2, tituloCuadro);
            prepareInsertPintor.setInt(3, anio);
            prepareInsertPintor.setInt(4, id_autor);
            prepareInsertPintor.executeUpdate();

            //prepareInsertPintor
            conexion.commit();

        } catch (SQLException ex) {
            conexion.rollback();
            conexion.setAutoCommit(true);
        }

        //SELECT id_pintor FROM pinturas.pintor WHERE nombre="?";
        //INSERT INTO `pinturas`.`cuadro` (`titulo`, `anio`, `id_autor`) VALUES ('?', '?', '?');
    }

    public void eliminarPintor(String nombre) {
        try {
            conexion.setAutoCommit(false);
            //PreparedStatement stmt = (PreparedStatement) conexion.createStatement("");
        } catch (SQLException ex) {
            Logger.getLogger(ControladorPinturas.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
