package logica;

import javax.json.JsonObject;
import modelo.JsonMetodosAlbumesFotos;



/**
 *
 * @author Shaila
 */
public class JSonAlbumesFotos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String rutaFichero = "fotos.json";
        
        JsonObject jsonObject = JsonMetodosAlbumesFotos.leerJson(rutaFichero);
        //800
        System.out.println("Total fotos " + JsonMetodosAlbumesFotos.
                contarTotalFotografias(jsonObject, "800"));
        
        System.out.println("Map "+JsonMetodosAlbumesFotos.generarMap(jsonObject));

    }
}
