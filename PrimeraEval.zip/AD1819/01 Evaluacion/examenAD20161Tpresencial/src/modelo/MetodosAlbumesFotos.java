package modelo;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.fotosBinding.AlbumesFotos;
import modelo.ExcepcionesAlbumesFotos.MarshalExcepcion;

/**
 *
 * @author Shaila
 */
public class MetodosAlbumesFotos implements AlbumesFotosInterface {

    private JAXBContext jaxbCtx = null;

    public MetodosAlbumesFotos(String packageName) {
        try {
            jaxbCtx = JAXBContext.newInstance(packageName);
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public JAXBElement unMarshall(File documentoXML) {
        JAXBElement jaxbElement = null;
        try {
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = unmarshaller.unmarshal(new StreamSource(new java.io.File(documentoXML.toString())), AlbumesFotos.class);

        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }

        return jaxbElement;
    }

    /**
     * Método marshalizador. Genera un XML a partir del JAXB
     *
     * @param jaxbElement
     * @param ficheroSalida donde volcamos los datos
     * @return true si esta todo correcto; false si hay algun problema
     * @throws jaxb_albaran.Excepciones.MarshalExcepcion
     */
    @Override
    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws
            MarshalExcepcion {
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.fotosBinding");
            Marshaller marshaller;
            marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);//Controla si hay que formatear el XML para leerlo mejor      
            marshaller.marshal(jaxbElement, ficheroSalida);//Muestra el contenido del objeto en salida estandar
            return true;
        } catch (javax.xml.bind.JAXBException ex) {

            return false;
        }
    }

    /**
     * Método que cuenta el total de fotografías con una ISO que se pasa como
     * parámetro.
     *
     * @param albumesFotos
     * @param iso
     * @return
     */
    @Override
    public int totalFotografiasConIso(AlbumesFotos albumesFotos, String iso) {
        int totalFotografias = 0;

        for (int i = 0; i < albumesFotos.getAlbumFotos().size(); i++) {
            for (int j = 0; j < albumesFotos.getAlbumFotos().get(i).getFoto().size(); j++) {
                if (albumesFotos.getAlbumFotos().get(i).getFoto().get(j).getISO().equalsIgnoreCase(iso)) {
                    totalFotografias++;
                }

            }

        }
        return totalFotografias;

    }

    /*
    Cambia el email de un autor en todas las fotografías y lo marsaliza en el fichero XML.
     */
    /**
     * Método para cambiar el email a un determinado autor en todas las
     * fotografías.
     *
     * @param albumesFotos
     * @param email
     */
    @Override
    public boolean cambiarEmailDeAutor(AlbumesFotos albumesFotos, String nameAutor) {
        //AutorType autor = new AutorType();
        for (int i = 0; i < albumesFotos.getAlbumFotos().size(); i++) {
            if (albumesFotos.getAlbumFotos().get(i).getAutor().getNombre().equals(nameAutor)) {
                albumesFotos.getAlbumFotos().get(i).getAutor().setEmail("newEmail");
            }
        }
        return true;
    }

    /**
     * Método que genera un Map donde K es el nombre del álbum y V es el total
     * de fotos del álbum.
     *
     * @param albumesFotos
     * @return
     */
    @Override
    public Map<String, Integer> generarInformeAlbumes(AlbumesFotos albumesFotos) {
        Map<String, Integer> informacionAlbumes = new HashMap<>();

        for (int i = 0; i < albumesFotos.getAlbumFotos().size(); i++) {

            informacionAlbumes.put(albumesFotos.getAlbumFotos().get(i).getTitulo(), albumesFotos.getAlbumFotos().get(i).getFoto().size());

        }

        return informacionAlbumes;

    }


}
