package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Shaila
 */
@Entity
@Table(name = "cuenta")
public class Cuenta  implements Serializable{

    @Id
    private Long id;

    private String numeroCuenta;
    private int saldo;
    private String divisa;
    
    /**
     * Relación bidireccional con cliente, metemos el objeto en la clase y
     * establecemos que es one to one ya que un cuenta solo puede tener un
     * cliente, en este caso. 
     * En las relaciones bidireccionales, el lado 'muchos' es el
     * dueño de la relación, es decir, aquí es Cuenta
     *
     * Muchos Cuentas pueden pertenecer a un Cliente.
     */
    @ManyToOne
    private Cliente cliente;
    
    
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)//para cargar los datos el eager, es más lento porque carga todos los datos
    private List<Movimiento> listaDeMovimientos = new ArrayList<>();

    public Cuenta() {
    }

    /**
     * No hace falta poner el constructor con parámetros
     *
     * @param numeroCuenta
     * @param saldo
     * @param divisa
     */
    
    public Cuenta(String numeroCuenta, int saldo, String divisa, Cliente cliente) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.divisa = divisa;
        this.cliente = cliente;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public String getDivisa() {
        return divisa;
    }

    public void setDivisa(String divisa) {
        this.divisa = divisa;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<Movimiento> getListaDeMovimientos() {
        return listaDeMovimientos;
    }

    public void setListaDeMovimientos(List<Movimiento> listaDeMovimientos) {
        this.listaDeMovimientos = listaDeMovimientos;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
