package logica;

import java.io.File;
import java.text.SimpleDateFormat;

import modelo.MisFiltros;

/**
 *
 * @author Shaila
 */
public class MainFiltros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String ruta = "C:\\Users\\Shaila\\Downloads\\WEB";
        File file = new File(ruta);
        //FUNCIONA
        /*        System.out.println("\nIMAGENES.");
        String[] listas1 = file.list(new MisFiltros.FiltroMultimedia("I"));
        for (String s : listas1) {
        System.out.println(s);
        }*/

        //FUNCIONA
        /*        System.out.println("\nDOCUMENTOS.");
        String[] listas2 = file.list(new MisFiltros.FiltroDocumentos("P"));
        for (String s : listas2) {
        System.out.println(s);
        }*/
        //FUNCIONA
        /*                System.out.println("\nDIRECTORIOS.");
        String[] listas3 = file.list(new MisFiltros.FiltroEsDirectorio());
        for (String s : listas3) {
        System.out.println(s);
        }*/
        //FUNCIONA
       System.out.println("\nARCHIVOS TAMAÑO MINIMO.");
        String[] listas4 = file.list(new MisFiltros.FiltroTamanio(28794538));
        for (String s : listas4) {
        System.out.println(s);
        }
        //NO FUNCIONA
        System.out.println("\nFECHAS.");
        String[] listas5 = file.list(new MisFiltros.Filtro24Horas());
        for (String s : listas5) {
            System.out.println(s);
        }
        
        
        
    }
}
