/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Shaila
 */
public class MisExcepciones {

    public static class NoEsFile extends Exception {

        public NoEsFile() {

        }

        public NoEsFile(String msg) {
            super(msg);
        }
    }

    public static class ExisteRuta extends Exception {

        public ExisteRuta() {

        }

        public ExisteRuta(String msg) {
            super(msg);
        }
    }

    public static class NoExisteRuta extends Exception {

        public NoExisteRuta() {

        }

        public NoExisteRuta(String msg) {
            super(msg);
        }
    }

    public static class YaExisteDirectorio extends Exception {

        public YaExisteDirectorio() {

        }

        public YaExisteDirectorio(String msg) {
            super(msg);
        }
    }

    public static class NoEsUnDirectorioNoSePuedeListar extends Exception {

        public NoEsUnDirectorioNoSePuedeListar() {

        }

        public NoEsUnDirectorioNoSePuedeListar(String msg) {
            super(msg);
        }
    }

    public static class CarpetaVacia extends Exception {

        public CarpetaVacia() {
        }

        public CarpetaVacia(String string) {
            super(string);
        }

    }
}
