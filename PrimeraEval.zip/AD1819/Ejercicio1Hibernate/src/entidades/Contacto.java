package entidades;

import java.io.Serializable;

/**
 *
 * @author Shaila
 */
public class Contacto implements Serializable {

    private long id;
    private String nombre;
    private String email;
    private String telefono;

    /**
     * El constructor sin argumentos si es obligatorio ya que Hibernate creará
     * instancias de esta clase usando reflexión cuando recupere las entidades
     * de la base de datos. Este constructor puede ser privado (si es que no
     * quieren permitir que alguien más lo utilice), pero usualmente el nivel de
     * acceso más restrictivo que usaremos es el de paquete (el default), ya que
     * esto hace más eficiente la creación de los objetos.
     */
    public Contacto() {
    }

    public Contacto(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getId() {
        return id;
    }

    /**
     * Hay que poner el setter del id privado --> parar que hibernate gestione
     * los id y les de uno diferente a cada uno. Usualmente no manipulamos
     * directamente este identificador (dejamos que sea la base de datos quien
     * lo genere, cuando la entidad sea guardada, y Hibernate quien lo asigne al
     * objeto), por lo tanto el setter del "id" es privado (fíjense cómo lo he
     * puesto en la clase "Contacto").
     */
    private void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
