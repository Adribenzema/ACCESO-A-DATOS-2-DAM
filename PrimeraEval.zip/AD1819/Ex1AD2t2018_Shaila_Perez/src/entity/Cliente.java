package entity;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Shaila
 */
@Entity
@Table(name = "cliente")
public class Cliente  implements Serializable{

    @Id
    private Long id;

    private String dni;
    private String nombre;
    private String apellido;

    /**
     * Relación bidireccional con sucursarl, metemos el objeto en la clase y
     * establecemos que es one to one ya que un cliente solo puede tener una
     * sucursal. En las relaciones bidireccionales, el lado 'muchos' es el dueño
     * de la relación, es decir, aquí es Cliente
     *
     * Muchos clientes pueden pertenecer a una sucursal.
     */
    @ManyToOne
    private Sucursal sucursal;

    /**
     * Relación bidireccional con cuenta, metemos el objeto en la clase y
     * establecemos que es one to many ya que un cliente puede tener varias
     * cuentas.
     */
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)//para cargar los datos el eager, es más lento porque carga todos los datos
    private List<Cuenta> listaDeCuentas = new ArrayList<>();

    public Cliente() {
    }
    public Cliente(String dni, String nombre, String apellido, Sucursal sucursal) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sucursal = sucursal;
    }

    //Generamos getters y setters por defecto
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Sucursal getSucursal() {
        return sucursal;
    }

    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }

    public List<Cuenta> getListaDeCuentas() {
        return listaDeCuentas;
    }

    public void setListaDeCuentas(List<Cuenta> listaDeCuentas) {
        this.listaDeCuentas = listaDeCuentas;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
