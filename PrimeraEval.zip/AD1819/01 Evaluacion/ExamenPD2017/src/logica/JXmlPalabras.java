package logica;

import java.io.File;
import javax.xml.bind.JAXBElement;
import jaxb.diccionario2Binding.DiccionarioEspanol;
import modelo.MetodosPalabras;

/**
 *
 * @author Shaila
 */
public class JXmlPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //String rutaFichero = "diccionario2.json";
        MetodosPalabras metodosPalabras = new MetodosPalabras("jaxb.diccionario2Binding");
        File documentoXML = new File("diccionario2.xml");
        JAXBElement jaxbElement = metodosPalabras.unMarshall(documentoXML);//metodo unmarshalizador

        DiccionarioEspanol diccionarioEspanol = (DiccionarioEspanol) jaxbElement.getValue();//castear al tipo del nodo "raíz"
        //OPERACIONES
        /*
        Contar el total de sinónimos y el total de antónimos que contienen una determinada palabra. 
         */
//OJO que lo cambiaste
        System.out.println("Total totalSinonimos y totalAntonimos " + (metodosPalabras.totalSinonimosYtotalAntonimos(diccionarioEspanol, 0)));
        /**
         * Borrar todas las palabras que en su grafía contienen una determinada
         * cadena de caracteres texto.
         */
        System.out.println("Total palabras borradas " + (metodosPalabras.borrarTodasLasPalabras(
                diccionarioEspanol, "Shaila")));
        /**
         * Generar un Map donde K es la grafía de la palabra y V es el total de
         * sinónimos con porcentaje de similitud superior a 80%.
         */
        System.out.println("Map key "+metodosPalabras.generarGrafia(diccionarioEspanol, 3.14159f));
    
        /**
         * Contar el número de veces que aparece una palabra (su grafía) en la
         * lista de sinónimos.
         */
        System.out.println("Total palabras grafía en sinónimos "+metodosPalabras.contarPalabras(diccionarioEspanol, "hola"));
        
    
    }
}
