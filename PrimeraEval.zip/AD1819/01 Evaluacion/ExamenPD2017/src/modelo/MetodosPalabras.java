package modelo;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.diccionario2Binding.DiccionarioEspanol;

/**
 *
 * @author Shaila
 */
public class MetodosPalabras implements PalabrasInterface {

    private JAXBContext jaxbCtx = null;

    public MetodosPalabras(String packageName) {
        try {
            jaxbCtx = JAXBContext.newInstance(packageName);
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public JAXBElement unMarshall(File documentoXML) {
        JAXBElement jaxbElement = null;
        try {
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = unmarshaller.unmarshal(new StreamSource(new java.io.File(documentoXML.toString())), DiccionarioEspanol.class);

        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }

        return jaxbElement;
    }

    @Override
    public boolean marshall(JAXBElement jaxbElement) {
        try {
            Marshaller m = null;

            m = jaxbCtx.createMarshaller();

            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            m.marshal(jaxbElement, System.out);
            return true;
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    @Override
    public String totalSinonimosYtotalAntonimos(DiccionarioEspanol diccionarioEspanol, int posicion) {

        
        return "Sinonimos: " + diccionarioEspanol.getPalabras().getPalabra().get(posicion).getSinonimos().getSinonimo().size() + ",Antonimos: " + diccionarioEspanol.getPalabras().getPalabra().get(posicion).getAntonimos().getAntonimo().size();

    }

    @Override
    public int borrarTodasLasPalabras(DiccionarioEspanol diccionarioEspanol, String cadenaCaracteres) {
        int totalPalabrasBorradas = 0;
        for (int i = 0; i < diccionarioEspanol.getPalabras().getPalabra().size(); i++) {
            if (diccionarioEspanol.getPalabras().getPalabra().get(i).getGrafia().equalsIgnoreCase(cadenaCaracteres)) {
                diccionarioEspanol.getPalabras().getPalabra().remove(i);
                totalPalabrasBorradas++;
            }

        }

        return totalPalabrasBorradas;

    }

    @Override
    public int contarPalabras(DiccionarioEspanol diccionarioEspanol, String palabra) {
        int totalPalabras = 0;
        for (int i = 0; i < diccionarioEspanol.getPalabras().getPalabra().size(); i++) {
            for (int j = 0; j < diccionarioEspanol.getPalabras().getPalabra().get(i).getSinonimos().getSinonimo().size(); j++) {
                if (diccionarioEspanol.getPalabras().getPalabra().get(i).getSinonimos().getSinonimo().get(j).getGrafia().equalsIgnoreCase(palabra)) {
                    totalPalabras++;
                }
            }

        }
        return totalPalabras;
    }

    /**
     * Generar un Map donde K es la grafía de la palabra y V es el total de
     * sinónimos con porcentaje de similitud superior a 80%.
     */
    public Map<String, Integer> generarGrafia(DiccionarioEspanol diccionarioEspanol, float porcentaje) {
    
        Map<String, Integer> informacionGrafia = new HashMap<>();

        for (int i = 0; i < diccionarioEspanol.getPalabras().getPalabra().size(); i++) {
            for (int j = 0; j < diccionarioEspanol.getPalabras().getPalabra().
                    get(i).getSinonimos().getSinonimo().size(); j++) {
                String grafia = diccionarioEspanol.getPalabras().getPalabra().
                        get(i).getSinonimos().getSinonimo().get(j).getGrafia();
                float porcentajeSimilitud = diccionarioEspanol.getPalabras().getPalabra().get(i).getSinonimos().
                        getSinonimo().get(j).getPorcentajeSimilitud();
                if (porcentajeSimilitud >= porcentaje) {

                    if (!informacionGrafia.containsKey(grafia)) {
                        informacionGrafia.put(grafia, 1);
                    } else {
                        informacionGrafia.put(grafia, (informacionGrafia.get(grafia) + 1));
                    }

                }
            }
        }

        return informacionGrafia;

    }

}
