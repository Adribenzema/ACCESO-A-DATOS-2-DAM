package modelo;

import java.sql.*;


/**
 *
 * @author Shaila
 */
public class AccesoBBDD {

    String usuario = "root";
    String contrasenia = "elentrego1384";
    String cadenaConexion = "jdbc:mysql://localhost:3306/galeria?serverTimezone=UTC";

    Connection conexion = null;
    ResultSet resultado = null;
    int resultadoFinal = 0;

    public Connection getConexion() {
        return conexion;
    }

    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }

    /**
     * Método que permite conectarse a la BBDD.
     *
     * @return Conexión
     */
    public Connection conexionBBDD() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        //creo la conexión
        conexion = DriverManager.getConnection(cadenaConexion, usuario, contrasenia);//creas la conexion
        return conexion;
    }

    /**
     * Método que cierra la conexión con la BBDD.
     *
     */
    public void cerrarConexion() throws SQLException {
        conexion.close();

    }

    /**
     * Método que cierra la conexión de la BBDD para PreparedStatement.
     *
     * @param pstmtSQL
     */
    public void cerrarPreparedStatement(PreparedStatement pstmtSQL) throws SQLException {

        if (pstmtSQL != null) {
            pstmtSQL.close();
        }
    }

    /**
     * Método que cierra una conexión de la BBDD para Statement.
     *
     * @param stmtSQL
     */
    public void cerrarStatement(Statement stmtSQL) throws SQLException {
        if (stmtSQL != null) {
            stmtSQL.close();
        }
    }

    /**
     * Método para crear statements sabiendo qué tipo va a
     * ser(Select,Insert,Update,Delete) para luego ejecutarlos y hacer la
     * consulta, en el que se le pasarás un objeto de tipo Statement para
     * realizar la conexión y se le pasará un tipo resultado que SIEMPRE SERÁ
     * ResultSet.TYPE_SCROLL_SENSITIVE y el tipo de actualización que siempre
     * será ResultSet.CONCUR_UPDATABLE
     *
     * @param tipoResultado
     * @param tipoActualizacion
     * @return Statement con el resultado de la consulta.
     */
    public Statement crearStatementFijo(int tipoResultado, int tipoActualizacion) throws SQLException {
        Statement stmt = null;
        stmt = conexion.createStatement(tipoResultado, tipoActualizacion);
        return stmt;
    }

    /**
     * Método para crear statements que sepas qué tipo va a
     * ser(Slect,Insert,Update,Delete) para luego ejecutarlos y hacer la
     * consulta, en el que le pasarás un objeto de tipo Statement para realizar
     * la conexion y le pasarás un tipo resultado que SIEMPRE SERÁ
     * ResultSet.TYPE_SCROLL_SENSITIVE y el tipo de actualización que siempre
     * será ResultSet.CONCUR_UPDATABLE. HAY QUE PASARLE YA LA CONSULTA SQL
     *
     * @param consultaSQL
     * @param tipoResultado
     * @param tipoActualizacion
     * @return PreparedStatement con el resultado de la consulta.
     */
    public PreparedStatement crearStatementSinSaberCual(String consultaSQL, int tipoResultado, int tipoActualizacion) throws SQLException {
        PreparedStatement pstmt = null;

        pstmt = conexion.prepareStatement(consultaSQL, tipoResultado, tipoActualizacion);

        return pstmt;
    }

    /**
     * Método que ejecuta el statement donde antes tienes que guardar en una
     * variable statement algún de los dos métodos echos anteriormente, y le
     * escribes la consulta que quieras hacer.
     *
     * @param consultaSQL
     * @param t
     * @return ResultSet con el resultado de la consulta.
     */
    public ResultSet ejecutarSecuenciaSelect(String consultaSQL, Statement t) throws SQLException {

        resultado = t.executeQuery(consultaSQL);

        return resultado;
    }

    /**
     * Lo mismo: Ejecuta el statement donde antes tienes que guardar en una
     * variable statement algún de los dos métodos echos anteriormente, y le
     * escribes la consulta que quieras hacer y será int,diciendote el número de
     * fulas afectadas
     *
     * @param consultaSQL
     * @param t
     * @return int con el resultado final de filas afectadas.
     */
    public int ejecutarSecuenciaInsertUpdateDelete(String consultaSQL, Statement t) throws SQLException {
        System.out.println(consultaSQL);
        resultadoFinal = t.executeUpdate(consultaSQL);
        System.out.println("Se ha visto afectadas el numero de filas de: " + resultadoFinal);

        return resultadoFinal;
    }

    /**
     * Método para ejecutar una PreparedStatement SELECT.
     *
     * @param pstmtSQL
     * @return ResultSet con el resultado de la consulta.
     */
    public ResultSet ejecutarPreparedStatementSELECT(PreparedStatement pstmtSQL) throws SQLException {
        ResultSet resultadoConsulta = null;

        resultadoConsulta = pstmtSQL.executeQuery();

        return resultadoConsulta;
    }

    /**
     * Método para ejecutar una PreparedStatement UPDATE, INSERT, UPDATE.
     *
     * @param pstmtSQL
     * @return int número de filas afectadas SQL.
     */
    public int ejecutarPreparedStatementNOSELECT(PreparedStatement pstmtSQL) throws SQLException {
        int numFilasAfectadasSQL = 0;

        numFilasAfectadasSQL = pstmtSQL.executeUpdate();

        return numFilasAfectadasSQL;
    }

    /**
     * Método que cierra todo.
     *
     * @param s
     */
    public void cerrarTodoSelect(Statement s) throws SQLException {
        if (resultado != null) {

            resultado.close();
            System.out.println("Cerrado el resultado.");

        }
        if (s != null) {

            s.close();
            System.out.println("Cerrado el statement.");

        }
        if (conexion != null) {
            System.out.println("La conexión a la BBDD se ha realizado con éxito.");
            this.cerrarConexion();

        } else {
            System.out.println("No se ha podido conectar.");
        }
    }

}
