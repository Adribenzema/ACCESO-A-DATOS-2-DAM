/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.File;
import java.util.Map;
import javax.xml.bind.JAXBElement;
import jaxb.fotosBinding.AlbumesFotos;

/**
 *
 * @author Annie
 */
public interface AlbumesFotosInterface {

    public JAXBElement unMarshall(File documentoXML) throws ExcepcionesAlbumesFotos.UnmarshalExcepcion;

    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws ExcepcionesAlbumesFotos.MarshalExcepcion;

    public int totalFotografiasConIso(AlbumesFotos albumesFotos, String iso);

    public boolean cambiarEmailDeAutor(AlbumesFotos albumesFotos, String nameAutor);

    public Map<String, Integer> generarInformeAlbumes(AlbumesFotos albumesFotos);

}
