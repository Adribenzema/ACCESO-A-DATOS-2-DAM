package modelo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

/**
 *
 * @author Shaila
 */
public class JsonMetodos {

    /**
     * Método para leer un fichero Json al que se le pasa por parámetro dicho
     * fichero.
     *
     * @param documentoJson
     * @return un objeto JsonObject.
     */
    public static JsonObject leerJson(String documentoJson) {
        JsonObject diccionarioEspanol = null;
        try {
            JsonReader jsonReader;

            InputStream fis = new FileInputStream(documentoJson);
            jsonReader = Json.createReader(fis);
            diccionarioEspanol = jsonReader.readObject();

            jsonReader.close();

            fis.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return diccionarioEspanol;

    }

    /**
     * Cuente el total de definiciones que contienen una determinada palabra.
     */
    public static int contarTotalDefinicionesPalabraDeterminada(JsonObject jsonObject,
            String palabraDeterminada) {

        //Creamos un jsonArray de palabras que es con lo que vamos a trabajar
        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").
                getJsonArray("palabra");
     int contador = 0;   
        for (int i = 0; i < jsonArray.size(); i++) {
            JsonObject palabra = jsonArray.getJsonObject(i);
            if(palabraDeterminada.equals(palabra.getString("grafia"))){
            contador = palabra.getJsonArray("definicion").size();
            }
        }

        return contador;

    }

    /**
     * Genere un Map donde K es el idioma de traducción y V es el total de
     * traducciones que hay.
     */
    public static Map<String, Integer> generarGrafia(JsonObject jsonObject) {

        Map<String, Integer> informacionGrafia = new HashMap<>();
//Creamos un jsonArray de palabras que es con lo que vamos a trabajar
        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").getJsonArray("palabra");
        for (int i = 0; i < jsonArray.size(); i++) {
            //Meto en un JsonArray con lo que voy a trabajar
            JsonArray jsonTraducciones = jsonArray.getJsonObject(i).getJsonObject("traducciones").
                    getJsonArray("traduccion");
//DUDAS
            for (int j = 0; j < jsonTraducciones.size(); j++) {
                if (jsonTraducciones.getJsonObject(j).getString("idiomaTraduccion").equals("String")) {
                    if (!informacionGrafia.containsKey("String")) {
                       informacionGrafia.put(jsonTraducciones.getJsonObject(j).getString("idiomaTraduccion"),1);   
  
                    }else{
                        informacionGrafia.put(jsonTraducciones.getJsonObject(j).getString("idiomaTraduccion"),informacionGrafia.get("String")+1); 
                    }
                    
                }
                

            }

        }

        return informacionGrafia;
    }

    /**
     * Genere una lista con la grafía de las palabras añadidas hace menos de 3
     * días.
     */
    public static List<JsonObject> generarLista(JsonObject jsonObject) {
        List<JsonObject> listapalabras = new ArrayList();
        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").getJsonArray("palabra");

        for (int i = 0; i < jsonArray.size(); i++) {
            String string = jsonArray.getJsonObject(i).getString("fechaInsercion");
            String[] split = string.split("-");
            Date date = new Date();
            int res = Integer.parseInt(split[2]) - date.getDate();
            //No sale nada por el día
            if (res < 3) {
                listapalabras.add(jsonArray.getJsonObject(i));
            }
        }
        return listapalabras;
    }
}
