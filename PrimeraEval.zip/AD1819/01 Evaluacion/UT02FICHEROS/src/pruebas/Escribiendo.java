package pruebas;

import java.io.FileWriter;

/**
 *
 * @author Shaila
 */
class Escribiendo {

    public void escribir(String rutaArchivo) {
        String frase = "this is an example";
        try {
            FileWriter fileWrite = new FileWriter(rutaArchivo);
            for (int i = 0; i < frase.length(); i++) {
                fileWrite.write(frase.charAt(i));
            }
            fileWrite.close();
        } catch (Exception e) {
        }

    }

}
