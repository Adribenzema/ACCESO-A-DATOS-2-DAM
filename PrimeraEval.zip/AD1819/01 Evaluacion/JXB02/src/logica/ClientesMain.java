package logica;

import java.io.File;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import jaxb.clientes.Clientes;
import modelo.ExcepcionesClientes;
import modelo.OperacionesCliente;

/**
 *
 * @author Shaila
 */
public class ClientesMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JAXBException, ExcepcionesClientes.CodigoPostalException, ExcepcionesClientes.PisoIncorrecto, ExcepcionesClientes.NumeroMaximoDirecciones {

        //Funciona
        JAXBElement jAXBElement = OperacionesCliente.getInstance().
                unmarshalDocument("jaxb.clientes", "clientes.xml");

        Clientes cliente = (Clientes) jAXBElement.getValue(); //Devuelve la lista de clientes

        /**
         * 1. Retorna el total de clientes.
         */
        System.out.println("Total clientes: " + OperacionesCliente.getInstance()
                .totalClientes(cliente));
        /**
         * 2. Retorna el total de clientes por provincia.
         */
        System.out.println("Total clientes provincia: " + OperacionesCliente.
                getInstance().totalClientesPorProvincia(cliente, 33940));
        /**
         * 3. Borra un cliente especificando los apellidos.
         */
        System.out.println("Borrar: " + OperacionesCliente.
                getInstance().borrarClientePorApellidos(cliente, "Perez", "Fernandez"));
        /**
         * 4. Añade un cliente con todos sus datos.
         */

        System.out.println("Nuevo cliente: " + OperacionesCliente.
                getInstance().aniadirCliente(cliente, "Shaila", "Perez", "Fernandez",
                        "Travesia Colon", 1, "1", "-", 33940, "El Entrego", "665934374"));

        /**
         * 5. Añade una direccion a un cliente concreto.
         */
        System.out.println("Nueva dirección cliente: " + OperacionesCliente.
                getInstance().aniadirDireccionCliente(cliente, "Perez",
                        "Fernandez", "calle", 0, "numero", "escalera", 33900,
                        "ciudad", "numTelefono"));
        /**
         * 6. Modificar los datos de una direccion de un cliente concreto.
         */
        System.out.println("modificarDatosDireccionCliente " + OperacionesCliente.
                getInstance().modificarDatosDireccionCliente(cliente, "Perez",
                        "Fernandez", "calle", 0, "numero", "escalera", 33900,
                        "ciudad", "numTelefono"));
        /**
         * 7. Borra las direcciones que no tienen código postal
         */
        System.out.println("Borrar direcciones que no tiene cp: " + OperacionesCliente.
                getInstance().borrarDireccionesSinCodigoPostal());
//MARSHALIZAR
        File ficheroSalida = new File("shailaXMLmodificadoCLIENTES.xml");//xml de salida nuevo modificado

//Hay que grabarlo para ver los cambios
        OperacionesCliente.getInstance().marshalDocument(jAXBElement, ficheroSalida);
    }

}
