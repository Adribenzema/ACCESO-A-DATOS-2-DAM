import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateSesion {

    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {

        if (sessionFactory != null) {
            return sessionFactory;
        } else {
            try {
                sessionFactory = new Configuration().configure().buildSessionFactory();
            } catch (HibernateException he) {
                he.printStackTrace();
            } finally {
                return sessionFactory;
            }
        }
    }
    
    public static void cerrarSesion() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

}
