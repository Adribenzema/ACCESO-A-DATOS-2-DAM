package modelo;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.clientes.Clientes;
import jaxb.clientes.TipoDireccion;
import modelo.ExcepcionesClientes.*;

/**
 *
 * @author Shaila
 */
public class OperacionesCliente implements MetodosOperacionesClientes {

//Atributos
    private static OperacionesCliente INSTANCE;

    /**
     * Método para crear una sola instancia de la lógica del negocio.
     *
     * @return INSTANCE
     */
    public static OperacionesCliente getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OperacionesCliente();
        }
        return INSTANCE;
    }

    /**
     * Método para Unmarshalizar un documento XML.
     *
     * @param jaxbAlbaran String con el paquete jaxb.
     * @param xml String con el XML .xml
     * @return JAXBElement jaxbElement.
     */
    @Override
    public JAXBElement unmarshalDocument(String jaxb, String xml) {
        JAXBElement jaxbElement = null;
        javax.xml.bind.JAXBContext jaxbCtx = null;
        javax.xml.bind.Unmarshaller unmarshaller = null;
        try {
            jaxbCtx = javax.xml.bind.JAXBContext.newInstance(jaxb);
            unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = unmarshaller.unmarshal(new StreamSource(new File(xml)), Clientes.class);
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        return jaxbElement;
    }

    /**
     * Método para Marshalizar un documento XML.
     *
     * @param jaxbElement JAXBElement
     * @return boolean con el resultado de la operación.
     */
    @Override
    public boolean marshalDocument(JAXBElement jaxbElement, File ficheroSalida) {
//jaxbm tabulador, hay que cambiar un par de cosas

        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.clientes");
            Marshaller marshaller;
            marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);//Controla si hay que formatear el XML para leerlo mejor      
            marshaller.marshal(jaxbElement, ficheroSalida);//Muestra el contenido del objeto en salida estandar
            return true;
        } catch (javax.xml.bind.JAXBException ex) {

            return false;
        }
/*        try {
javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.clientes");
javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8"); //NOI18N
marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
marshaller.marshal(jaxbElement, System.out);
} catch (javax.xml.bind.JAXBException ex) {
// XXXTODO Handle exception
java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
}

return true;*/
    }

    /**
     * Método que devuelve el número de clientess.
     *
     * @param cliente Cliente cliente.
     * @return int con el número de clientes.
     */
    @Override
    public int totalClientes(Clientes clientes) {

        return clientes.getCliente().size();
    }

    /**
     * Método para conocer la cantidad de clientes que hay en una provincia en
     * función de los dos primeros números del cp.
     *
     * @param cliente Cliente cliente.
     * @param cpParaBuscar int cp.
     * @return int con el número de clientes.
     */
    @Override
    public int totalClientesPorProvincia(Clientes clientes, int cpParaBuscar) {
        int contadorDeClientesPorProvincia = 0;
        boolean masDeUnaDireccionPorcliente = false;
        cpParaBuscar /= 1000;
        List<Clientes.Cliente> listaDeClientes = clientes.getCliente();

        for (Clientes.Cliente listaDeCliente : listaDeClientes) {
            List<TipoDireccion> listaDeDirecciones = listaDeCliente.getDireccion();
            for (TipoDireccion listaTipoDireccion : listaDeDirecciones) {
                if ((listaTipoDireccion.getCp() / 1000) == cpParaBuscar) {
                    masDeUnaDireccionPorcliente = true;
                }
            }
            if (masDeUnaDireccionPorcliente) {
                contadorDeClientesPorProvincia++;
                masDeUnaDireccionPorcliente = false;
            }
        }
        return contadorDeClientesPorProvincia;
    }

    /**
     * Método para borrar un cliente por apellidos, puedes introducir uno o dos
     * apellidos para buscar.
     *
     * @param cliente
     * @param apellidos Array de apellidos, puedes meter uno o dos valores o
     * ninguno.
     * @return boolean con el resultado de la operación.
     */
    @Override
    public boolean borrarClientePorApellidos(Clientes cliente, String... apellidos) {
        List<Clientes.Cliente> listaDeClientes = cliente.getCliente();

        for (Clientes.Cliente listaDeCliente : listaDeClientes) {
            List<String> listaDeApellidos = listaDeCliente.getApellido();
            if (listaDeApellidos.containsAll(Arrays.asList(apellidos))) {
                return listaDeClientes.remove(listaDeCliente);
            }
        }

        return false;
    }

    /**
     * Método para añadir un cliente.
     *
     * @param clientes
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param calle
     * @param piso
     * @param numero
     * @param escalera
     * @param codigoPostal
     * @param ciudad
     * @param numTelefono
     * @return Clientes.Cliente
     * @throws modelo.ExcepcionesClientes.CodigoPostalException
     */
    @Override
    public Clientes.Cliente aniadirCliente(Clientes clientes, String nombre,
            String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad,
            String numTelefono) throws ExcepcionesClientes.CodigoPostalException {

        if (codigoPostal > 99999 || codigoPostal < 10000) {
            throw new ExcepcionesClientes.CodigoPostalException("El código postal introducido " + codigoPostal
                    + " no es válido.");

        }
        Clientes.Cliente nuevoCliente = new Clientes.Cliente();
        List<Clientes.Cliente> listaDeClientes = clientes.getCliente();
        TipoDireccion direccion = new TipoDireccion();
        List<TipoDireccion> listaDeDirecciones = nuevoCliente.getDireccion();

        nuevoCliente.setNombre(new Clientes.Cliente.Nombre());
        nuevoCliente.setTelefono(numTelefono);
        nuevoCliente.getApellido().add(apellido1);
        nuevoCliente.getApellido().add(apellido2);
        direccion.setCalle(calle);
        direccion.setCiudad(ciudad);
        direccion.setCp(codigoPostal);
        direccion.setEscalera(escalera);
        direccion.setNumero(numero);
        direccion.setPiso(piso);
        listaDeDirecciones.add(direccion);
        listaDeClientes.add(nuevoCliente);

        return nuevoCliente;
    }

    /**
     * Método que permite introducir una nueva dirección a un cliente concreto.
     * Si coinciden, se le añadirá la dirección. Si ya tiene 3 direcciones, no
     * se le añadirá la nueva dirección.
     *
     * @param clientes
     * @param apellido1
     * @param apellido2
     * @param calle
     * @param piso
     * @param numero
     * @param escalera
     * @param codigoPostal
     * @param ciudad
     * @param numTelefono
     * @return TipoDireccion con la dirección nueva.
     * @throws modelo.ExcepcionesClientes.CodigoPostalException
     * @throws modelo.ExcepcionesClientes.PisoIncorrecto
     * @throws modelo.ExcepcionesClientes.NumeroMaximoDirecciones
     */
    @Override
    public TipoDireccion aniadirDireccionCliente(Clientes clientes,
            String apellido1, String apellido2, String calle,
            int piso, String numero, String escalera, int codigoPostal,
            String ciudad, String numTelefono) throws ExcepcionesClientes.CodigoPostalException,
            ExcepcionesClientes.PisoIncorrecto, ExcepcionesClientes.NumeroMaximoDirecciones {

        TipoDireccion nuevaDireccion = new TipoDireccion();
        Clientes.Cliente clienteNuevaDireccion = new Clientes.Cliente();
        List<Clientes.Cliente> listaDeClientes = clientes.getCliente();
        List<String> listaDeApellidos = new ArrayList<>();

        List<TipoDireccion> listaDeDirecciones = clienteNuevaDireccion.getDireccion();

        nuevaDireccion.setCalle(calle);
        nuevaDireccion.setCiudad(ciudad);
        nuevaDireccion.setCp(codigoPostal);
        nuevaDireccion.setEscalera(escalera);
        nuevaDireccion.setNumero(numero);
        nuevaDireccion.setPiso(piso);

        if (nuevaDireccion.getPiso() < 0) {
            throw new ExcepcionesClientes.PisoIncorrecto("El piso introducido "
                    + Integer.parseInt(nuevaDireccion.getNumero()) + " no es válido.");
        }
        if (codigoPostal > 99999 || codigoPostal < 10000) {
            throw new ExcepcionesClientes.CodigoPostalException("El código postal "
                    + "introducido " + codigoPostal + " no es válido.");
        }

        for (Clientes.Cliente cliente : listaDeClientes) {
            if (cliente.getDireccion().size() < 3) {
                if (cliente.getApellido().get(0).equalsIgnoreCase(apellido1)
                        && cliente.getApellido().get(1).equalsIgnoreCase(apellido2)) {
                    System.out.println("nuevaDireccion " + nuevaDireccion.getCalle());

                    listaDeDirecciones.add(nuevaDireccion);
                    cliente.getDireccion();
                } else {
                    throw new NumeroMaximoDirecciones("No se puede añadir más de"
                            + " tres direcciones al cliente.");
                }

            }
        }

        return nuevaDireccion;

    }

    @Override
    public TipoDireccion modificarDatosDireccionCliente(Clientes clientes,
            String apellido1, String apellido2, String calle,
            int piso, String numero, String escalera, int codigoPostal,
            String ciudad, String numTelefono) {
        TipoDireccion direccionModificada = null;
        List<Clientes.Cliente> listaDeClientes = clientes.getCliente();

        for (Clientes.Cliente cliente : listaDeClientes) {
            if (cliente.getApellido().get(0).equalsIgnoreCase(apellido1)
                    && cliente.getApellido().get(1).equalsIgnoreCase(apellido2)) {
                //listaDeDirecciones.add(nuevaDireccion);
            } else {

            }
        }

        return direccionModificada;

    }

    @Override
    public boolean borrarDireccionesSinCodigoPostal() {

        List<Clientes.Cliente> listaDeClientes = new ArrayList<Clientes.Cliente>();

        for (int i = 0; i < listaDeClientes.size(); i++) {
            for (int j = 0; j < listaDeClientes.get(i).getDireccion().size(); j++) {
                if (listaDeClientes.get(i).getDireccion().get(j).getCp() == 0) {
                    listaDeClientes.get(i).getDireccion().remove(j);
                }
            }

        }

        return true;
    }

}
