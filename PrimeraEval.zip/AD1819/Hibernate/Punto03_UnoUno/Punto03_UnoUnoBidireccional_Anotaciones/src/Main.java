
import entidades.*;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

    private static Session session;

    public static void main(String[] args) {

        session = HibernateSesion.getSessionFactory().openSession();

        //crearDatos();
        //borrarPais();
        //borrarPresidente();

        HibernateSesion.cerrarSesion();
    }

    private static void crearDatos() {
        Pais pais = new Pais("Zamunda", null);
        Presidente presidente = new Presidente("Akeem", pais);
        pais.setPresidente(presidente);
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.persist(pais);
            tx.commit();
            System.out.println("Se han guardado los datos con éxito");
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    private static void borrarPais() {
        borrarEntidad(Pais.class, 1);
    }

    private static void borrarPresidente() {
        borrarEntidad(Presidente.class, 1);
    }

    private static <T> void borrarEntidad(Class<T> t, int indice) {
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            T entidad = (T) session.get(t, indice);
            session.delete(entidad);
            tx.commit();
            System.out.println("Se ha borrado el " + t.getName().replace("entidades.", "") + " con éxito.");
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

}
