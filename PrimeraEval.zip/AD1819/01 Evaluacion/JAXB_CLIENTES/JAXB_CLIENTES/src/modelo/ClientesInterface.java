/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import excepcionesClientes.ExcepcionesClientes;
import java.io.File;
import java.util.List;
import javax.xml.bind.JAXBElement;
import jaxb.clientes.Clientes;
import jaxb.clientes.TipoDireccion;

/**
 *
 * @author Annie
 */
public interface ClientesInterface {

    public JAXBElement unMarshalizar(String ficheroEntrada) throws ExcepcionesClientes.UnmarshalExcepcion;

    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws ExcepcionesClientes.MarshalExcepcion;

    public int totalClientes(Clientes clientes);

    public int totalClientesPorProvincia(Clientes clientes, String PrefijoCodigoPostal);

    public List borrarClientePorApellidos(Clientes clientes, String apellido1, String apellido2);

    public Clientes.Cliente anhadirCliente(Clientes clientes, String nombre, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad, String numTelefono) throws ExcepcionesClientes.CodigoPostalExcepcion;

    public TipoDireccion anhadirDireccionClienteEspecifico(Clientes clientes, String nombre, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad) throws ExcepcionesClientes.PisoIncorrectoException,ExcepcionesClientes.NumeroDireccionesExcedidoException;

    public TipoDireccion modificarDireccionClienteEspecico(Clientes clientes,int posicionDireccion, String nombre, String apellido1, String apellido2, String calle, int piso, String numero, String escalera, int codigoPostal, String ciudad) throws ExcepcionesClientes.CaracterInvalidoException;

    public List borrarDireccionNoCodPostalDeTodos(Clientes clientes);

    public void crearHTML();
}
