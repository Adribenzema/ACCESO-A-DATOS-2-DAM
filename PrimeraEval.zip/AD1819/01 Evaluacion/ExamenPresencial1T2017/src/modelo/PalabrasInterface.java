/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.File;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBElement;
import jaxb.diccionarioBinding.DiccionarioEspanol;
import jaxb.diccionarioBinding.PalabraType;
import jaxb.diccionarioBinding.SinonimoType;

/**
 *
 * @author Annie
 */
public interface PalabrasInterface {

    public JAXBElement unMarshall(File documentoXML) throws ExcepcionesPalabras.UnmarshalExcepcion;

    
    
    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws ExcepcionesPalabras.MarshalExcepcion;

    public int totalDefiniciones(DiccionarioEspanol diccionarioEspanol, String posicion);

    public boolean borrarTraduccionesIdioma(DiccionarioEspanol diccionarioEspanol, String idioma);

    public Map<SinonimoType, String> sinonimosPalabra(DiccionarioEspanol diccionarioEspanol, String palabra);

    public Map<String, Integer> generarInformeTraducciones(DiccionarioEspanol diccionarioEspanol);

}
