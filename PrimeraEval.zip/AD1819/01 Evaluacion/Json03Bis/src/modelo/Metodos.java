package modelo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonValue;
import javax.json.JsonWriter;
import javax.xml.bind.JAXBElement;
import jaxb.clientesBinding.Clientes;
import jaxb.clientesBinding.TipoDireccion;

/**
 *
 * @author Shaila
 */
public class Metodos {

    /**
     * Crear dirección. Crea un JSONObject con los datos necesarios. Creamos un
     * método que devuelva un JsonObjectBuilder y le pasamos por parámetro los
     * datos necesarios para crear una direccion nueva y devolvemos
     */
    public static JsonObjectBuilder crearDireccion(String calle, String numero,
            int piso, String escalera, int cp, String ciudad) {

        return Json.createObjectBuilder()
                .add("calle", calle)
                .add("numero", numero)
                .add("piso", piso)
                .add("escalera", escalera)
                .add("cp", cp)
                .add("ciudad", ciudad);

    }

    /**
     * Método para unir direcciones, entiendo que en el main creamos las
     * direcciones, llamamos las veces que sea necesario al método
     * crearDirecciones, lo metemos en una lista y luego se la pasamos a este
     * método.
     *
     * @param listaDirecciones
     * @return
     */
    public static JsonArrayBuilder unirDirecciones(List<JsonObjectBuilder> listaDirecciones) {
        JsonArrayBuilder createArrayBuilder = Json.createArrayBuilder();

        for (JsonObjectBuilder dir : listaDirecciones) {
            createArrayBuilder.add(dir);
        }

        return createArrayBuilder;
    }

    /**
     * Crear clientes. Crea un JSONObject con los datos necesarios (pasar una
     * lista de clientes) Miramos el xml, un cliente está compuesto por dos
     * apellidos, telefono, un nombre (que debe estar mal) y una lista de
     * direcciones, la lista de direcciones la saco del método anterior,
     * uniéndolas con un método para crear un JsonArrayBuilder.
     */
    
    public static JsonObject crearClientes(String apellido1, String apellido2,
            JsonArrayBuilder listaDirecciones, String telefono) {

        return Json.createObjectBuilder()
                .add("apellido1", apellido1)
                .add("apellido2", apellido2)
                .add("direccion", listaDirecciones)
                .add("telefono", telefono)
                .build();

    }

    /**
     * Lo mismo que las direcciones.
     *
     * @param listaClientes
     * @return
     */
    public static JsonArrayBuilder unirClientes(List<JsonObject> listaClientes) {
        JsonArrayBuilder createArrayBuilder = Json.createArrayBuilder();

        for (JsonObject cliente : listaClientes) {
            createArrayBuilder.add(cliente);
        }

        return createArrayBuilder;
    }

    /**
     * Último paso, crear un fichero.
     *
     * @param rutaFichero
     * @param JsonArrayBuilder clientes
     */
    public static void crearFichero(String rutaFichero, JsonArrayBuilder clientes) {
        //Construimos un JsonArray
        JsonArray arrayJsonLibros = clientes.build();

        //Creamos un FileWriter para el archivo de salida
        FileWriter ficheroSalida = null;
        try {
            ficheroSalida = new FileWriter(rutaFichero);
            //Creamos un JsonWriter para crear el archivo Json
            JsonWriter jsonWriter = Json.createWriter(ficheroSalida);
            //Escribimos el array de Json
            jsonWriter.writeArray(arrayJsonLibros);

        } catch (IOException ex) {
            Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                ficheroSalida.flush();
                ficheroSalida.close();
            } catch (IOException ex) {
                Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    /**
     * Método que pasa un xml a Json
     *
     * @param paquete
     * @param xml
     * @return
     */
    public static List<JsonObject> xmlToJson(String paquete, String xml) {
        //"jaxb.clientesBinding"
        //Creamos una nueva instancia de muestra clase que trabaja con jaxb
        GestionJAXB gesJ = new GestionJAXB(paquete);
        //"clientes.xml"
        //Creamos un file al que le pasamos el xml correspondiente
        File documentoXML = new File(xml);

        //UnMarshallizamos nuestro fichero
        JAXBElement unMarshall = gesJ.unMarshall(documentoXML);
        //Cogemos un cliente mediante getValue();
        Clientes clientes = (Clientes) unMarshall.getValue();

        //Creamos una lista de JsonObject para meter nuestros clientes
        //Clientes por lo visto es una lista de clientes
        //List<Clientes.Cliente> cliente = clientes.getCliente(); //ejemplo
        //Creamos una lista de JsonObject
        List<JsonObject> listaClientesJson = new ArrayList<>();
        for (Clientes.Cliente cliente1 : clientes.getCliente()) {
            //Creamos una lista de direcciones para luego añadirselas al cliente
            List<JsonObjectBuilder> listaDirecciones = new ArrayList<>();
            // TipoDireccion sale del Binding que hice
            //TipoDireccion tipoDireccion;
            //tipoDireccion.getCalle, se que es una lista --> List<TipoDireccion> direccion = cliente1.getDireccion();
            //Lo recorro
            for (TipoDireccion tipoDireccion : cliente1.getDireccion()) {
                //Creo una direccion y la meto en mi lista de direcciones para luego metersela al cliente
                listaDirecciones.add(Metodos.crearDireccion(tipoDireccion.getCalle(),
                        tipoDireccion.getNumero(), tipoDireccion.getPiso(), tipoDireccion.getEscalera(),
                        tipoDireccion.getCp(), tipoDireccion.getCiudad()));
            }
            //Metemos en nuestra lista de JsonClientes a un nuevo cliente
            listaClientesJson.add(Metodos.crearClientes(cliente1.getApellido().get(0), cliente1.getApellido().get(1),
                    Metodos.unirDirecciones(listaDirecciones), cliente1.getTelefono()));
        }
        return listaClientesJson;

    }

    /**
     * Método que pasa de jSon a Xml
     *
     * @param documentoJson
     * @param paquete
     * @param xml
     */
    public static void jsontoXml(String documentoJson, String paquete, String xml) {

        //lectura JSON
        JsonReader jsonReader;
        JsonArray datosCliente = null;
        try {
            //"PruebaMetodo.json"
            InputStream fis = new FileInputStream(documentoJson);
            jsonReader = Json.createReader(fis);
            datosCliente = jsonReader.readArray();
            jsonReader.close();
            fis.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        //"jaxb.clientesBinding"        
        GestionJAXB gesJ = new GestionJAXB(paquete);
        //"clientes.xml"
        File documentoXML = new File(xml);

        JAXBElement unMarshall = gesJ.unMarshall(documentoXML);
        Clientes clientes = (Clientes) unMarshall.getValue();

        //CLIENTE
        for (Iterator<JsonValue> itCliente = datosCliente.iterator(); itCliente.hasNext();) {
            List<TipoDireccion> listaDirs = new ArrayList<>();
            JsonObject cliente = (JsonObject) itCliente.next();

            JsonArray direccion = cliente.getJsonArray("direccion");

            if (direccion.size() > 0) {
                for (Iterator<JsonValue> itDir = direccion.iterator(); itDir.hasNext();) {
                    JsonObject datoDir = (JsonObject) itDir.next();
                    listaDirs.add(gesJ.crearDirCliente(datoDir.getString("calle"),
                            datoDir.getString("ciudad"), datoDir.getInt("cp"),
                            datoDir.getString("escalera"), datoDir.getString("numero"),
                            datoDir.getInt("cp")));
                }
            }
            gesJ.annadirClienteDirs(clientes, cliente.getString("apellido1"),
                    cliente.getString("apellido2"), listaDirs, cliente.getString("telefono"), "");
        }

        gesJ.marshall(unMarshall);

    }
}
