package entidades;

public class Televidente {
    
    private long id;
    private String nombre;
    private CadenaTelevisiva cadenaFavorita;

    public Televidente() {
    }

    public Televidente(String nombre, CadenaTelevisiva cadenaFavorita) {
        this.nombre = nombre;
        this.cadenaFavorita = cadenaFavorita;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public CadenaTelevisiva getCadenaFavorita() {
        return cadenaFavorita;
    }

    public void setCadenaFavorita(CadenaTelevisiva cadenaFavorita) {
        this.cadenaFavorita = cadenaFavorita;
    }
    
}
