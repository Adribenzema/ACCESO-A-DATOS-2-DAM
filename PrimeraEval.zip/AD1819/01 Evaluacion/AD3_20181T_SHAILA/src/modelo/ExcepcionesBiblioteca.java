package modelo;

/**
 *
 * @author Shaila
 */
public class ExcepcionesBiblioteca {

    /**
     * Excepcion al Unmarshalizar
     */
    public static class UnmarshalExcepcion extends Throwable {

        public UnmarshalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción al marshalizar
     */
    public static class MarshalExcepcion extends Throwable {

        public MarshalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción No Existe Socio Excepcion
     */
    public static class NoExisteSocioExcepcion extends Throwable {

        public NoExisteSocioExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción fecha incorrecta.
     */
    public static class FechaIncorrectaException extends Throwable {

        public FechaIncorrectaException(String string) {
            super(string);
        }
    }

}
