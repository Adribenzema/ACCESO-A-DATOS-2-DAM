/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Annie
 */
public class ExcepcionesPalabras {

    /**
     * Excepcion al Unmarshalizar
     */
    public static class UnmarshalExcepcion extends Throwable {

        public UnmarshalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción al marshalizar
     */
    public static class MarshalExcepcion extends Throwable {

        public MarshalExcepcion(String string) {
            super(string);
        }
    }

}
