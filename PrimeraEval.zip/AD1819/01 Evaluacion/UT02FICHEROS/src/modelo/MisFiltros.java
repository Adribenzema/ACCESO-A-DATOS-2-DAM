package modelo;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Date;

/**
 *
 * @author Shaila
 */
public class MisFiltros {

    
    
    /**
     * Método que devuelve los nombres de los ficheros multimedia.
     *
     * @param tipo String en el que se pasa el formato de multimedia a buscar.
     * @param ruta String en el que se pasa la ruta en la que se buscan los
     * ficheros.
     */
    public static class FiltroMultimedia implements FilenameFilter {

        String tipo;

        public FiltroMultimedia(String tipo) {
            this.tipo = tipo;
        }

        @Override
        public boolean accept(File file, String name) {
            if (tipo.contentEquals("I")) {
                return name.endsWith(".gif") | name.endsWith(".jpg") | name.endsWith(".tiff");
            }
            if (tipo.contentEquals("V")) {
                return name.endsWith(".avi") | name.endsWith(".mov") | name.endsWith(".mp4");
            }
            return true;
        }
    }

    /**
     * Método que devuelve los nombres de los ficheros documentos.
     *
     * @param tipo String en el que se pasa el formato de documento a buscar.
     * @param ruta String en el que se pasa la ruta en la que se buscan los
     * ficheros.
     */
    public static class FiltroDocumentos implements FilenameFilter {

        String tipo;

        public FiltroDocumentos(String tipo) {
            this.tipo = tipo;
        }

        @Override
        public boolean accept(File file, String name) {
            if (tipo.contentEquals("P")) {
                return name.endsWith(".pdf");
            }
            if (tipo.contentEquals("D")) {
                return name.endsWith(".ODT") | name.endsWith(".OBJ")
                        | name.endsWith(".RTF") | name.endsWith(".TXT ")
                        | name.endsWith(".TXT") | name.endsWith(".DOC");
            }
            return true;
        }
    }

    /**
     * Método que devuelve los nombres de los directorios de la carpeta.
     *
     * @param ruta String en el que se pasa la ruta en la que se buscan los
     * directorios.
     */
    public static class FiltroEsDirectorio implements FilenameFilter {

        @Override
        public boolean accept(File file, String name) {
            File carpetas = new File(file, name);

            return carpetas.isDirectory();
        }
    }

    /**
     * Método que devuelve los nombres de los ficheros de tamaño mayor al
     * especificado.
     *
     * @param minimo long en el que se pasa el tamaño del archivo a buscar.
     * @param ruta String en el que se pasa la ruta en la que se buscan los
     * ficheros.
     */
    public static class FiltroTamanio implements FilenameFilter {

        long minimo;

        public FiltroTamanio(long minimo) {
            this.minimo = minimo;
        }

        @Override
        public boolean accept(File file, String name) {
            File carpetas = new File(file, name);
            return carpetas.length() > minimo;
        }
    }

    /**
     * Método que devuelve los nombres de los ficheros que fueron modificados en
     * las últimas 24 horas.
     *
     * @param ruta String en el que se pasa la ruta en la que se buscan los
     * ficheros
     */
    public static class Filtro24Horas implements FilenameFilter {

        @Override
        public boolean accept(File file, String name) {
            Date fechaHoy = new Date();
            File horas = new File(file, name);
            return ((fechaHoy.getTime() - horas.lastModified()) <= 24 * 3600 * 1000);
        }

    }
}
