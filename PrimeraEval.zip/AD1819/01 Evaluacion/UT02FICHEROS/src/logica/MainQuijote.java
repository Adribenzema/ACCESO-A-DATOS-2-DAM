package logica;

import java.io.IOException;
import modelo.AnalisisQuijote;

/**
 *
 * @author Shaila
 */
public class MainQuijote {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

//quijotePruebas
        System.out.println("El número de líneas del quijote es: "
                + AnalisisQuijote.contarLineas("quijote.txt"));

        System.out.println("El número de palabras del quijote es: "
                + AnalisisQuijote.contarPalabrasDelQuijote("quijote.txt"));

        System.out.println("El número de veces que aparece la palabra quijote es: "
                + AnalisisQuijote.contarPalabraQuijote("quijote.txt","quijote"));
        
        System.out.println("El número de letras que tiene el Quijote es: "
                + AnalisisQuijote.contarLetrasQuijote("quijote.txt"));
        System.out.println("El Quijote al revés: \n"
                + AnalisisQuijote.escribirQuijoteAlReves("quijote.txt"));

           System.out.println("Palabras distintas del Quijote: \n"
                + AnalisisQuijote.mostrarPalabrasDistintas("quijote.txt"));
                   
         System.out.println("El Quijote ha sido dividido en : \n"
                + AnalisisQuijote.dividirCapitulosQuijote("quijotePruebas1.txt","Capitulo")+" capítulos.");
    }

}
