package logica;

import javax.json.JsonObject;
import modelo.JsonMetodosBiblioteca;




/**
 *
 * @author Shaila
 */
public class JSonBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String rutaFichero = "biblioteca.json";
        
        JsonObject jsonObject = JsonMetodosBiblioteca.leerJson(rutaFichero);
      
        
        System.out.println("Map "+JsonMetodosBiblioteca.generarMap(jsonObject));

    }
}
