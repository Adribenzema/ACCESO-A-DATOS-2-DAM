
import entidades.Contacto;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ContactosDAO {

    private Session sesionActual;
    private Transaction tx;

    public ContactosDAO() {
    }

    private void iniciarOperacion() throws HibernateException {
        sesionActual = HibernateSesion.getSessionFactory().openSession();
        tx = sesionActual.beginTransaction();
    }
    
    public void desconectarHibernate() throws HibernateException {
         HibernateSesion.cerrarSesion();
    }
    
    //buscarContacto y obtenerListaContactos son operaciones de consulta y la transacción no ejecuta commit()
    
    public Contacto buscarContacto(long idContacto) {
        Contacto contacto = null;
        
        try {
            iniciarOperacion();
            contacto = (Contacto) sesionActual.get(Contacto.class, idContacto);
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } finally {
            sesionActual.close();
        }
        return contacto;
    }
    
    public List<Contacto> obtenerListaContactos() throws HibernateException {
        List<Contacto> listaContactos = null;
        try {
            iniciarOperacion();
            listaContactos = sesionActual.createQuery("from Contacto").list();
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } finally {
            sesionActual.close();
        }
        return listaContactos;
    }

    //Los tres siguientes métodos sí alteran la BD y por tanto ejecutan un commit() para la transacción
    
    public long crearContacto(Contacto contacto) throws HibernateException {
        long id = 0;
        try {
            iniciarOperacion();
            id = (Long) sesionActual.save(contacto);
            tx.commit();
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } finally {
            sesionActual.close();
        }
        return id;
    }
    
    public void modificarContacto(Contacto contacto) throws HibernateException {
        try {
            iniciarOperacion();
            sesionActual.update(contacto);
            tx.commit();
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } finally {
            sesionActual.close();
        }
    }

    public void eliminarContacto(Contacto contacto) throws HibernateException {
        try {
            iniciarOperacion();
            sesionActual.delete(contacto);
            tx.commit();
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } finally {
            sesionActual.close();
        }
    }

    private void suspenderCambios(HibernateException he) {
        tx.rollback();
        throw new HibernateException("Se ha revertido un error", he);
    }

    
}
