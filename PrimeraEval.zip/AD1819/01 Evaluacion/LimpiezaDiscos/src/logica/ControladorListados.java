package logica;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import modelo.MisExcepcionesPractica;

/**
 *
 * @author Shaila
 */
public class ControladorListados {
    
    private String ruta = "";
    private List<String> listaArchivosTamanio;
    private List<File> listaFicheros;
    private List<String> listaFicherosAntiguos;
    private List<String> listaDirectoriosVacios;
    private List<String> listaArchivosCategoria;
    private static ControladorListados INSTANCE;

    /**
     * Constructor que inicializa las listas.
     */
    public ControladorListados() {
        this.listaArchivosTamanio = new ArrayList<>();
        this.listaFicheros = new ArrayList<>();
        this.listaFicherosAntiguos = new ArrayList<>();
        this.listaDirectoriosVacios = new ArrayList<>();
        this.listaArchivosCategoria = new ArrayList<>();
    }

    /**
     * Para crear una sola instancia de la lógica del negocio.
     *
     * @return INSTANCE
     */
    public static ControladorListados getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ControladorListados();
        }
        return INSTANCE;
    }

    /**
     * Método recursivo que lista los directorios vacíos.
     * @param ruta String con la ruta dónde se va a trabajar.
     * @return List String listado de directorios vacíos.
     * @throws modelo.MisExcepcionesPractica.CarpetaLlena Excepción propia.
     * @throws modelo.MisExcepcionesPractica.NoTieneNada Excepción propia.
     * @throws IOException An input or output exception.
     */
    public List<String> listarDirectoriosVaciosR(String ruta) throws
            MisExcepcionesPractica.CarpetaLlena, MisExcepcionesPractica.NoTieneNada,
            IOException {
        
        File directorios = new File(ruta);
        File[] directoriosListados = directorios.listFiles();
        
        for (File directorio : directoriosListados) {
            if (directorio.isDirectory() && directorio.list().length == 0) {
                listaDirectoriosVacios.add(directorio.getName());
            }
        }
        for (File file : directoriosListados) {
            if (file.isDirectory()) {
                listarDirectoriosVaciosR(file.getAbsolutePath());
            }
        }
        return listaDirectoriosVacios;
        
    }

    /**
     * Método recursivo que lista archivos por categoría.
     *
     * @param ruta String con la ruta dónde se va a trabajar.
     * @param categoria String con la categoría de archivos a eliminar.
     * @param extensionFichero String con la extensión de los archivos a eliminar.
     * @return List String listado de archivos según categoría y extensión.
     * @throws IOException An input or output exception.
     */
    
   
    public List<String> listarFicherosSegunCategoriaR(String ruta, String categoria,
            String extensionFichero) throws IOException {
        
        File ficheroRoot = new File(ruta);
        File[] listaFicheros = ficheroRoot.listFiles();
        
        for (File ficheroExtension : listaFicheros) {
            if (categoria.equalsIgnoreCase("documentos")) {
                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    listaArchivosCategoria.add(ficheroExtension.getName());
                }
            } else if (categoria.equalsIgnoreCase("imagenes")) {
                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    listaArchivosCategoria.add(ficheroExtension.getName());
                }
            } else if (categoria.equalsIgnoreCase("videos")) {
                
                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    listaArchivosCategoria.add(ficheroExtension.getName());
                }
            }
        }
        for (File fichero : listaFicheros) {
            if (fichero.isDirectory()) {
                listarFicherosSegunCategoriaR(fichero.getPath(), categoria,
                        extensionFichero);
            }
        }
        return listaArchivosCategoria;
    }

    
    /**
     * Método que lista archivos de determinada longitud de una ruta introducida
     * por el usuario.
     *
     * @param ruta String con la ruta dónde se va a trabajar.
     * @param tamanio String con el tamaño elegido por el usuario.
     * @return List String listado de archivos según tamaño.
     */
    public List<String> listarFicherosGranTamanioR(String ruta, String tamanio) throws
            IOException {
        
        long tamanioArchivo = 0;
        File ficherosGranTamanio = new File(ruta);
        File[] arrayFicherosGranTamanio = ficherosGranTamanio.listFiles();
        for (File fichero : arrayFicherosGranTamanio) {
            if (tamanio.equalsIgnoreCase("grande")) {
                tamanioArchivo = 50L;
            } else if (tamanio.equalsIgnoreCase("mediano")) {
                tamanioArchivo = 10L;
            } else if (tamanio.equalsIgnoreCase("pequeño")) {
                tamanioArchivo = 2L;
            }
            if (fichero.getTotalSpace() > tamanioArchivo * 1024 / 1024 / 1024) {
                listaArchivosTamanio.add(fichero.getName());
            }
        }
        for (File fichero : arrayFicherosGranTamanio) {
            if (fichero.isDirectory()) {
                listarFicherosGranTamanioR(fichero.getPath(), tamanio);
            }
        }
        return listaArchivosTamanio;
    }
    
    /**
     * Método que lista archivos de determinada fecha de una ruta introducida
     * por el usuario.
     * @param ruta String con la ruta dónde se va a trabajar.
     * @param fechaUsuario Date con la fecha elegida por el usuario.
     * @return List String listado de archivos según categoría y extensión.
     * @throws ParseException
     * @throws IOException An input or output exception.
     */
    public List<String>  listarFicherosAntiguosR(String ruta, Date fechaUsuario) throws
            ParseException, IOException {
        
        File ficherosAntiguos = new File(ruta);
        File[] listaFicheros = ficherosAntiguos.listFiles();
        
        for (File fichero : listaFicheros) {
            if (fichero.lastModified() < fechaUsuario.getTime()) {
                listaFicherosAntiguos.add(fichero.getName());
            }
        }
        for (File fichero : listaFicheros) {
            if (fichero.isDirectory()) {
                listarFicherosAntiguosR(fichero.getPath(), fechaUsuario);
            }
        }
        return listaFicherosAntiguos;
    }
    
}
