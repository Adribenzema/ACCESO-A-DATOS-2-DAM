package modelo;

import javax.xml.bind.JAXBElement;
import jaxb.albaran.Articulos.Articulo;
import jaxb.albaran.PedidoType;

/**
 *
 * @author Shaila
 */
public interface MetodosOperacionesAlbaran {

    public JAXBElement unmarshalDocument(String jaxb, String xml);

    public boolean marshalDocument(JAXBElement jaxbElement);

    public Articulo anadirArticulo(PedidoType pedidoType, int cantidad,
            String codigo, String nombre, int precio, int anio, int mes, int dia);

    public boolean modificarDireccion(PedidoType pedidoType, String nombre,
            String calle, String ciudad, String provincia, String codigoPostal,
            String pais);

    public double calcularImportePedido(PedidoType pedidoType);

    public boolean borrarArticulo(PedidoType pedidoType, String nombre);

    public Articulo anadirArticuloAmpliado(PedidoType pedidoType, int cantidad,
            String codigo, String nombre, int precio, int anio, int mes, int dia);

}
