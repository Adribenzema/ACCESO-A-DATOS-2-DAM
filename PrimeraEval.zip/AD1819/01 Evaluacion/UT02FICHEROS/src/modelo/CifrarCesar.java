package modelo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Shaila
 */
public class CifrarCesar {

    private Map<Character, Integer> mapInformacion = new HashMap();
    private FileInputStream in ;
    private FileOutputStream out ;

    /**
     * Método para cifrar un archivo de texto.
     *
     * @param numeroParaCodificar
     * @param archivoALeer
     * @param archivoCodificar
     * @return
     * @throws IOException
     */
    public int cifrar(int numeroParaCodificar, String archivoALeer, String 
            archivoCodificar) throws IOException {
        int caracteresCifrados = 0;
        try {
            in = new FileInputStream(archivoALeer);
            out = new FileOutputStream(archivoCodificar);
            int c;

            while ((c = in.read()) != -1) {
                out.write(c + numeroParaCodificar);
                caracteresCifrados++;
            }
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        return caracteresCifrados;
    }

    /**
     * Método para descifrar un archivo de texto.
     *
     * @param numeroParaCodificar
     * @param archivoALeer
     * @param archivoAdesCodificar
     * @return
     * @throws IOException
     */
    public int desCifrar(int numeroParaCodificar, String archivoALeer, 
            String archivoAdesCodificar) throws IOException {
        int caracteresdesCifrados = 0;
        try {
            in = new FileInputStream(archivoALeer);
            out = new FileOutputStream(archivoAdesCodificar);
            int c;

            while ((c = in.read()) != -1) {
                out.write(c - numeroParaCodificar);
                caracteresdesCifrados++;
            }
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        return caracteresdesCifrados;
    }
/**
 * Método que cuenta el número de caracteres que hay en un txt.
 * @param archivoALeer
 * @return Map con los caracteres y la cantidad de ellos.
 * @throws IOException 
 */
    public Map<Character, Integer> cuentaCaracteres(String archivoALeer) throws IOException {

        try {
            in = new FileInputStream(archivoALeer);
            int c;
            while ((c = in.read()) != -1) {
                //No me pilla el código ascii extendido
                if ((c>64 && c<91) || (c>96 && c<123) || c==193 || c==225
                        || c==237 || c==243 || c==233 || c==250 || c==200 
                        || c==205 || c==211 || c==218 || c==252 || c==220
                        || c==241 || c==209) {
                    if (!mapInformacion.containsKey((char) c)) {                        
                        mapInformacion.put((char) c, 1);
                    } else {
                        int valorActual = mapInformacion.get((char) c);
                        mapInformacion.put((char) c, valorActual+1);
                    }
                }else if (c==32){
                    System.out.println((char)c+"Es un espacio.");
                }else{
                    System.out.println((char)c+" no es un caracter válido.");
                }
            }
        } finally {
            if (in != null) {
                in.close();
            }
        }
        return mapInformacion;
    }
}
