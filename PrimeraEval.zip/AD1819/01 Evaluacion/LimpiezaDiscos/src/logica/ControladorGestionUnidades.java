package logica;

import java.io.File;
import java.io.IOException;
import java.math.RoundingMode;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import modelo.MisExcepcionesPractica;

/**
 *
 * @author Shaila
 */
public class ControladorGestionUnidades {

    //Atributos
    private String ruta = "";
    private List<File> listaDirectorios;
    private List<File> listaFicheros;
    private List<String> espacioUnidades;

    private static ControladorGestionUnidades INSTANCE;

    /**
     * Constructor que inicializa las listas.
     */
    public ControladorGestionUnidades() {
        this.listaDirectorios = new ArrayList<>();
        this.listaFicheros = new ArrayList<>();
        this.espacioUnidades = new ArrayList<>();
    }

    /**
     * Método para crear una sola instancia de la lógica del negocio.
     *
     * @return INSTANCE
     */
    public static ControladorGestionUnidades getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ControladorGestionUnidades();
        }
        return INSTANCE;
    }

    /**
     * Método para hacer una copia de seguridad de la unidad elegida.
     * @param rutaAcopiar String con la ruta que se va a hacer la copia de seguridad.
     * @param rutaDondeCopiar String con la ruta dónde se va a hacer la copia de seguridad.
     * @return boolean con el resultado de la operación.
     * @throws IOException An input or output exception.
     */

    public boolean copiaDeSeguridadR(String rutaAcopiar, String rutaDondeCopiar)
            throws IOException {

        File fileACopiar = new File(rutaAcopiar);
        File filedondeCopiar = new File(rutaDondeCopiar);

        FileSystem system = FileSystems.getDefault();
        Path aCopiar = null;
        Path dondeCopiar;

        File[] files = fileACopiar.listFiles();
        for (File file : files) {
            if (file.exists()) {
                aCopiar = system.getPath(file.getAbsolutePath());
            }
            dondeCopiar = system.getPath(filedondeCopiar + File.separator + file.getName());

            File test = dondeCopiar.toFile();
            if (!test.exists()) {
                Files.copy(aCopiar, dondeCopiar);
            }
        }

        File dir;
        for (File file : files) {
            if (file.isDirectory()) {
                dir = new File(filedondeCopiar.getAbsolutePath() + File.separator + file.getName());
                dir.mkdir();
                copiaDeSeguridadR(file.getAbsolutePath(), dir.getAbsolutePath());
            }

        }
        return true;
    }

    /**
     * Método para escoger una unidad de disco.
     *
     * @return Arrays de Files con la ruta elegida.
     */
    public File[] seleccionarUnidades() {
        File[] unidades = File.listRoots();
        return unidades;
    }

    /**
     * Método que muestra el espacio libre de las unidades del dispositivo.
     *
     * @return String con el espacio total y disponible en las unidades.
     */
    public List<String> mostrarEspacioLibreUnidad() {

        File[] unidades = File.listRoots();
        String unidad = "";
        float espacioTotal = 0f;
        float tamanioDisponible = 0f;
        for (File f : unidades) {
            unidad = f.getAbsolutePath();
            espacioTotal = (f.getTotalSpace() / 1024 / 1024 / 1024);
            tamanioDisponible = (f.getFreeSpace() / 1024 / 1024 / 1024);
            DecimalFormat df = new DecimalFormat("#.##");
            df.setRoundingMode(RoundingMode.CEILING);
            espacioUnidades.add(unidad + " Espacio Total: " + df.format(espacioTotal)
                    + "(Gb) Espacio Disponible: " + df.format(tamanioDisponible) + "(Gb)");
        }
        return espacioUnidades;

    }

    /**
     * Método recursivo que elimina los directorios vacíos.
     *
     * @param ruta String con la ruta específica donde se va a trabajar.
     * @throws modelo.MisExcepcionesPractica.CarpetaLlena Excepción propia.
     * @throws modelo.MisExcepcionesPractica.NoTieneNada Excepción propia.
     * @throws IOException An input or output exception.
     *
     */
    public void eliminarDirectoriosVaciosR(String ruta) throws
            MisExcepcionesPractica.CarpetaLlena, MisExcepcionesPractica.NoTieneNada,
            IOException {

        File directorios = new File(ruta);
        File[] directoriosListados = directorios.listFiles();
        listaDirectorios = Arrays.asList(directoriosListados);
        for (File directorio : listaDirectorios) {
            if (directorio.isDirectory() && directorio.list().length == 0) {
                directorio.delete();
            }
        }
        for (File file : listaDirectorios) {
            if (file.isDirectory()) {
                eliminarDirectoriosVaciosR(file.getPath());
            }
        }

    }


    /**
     * Método que elimina archivos de determinada extensión de una ruta
     * introducida por el usuario.
     *
     * @param ruta String con la ruta específica donde se va a trabajar.
     * @param categoria String con la categoría de archivos a eliminar.
     * @param extensionFichero String con la extensión de los archivos a eliminar.
     * @throws IOException An input or output exception.
     */
    public void eliminarFicherosSegunCategoriaR(String ruta, String categoria,
            String extensionFichero) throws IOException {

        File ficheroRoot = new File(ruta);
        File[] arrayFicheros = ficheroRoot.listFiles();
        listaFicheros = Arrays.asList(arrayFicheros);

        for (File ficheroExtension : listaFicheros) {
            if (categoria.equalsIgnoreCase("documentos")) {
                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    ficheroExtension.delete();
                }
            } else if (categoria.equalsIgnoreCase("imagenes")) {
                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    ficheroExtension.delete();
                }
            } else if (categoria.equalsIgnoreCase("videos")) {

                if (ficheroExtension.getName().endsWith(extensionFichero)) {
                    ficheroExtension.delete();
                }
            }
        }
        for (File fichero : listaFicheros) {
            if (fichero.isDirectory()) {
                eliminarFicherosSegunCategoriaR(fichero.getPath(), categoria,
                        extensionFichero);
            }
        }
    }

  

    /**
     * Método que elimina archivos de determinada longitud de una ruta
     * introducida por el usuario.
     *
     * @param ruta String con la ruta específica donde se va a trabajar.
     * @param tamanio Long con el tamaño del archivo a eliminar.
     * @throws IOException An input or output exception.
     */
    public void eliminarFicherosGranTamanioR(String ruta, String tamanio) throws
            IOException {

        long tamanioArchivo = 0;
        File ficherosGranTamanio = new File(ruta);

        File[] arrayFicherosGranTamanio = ficherosGranTamanio.listFiles();
        listaFicheros = Arrays.asList(arrayFicherosGranTamanio);

        for (File fichero : listaFicheros) {
            if (tamanio.equalsIgnoreCase("grande")) {
                tamanioArchivo = 50L;
            } else if (tamanio.equalsIgnoreCase("mediano")) {
                tamanioArchivo = 10L;
            } else if (tamanio.equalsIgnoreCase("pequeño")) {
                tamanioArchivo = 2L;
            }
            if (fichero.getTotalSpace() > tamanioArchivo * 1024 / 1024 / 1024) {
                fichero.delete();
            }
        }
        for (File fichero : listaFicheros) {
            if (fichero.isDirectory()) {
                eliminarFicherosGranTamanioR(fichero.getPath(), tamanio);
            }
        }
    }

    /**
     * Método que elimina archivos antiguos de una ruta introducida por el
     * usuario.
     * @param ruta String con la ruta específica donde se va a trabajar.
     * @param fechaUsuario Date con la fecha escogida por el usuario.
     * @throws ParseException It can occur when you fail to parse a String that 
     * is ought to have a special format.
     * @throws IOException An input or output exception.
     */
    public void eliminarFicherosAntiguosR(String ruta, Date fechaUsuario) throws
            ParseException, IOException {

        File ficherosAntiguos = new File(ruta);
        File[] arrayficherosAntiguos = ficherosAntiguos.listFiles();
        listaFicheros = Arrays.asList(arrayficherosAntiguos);

        for (File fichero : listaFicheros) {
            if (fichero.lastModified() < fechaUsuario.getTime()) {
                fichero.delete();
            }
        }
        for (File fichero : listaFicheros) {
            if (fichero.isDirectory()) {
                eliminarFicherosAntiguosR(fichero.getPath(), fechaUsuario);
            }
        }
    }

}
