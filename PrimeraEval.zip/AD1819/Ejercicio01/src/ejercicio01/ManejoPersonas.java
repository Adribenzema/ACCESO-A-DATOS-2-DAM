
package ejercicio01;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Shaila
 */
public class ManejoPersonas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
     
        
        PersonaJDBC personasJDBC = new PersonaJDBC();
	//Prueba del metodo insert
        personasJDBC.insert("Alberto", "Juarez");
        
        //Prueba del metodo update
        //personasJDBC.update(2, "Nombre3", "Apellido3");
		
        //Prueba del metodo delete
        //personasJDBC.delete(1);
      
        //Prueba del metodo select
        //Uso de un objeto persona para encapsular la informacion
        //de un registro de base de datos
        /*List<Persona> personas = personasJDBC.select();
        for (Persona persona : personas) {
        System.out.print(persona);
        System.out.println("");
        }*/
    }}
