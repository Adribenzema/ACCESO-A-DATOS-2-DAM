/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.File;
import javax.xml.bind.JAXBElement;
import jaxb.diccionario2Binding.DiccionarioEspanol;

/**
 *
 * @author Annie
 */
public interface PalabrasInterface {

    public JAXBElement unMarshall(File documentoXML) throws ExcepcionesPalabras.UnmarshalExcepcion;

    public boolean marshall(JAXBElement jaxbElement) throws ExcepcionesPalabras.MarshalExcepcion;

    public String totalSinonimosYtotalAntonimos(DiccionarioEspanol diccionarioEspanol, int posicion);

    public int borrarTodasLasPalabras(DiccionarioEspanol diccionarioEspanol, String cadenaCaracteres);

    public int contarPalabras(DiccionarioEspanol diccionarioEspanol, String palabra);
}
