/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepcionesClientes;

/**
 *
 * @author Annie
 */
public class ExcepcionesClientes {

    /**
     * Excepcion al Unmarshalizar
     */
    public static class UnmarshalExcepcion extends Throwable {

        public UnmarshalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción al marshalizar
     */
    public static class MarshalExcepcion extends Throwable {

        public MarshalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepción Codigo Postal
     */
    public static class CodigoPostalExcepcion extends Throwable {

        public CodigoPostalExcepcion(String string) {
            super(string);
        }
    }

    /**
     * Excepcion numero piso
     */
    public static class PisoIncorrectoException extends Throwable {

        public PisoIncorrectoException(String string) {
            super(string);
        }
    }

    /**
     * Excepcion Caracter invalido (ñ)
     */
    public static class CaracterInvalidoException extends Throwable {

        public CaracterInvalidoException(String string) {
            super(string);
        }
    }
    /**
     * Excepcion tamaño lista direcciones
     */
     public static class NumeroDireccionesExcedidoException extends Throwable {

        public NumeroDireccionesExcedidoException(String string) {
            super(string);
        }
    }
}
