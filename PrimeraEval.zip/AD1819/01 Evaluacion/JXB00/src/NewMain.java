
import java.math.BigInteger;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;
import jaxb.albaran.Articulos;
import jaxb.albaran.PedidoType;

/**
 *
 * @author Shaila
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        JAXBElement jaxbElement = null;
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(args.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
//Quitar la linea que lleva args y poner jaxbElement            
//args = (String[]) unmarshaller.unmarshal(new java.io.File("File path")); //NOI18N
            jaxbElement = (JAXBElement) unmarshaller.unmarshal(new java.io.File("albaran.xsd"));

        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }

        PedidoType pedido = (PedidoType) jaxbElement.getValue();
        //Alt enter para que salga la parte derecha, la variable
        XMLGregorianCalendar fechaPedido = pedido.getFechaPedido();

        //Conversiones 
        BigInteger eon = fechaPedido.getEon();
        long longValueEON = eon.longValue();
        BigInteger bigInteger = BigInteger.valueOf(longValueEON);

        //String comentario = pedido.getComentario();
        pedido.setComentario(pedido.getComentario() + " :Antiguo.");

        Articulos articulos = pedido.getArticulos();
        List<Articulos.Articulo> listaArticulo = articulos.getArticulo();

        Articulos.Articulo articuloPrimero = listaArticulo.get(0);

        String codigoArticuloPrimero = articuloPrimero.getCodigo();

        Articulos.Articulo articuloSegundo = listaArticulo.get(1);
        articuloSegundo.setCodigo(codigoArticuloPrimero);
        articuloSegundo.setCodigo(articuloPrimero.getCodigo());
        articuloSegundo.setCodigo(listaArticulo.get(0).getCodigo());//PRO

        int totalCantidad = 0;
        for (Articulos.Articulo articulo : listaArticulo) {

            totalCantidad += articulo.getCantidad();
            articulo.setCantidad(articulo.getCantidad()-1);
        }

        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(args.getClass().getPackage().getName());
            javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8"); //NOI18N
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(args, System.out);
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }

    }

}
