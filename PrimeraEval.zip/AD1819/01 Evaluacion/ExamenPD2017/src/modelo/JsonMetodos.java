package modelo;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;

/**
 *
 * @author Shaila
 */
public class JsonMetodos {

    /**
     * Método para leer un fichero Json al que se le pasa por parámetro dicho
     * fichero.
     *
     * @param documentoJson
     * @return un objeto JsonObject.
     */
    public static JsonObject leerJson(String documentoJson) {
        JsonObject diccionarioEspanol = null;
        try {
            JsonReader jsonReader;

            InputStream fis = new FileInputStream(documentoJson);
            jsonReader = Json.createReader(fis);
            diccionarioEspanol = jsonReader.readObject();

            jsonReader.close();

            fis.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return diccionarioEspanol;

    }

    /**
     * Método que calcula el total de sinónimos y antónimos de una determinada
     * palabra
     *
     * @param jsonObject
     * @param palabraDeterminada
     * @return
     */
    public static String contarTotalSinonimosYAntonimos(JsonObject jsonObject, String palabraDeterminada) {
        String totalSinonimosAntonimos = null;
        int contadorSinonimos = 0;
        int contadorAntonimos = 0;

        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").getJsonObject("palabras").getJsonArray("palabra");

        //FOR para SINONIMOS
        for (int i = 0; i < jsonArray.size(); i++) {
            JsonArray listaSINONIMO = jsonArray.getJsonObject(i).getJsonObject("sinonimos").getJsonArray("sinonimo");

            for (int j = 0; j < listaSINONIMO.size(); j++) {
                String grafia = listaSINONIMO.getJsonObject(j).getString("grafia");
                System.out.println(grafia);
                if (grafia.equalsIgnoreCase(palabraDeterminada)) {
                    contadorSinonimos++;
                }
            }
        }

        //FOR para ANTONIMOS
        for (int l = 0; l < jsonArray.size(); l++) {
            JsonArray listaAntonimo = jsonArray.getJsonObject(l).getJsonObject("antonimos").getJsonArray("antonimo");

            for (int k = 0; k < listaAntonimo.size(); k++) {
                String grafia = listaAntonimo.getJsonObject(k).getString("grafia");
                System.out.println(grafia);
                if (grafia.equalsIgnoreCase(palabraDeterminada)) {
                    contadorAntonimos++;
                }
            }

        }

        totalSinonimosAntonimos = "Sinonimos " + contadorSinonimos + "\n" + "Antonimos " + contadorAntonimos;

        return totalSinonimosAntonimos;
    }

    /**
     * Método que genera un Map con la grafía de la palabra y el total de
     * sinónimos con porcentaje de similitud superior a 80%.
     *
     * @param jsonObject
     * @return
     */
    public static Map<String, Integer> generarGrafia(JsonObject jsonObject) {

        Map<String, Integer> informacionGrafia = new HashMap<>();
//Creamos un jsonArray de palabras que es con lo que vamos a trabajar
        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").getJsonObject("palabras").getJsonArray("palabra");

        for (int i = 0; i < jsonArray.size(); i++) {
            int totalsinonimos = 0;
            //Meto en un JsonArray con lo que voy a trabajar
            JsonArray JAsinonimos = jsonArray.getJsonObject(i).getJsonObject("sinonimos").getJsonArray("sinonimo");
            for (int j = 0; j < JAsinonimos.size(); j++) {
                if (JAsinonimos.getJsonObject(i).getJsonNumber("porcentajeSimilitud").longValue() > 0.8) {
                    totalsinonimos++;
                }
            }
            informacionGrafia.put(jsonArray.getJsonObject(i).getString("grafia"), totalsinonimos);
        }
        return informacionGrafia;

    }

    /**
     * Método para crear un Fichero Json.
     *
     * @param rutaFichero
     * @param diccionarios
     */
    public static void crearFichero(String rutaFichero, JsonArrayBuilder diccionarios) {

        JsonArray arrayJsonLibros = diccionarios.build();

        FileWriter ficheroSalida = null;
        try {
            ficheroSalida = new FileWriter(rutaFichero);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        JsonWriter jsonWriter = Json.createWriter(ficheroSalida);
        jsonWriter.writeArray(arrayJsonLibros);
        try {
            ficheroSalida.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        try {
            ficheroSalida.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    /**
     * Método para crear un JsonArrayBuilder de palabras.
     *
     * @param listapalabras
     * @return
     */
    public static JsonArrayBuilder crearArrayPalabras(List<JsonObject> listapalabras) {

        JsonArrayBuilder createArrayBuilder = Json.createArrayBuilder();
        for (JsonObject listapalabra : listapalabras) {
            createArrayBuilder.add(listapalabra);
        }
        return createArrayBuilder;
    }

    /**
     * Método para generar Json.
     *
     * @param jsonObject
     * @param documentoJson
     */
    public static void generarJson3D(JsonObject jsonObject, String documentoJson) {
        List<JsonObject> listapalabras = new ArrayList();
        JsonArray jsonArray = jsonObject.getJsonObject("diccionarioEspanol").
                getJsonObject("palabras").getJsonArray("palabra");

        for (int i = 0; i < jsonArray.size(); i++) {
            String string = jsonArray.getJsonObject(i).getString("fechaInsercion");
            String[] split = string.split("-");
            Date date = new Date();
            int res = Integer.parseInt(split[2]) - date.getDate();
            if (res < 3) {

                listapalabras.add(jsonArray.getJsonObject(i));
            }

        }

        crearFichero(documentoJson, crearArrayPalabras(listapalabras));
    }

}
