package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author Shaila
 */
@Entity
@Table(name = "sucursal")
public class Sucursal implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Para que autogenere el id
    private long id;

    private int numero;
    private String telefono;
    private String email;
    private String fax;

    /*si el dibujo me trae bidireccional significal que tengo que tener un 
    objeto sucursal en cliente y viceversa*/
    //Bidireccional
    //@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "persona") mappedBy no se si se pone
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)//para cargar los datos el eager, es más lento porque carga todos los datos
    private List<Cliente> listaDeClientes = new ArrayList<>();

    //Unidireccional --> metemos el objeto donde apunte la flecha
    @OneToOne(cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    private Direccion direccion;

    public Sucursal() {
    }

    public Sucursal(int numero, String telefono, String email, String fax) {
        this.numero = numero;
        this.telefono = telefono;
        this.email = email;
        this.fax = fax;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public List<Cliente> getListaDeClientes() {
        return listaDeClientes;
    }

    public void setListaDeClientes(List<Cliente> listaDeClientes) {
        this.listaDeClientes = listaDeClientes;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
