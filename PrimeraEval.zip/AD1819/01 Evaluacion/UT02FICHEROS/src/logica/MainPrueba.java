package logica;

import java.io.File;
import java.util.ArrayList;
import modelo.OperacionesFicheros;

/**
 *
 * @author Shaila
 */
public class MainPrueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] lista = null;
        File[] archivos = null;
        OperacionesFicheros of = new OperacionesFicheros();

        ArrayList<String> listaDirectorios = new ArrayList<String>();

        listaDirectorios.add("Nueva");
        listaDirectorios.add("Vacia");
        listaDirectorios.add("Prueba");
        //cambiar ruta
        File ruta = new File("C:\\Users\\Shaila\\Downloads\\WEB");
        System.out.println(of.crearDirectorio(ruta, listaDirectorios));
        String ruta1 = "C:\\Users\\Shaila\\Downloads\\WEB";
        System.out.println("\nRecursivo");
        of.listarRecursivoFicheros(ruta1);
    }

}
