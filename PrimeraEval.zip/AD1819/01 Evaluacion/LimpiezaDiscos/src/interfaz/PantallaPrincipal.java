package interfaz;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import logica.ControladorGestionUnidades;

/**
 *
 * @author Shaila
 */
public class PantallaPrincipal extends javax.swing.JFrame {
    
    private static final String RUTA_LOGO = ".."+File.separator+"imgs"+File.separator+"images.jpg";
    private String seleccionUnidadParaTrabajar;

    /**
     * Creates new form PantallaPrincipal
     */
    public PantallaPrincipal() throws ParseException {
        initComponents();
        //cambiarLookAndFeel();
        //Establecer el título de la aplicación
        setTitle("LIMPIEZA DE UNIDADES");
        ControladorGestionUnidades.getInstance();
        //Establecer una imagen en una label
        jLabelIcono.setIcon(new ImageIcon(getClass().getResource(RUTA_LOGO)));
        //Establecer el logo del a aplicación
        setIconImage(new ImageIcon(getClass().getResource(RUTA_LOGO)).getImage());
        setLocationRelativeTo(null);
        jButtonAnalizarUnidad.setText("<html><p>ANALIZAR</p> "
                + "<p>UNIDADES</p></html>");
        jButtonCopiaSeguridad.setText("<html><p>COPIA DE</p> "
                + "<p>SEGURIDAD</p></html>");
        jButtonEspacioDisco.setText("<html><p>ESPACIO</p> "
                + "<p>EN DISCO</p></html>");
        jLabelTexto.setText("<html><p>SELECCIONE</p> "
                + "<p>UNIDAD</p></html>");
        rellenarCombo();
        
    }
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelPantallaPrincipal = new javax.swing.JPanel();
        jButtonSalirDelTodo = new javax.swing.JButton();
        jButtonEspacioDisco = new javax.swing.JButton();
        jLabelTexto = new javax.swing.JLabel();
        jLabelIcono = new javax.swing.JLabel();
        jComboBoxUnidades = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListEspacioDisco = new javax.swing.JList<>();
        jButtonAnalizarUnidad = new javax.swing.JButton();
        jButtonCopiaSeguridad = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonSalirDelTodo.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalirDelTodo.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonSalirDelTodo.setText("SALIR");
        jButtonSalirDelTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirDelTodoActionPerformed(evt);
            }
        });

        jButtonEspacioDisco.setBackground(new java.awt.Color(204, 204, 255));
        jButtonEspacioDisco.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonEspacioDisco.setText("ESPACIO EN DISCO");
        jButtonEspacioDisco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEspacioDiscoActionPerformed(evt);
            }
        });

        jLabelTexto.setFont(new java.awt.Font("Dialog", 3, 14)); // NOI18N
        jLabelTexto.setText("Seleccione unidad");

        jComboBoxUnidades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxUnidadesActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(jListEspacioDisco);

        jButtonAnalizarUnidad.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAnalizarUnidad.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonAnalizarUnidad.setText("ANALIZAR UNIDADES");
        jButtonAnalizarUnidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAnalizarUnidadActionPerformed(evt);
            }
        });

        jButtonCopiaSeguridad.setBackground(new java.awt.Color(204, 204, 255));
        jButtonCopiaSeguridad.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonCopiaSeguridad.setText("COPIA DE SEGURIDAD");
        jButtonCopiaSeguridad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCopiaSeguridadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelPantallaPrincipalLayout = new javax.swing.GroupLayout(jPanelPantallaPrincipal);
        jPanelPantallaPrincipal.setLayout(jPanelPantallaPrincipalLayout);
        jPanelPantallaPrincipalLayout.setHorizontalGroup(
            jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelPantallaPrincipalLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelPantallaPrincipalLayout.createSequentialGroup()
                        .addGroup(jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBoxUnidades, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonEspacioDisco, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabelIcono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanelPantallaPrincipalLayout.createSequentialGroup()
                        .addComponent(jButtonAnalizarUnidad, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jButtonCopiaSeguridad, javax.swing.GroupLayout.PREFERRED_SIZE, 122, Short.MAX_VALUE)
                        .addGap(15, 15, 15)
                        .addComponent(jButtonSalirDelTodo, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );
        jPanelPantallaPrincipalLayout.setVerticalGroup(
            jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelPantallaPrincipalLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelPantallaPrincipalLayout.createSequentialGroup()
                        .addComponent(jLabelTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxUnidades, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(jButtonEspacioDisco, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabelIcono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(jPanelPantallaPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonCopiaSeguridad, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                    .addComponent(jButtonAnalizarUnidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonSalirDelTodo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanelPantallaPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanelPantallaPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
/**/
    private void jButtonSalirDelTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirDelTodoActionPerformed
        //setVisible(false);        
        this.dispose();
        System.exit(0);//Este usarlo para salir porque el dispose me deja una pantalla.
    }//GEN-LAST:event_jButtonSalirDelTodoActionPerformed

    private void jButtonEspacioDiscoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEspacioDiscoActionPerformed
        DefaultListModel dlm = new DefaultListModel();
        for (String u : ControladorGestionUnidades.getInstance().mostrarEspacioLibreUnidad()) {
            dlm.addElement(u);
            jListEspacioDisco.setModel(dlm);
        }

    }//GEN-LAST:event_jButtonEspacioDiscoActionPerformed

    private void jComboBoxUnidadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxUnidadesActionPerformed

    }//GEN-LAST:event_jComboBoxUnidadesActionPerformed

    private void jButtonCopiaSeguridadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCopiaSeguridadActionPerformed
        
        try {
            seleccionUnidadParaTrabajar = jComboBoxUnidades.getSelectedItem().toString();
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setMultiSelectionEnabled(false);
            int returnSelection = chooser.showOpenDialog(null);
            
            if (returnSelection == JFileChooser.APPROVE_OPTION) {
                String seleccionUnidadParaCopia = chooser.getSelectedFile().getAbsolutePath();
                JOptionPane.showMessageDialog(this, "Ha elegido " + seleccionUnidadParaCopia + "\n para realizar una copia de seguridad.");
                File filedondeCopiar = new File(seleccionUnidadParaCopia + File.separator + "copia_de_seguridad");
                if (!filedondeCopiar.exists()) {
                    filedondeCopiar.mkdir();
                    if (ControladorGestionUnidades.getInstance().copiaDeSeguridadR(
                            seleccionUnidadParaTrabajar, filedondeCopiar.getAbsolutePath())) {
                        JOptionPane.showMessageDialog(this, "COPIA REALIZADA CON ÉXITO.");
                    } else {
                        JOptionPane.showMessageDialog(this, "COPIA NO REALIZADA CON ÉXITO.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "LA CARPETA YA EXISTE, ESCOJA OTRA RUTA.");
                }
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }//GEN-LAST:event_jButtonCopiaSeguridadActionPerformed

    private void jButtonAnalizarUnidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAnalizarUnidadActionPerformed
        seleccionUnidadParaTrabajar = jComboBoxUnidades.getSelectedItem().toString();
        Acciones confirmacionValidar
                = new Acciones(new javax.swing.JFrame(), true, seleccionUnidadParaTrabajar);
        confirmacionValidar.setVisible(true);

    }//GEN-LAST:event_jButtonAnalizarUnidadActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                try {
                    new PantallaPrincipal().setVisible(true);
                } catch (ParseException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAnalizarUnidad;
    private javax.swing.JButton jButtonCopiaSeguridad;
    private javax.swing.JButton jButtonEspacioDisco;
    private javax.swing.JButton jButtonSalirDelTodo;
    private javax.swing.JComboBox<String> jComboBoxUnidades;
    private javax.swing.JLabel jLabelIcono;
    private javax.swing.JLabel jLabelTexto;
    private javax.swing.JList<String> jListEspacioDisco;
    private javax.swing.JPanel jPanelPantallaPrincipal;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void rellenarCombo() {
        File[] listarUnidades = ControladorGestionUnidades.getInstance().seleccionarUnidades();
        for (File files : listarUnidades) {
            jComboBoxUnidades.addItem(files.getAbsolutePath());
            
        }
        
    }
    
}
