package logica;

import java.io.IOException;
import java.util.Map;
import modelo.CifrarCesar;


/**
 *
 * @author Shaila
 */
public class MainPruebaCesar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        CifrarCesar modelo = new CifrarCesar();
        /*        System.out.println("Introduzca el número entero para codificar: ");
        int numeroParaCodificar = Leer.datoInt();
        System.out.println("Introduzca el nombre del fichero a codificar: ");
        String nombreArchivoACodificar = Leer.leerDato();
        System.out.println("Introduzca el nombre del fichero a descodificar: ");
        String nombreArchivoCodificado = Leer.leerDato();

        nombreArchivoACodificar=nombreArchivoACodificar+".txt";
        nombreArchivoCodificado=nombreArchivoCodificado+".txt";
        
        System.out.println("El número de caracteres codificados es:"+
        modelo.cifrar(numeroParaCodificar, nombreArchivoACodificar,
        nombreArchivoCodificado));
        System.out.println("Elemento: "+modelo.cuentaCaracteres(nombreArchivoACodificar));*/
        
        modelo.cifrar(3, "./sinCodificar.txt","./Codificado.txt");
        modelo.desCifrar(3, "./Codificado.txt","./desCodificado.txt");
        Map<Character, Integer> mapaCuentaCaracteres = modelo.cuentaCaracteres("./sinCodificar.txt");
        System.out.println(mapaCuentaCaracteres);
    }

}
