package modelo;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import jaxb.albaran.Articulos;
import jaxb.albaran.Articulos.Articulo;
import jaxb.albaran.Direccion;
import jaxb.albaran.ObjectFactory;
import jaxb.albaran.PedidoType;

/**
 *
 * @author Shaila
 */
public class OperacionesAlbaran implements MetodosOperacionesAlbaran {

//Atributos
    private static ObjectFactory objectFactory;
    private static OperacionesAlbaran INSTANCE;
    private double totalImportePedido;

    /**
     * Método para crear una sola instancia de la lógica del negocio.
     *
     * @return INSTANCE
     */
    public static OperacionesAlbaran getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OperacionesAlbaran();
        }
        return INSTANCE;
    }

    /**
     * Método para Unmarshalizar un documento XML.
     *
     * @param jaxbAlbaran String con el paquete jaxb.albaran
     * @param xml String con el XML albaran.xml
     * @return JAXBElement jaxbElement.
     */
    @Override
    public JAXBElement unmarshalDocument(String jaxb, String xml) {
        JAXBElement jaxbElement = null;
        javax.xml.bind.JAXBContext jaxbCtx = null;
        try {
            jaxbCtx = javax.xml.bind.JAXBContext.newInstance(jaxb);
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = (JAXBElement) unmarshaller.unmarshal(new java.io.File(xml)); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }

        return jaxbElement;

    }

    /**
     * Método para Marshalizar un documento XML.
     *
     * @param jaxbElement JAXBElement
     * @return boolean con el resultado de la operación.
     */
    @Override
    public boolean marshalDocument(JAXBElement jaxbElement) {

        try {
            javax.xml.bind.JAXBContext jaxbCtx = null;
            // Crear un objeto de tipo Marshaller para posteriormente convertir un
            // el árbol de objetos Java a datos XML
            Marshaller m = jaxbCtx.createMarshaller();

            // El método setProperty(String nombrePropiedad, Object value) recibe en este
            // caso la propiedad "jaxb.formatted.output". Esta propiedad controla si al
            // realizar un marshal, debe formatear el resultado XML con saltos de linea
            // e indentaciones para que las personas podamos leerlo cómodamente. Por defecto
            // su valor es falso es decir el XML creado no está formateado
            // El argumento value en este caso tiene que ser concretamente de tipo Boolean
            // para indicar si queremos que el resultado XML esté formateado o no
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            // El método marshall(Object elementoJAXB, OutputStream os) recibe un objeto
            // de tipo JAXBElement para que su contenido lo muestre en la salida estándar
            // debido a que este método está sobrecargo, si miramos la documentación de
            //la API podemos ver como podemos mostrar o escribir el resultado XML de
            //diferentes maneras
            m.marshal(jaxbElement, System.out);

        } catch (JAXBException ex) {
            Logger.getLogger(OperacionesAlbaran.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    /**
     * Añadir Articulo: Añade un articulo en el pedido.
     *
     * @param pedidoType PedidoType pedidoType.
     * @param cantidad int cantidad.
     * @param codigo String codigo.
     * @param nombre String nombre.
     * @param precio int precio.
     * @param anio int anio.
     * @param mes int mes.
     * @param dia int dia.
     * @return Articulo.
     */
    @Override
    public Articulo anadirArticulo(PedidoType pedidoType, int cantidad,
            String codigo, String nombre, int precio, int anio, int mes, int dia) {
        objectFactory = new ObjectFactory();

        Articulo articuloNuevo = objectFactory.createArticulosArticulo();
        articuloNuevo.setCantidad(cantidad);
        articuloNuevo.setCodigo(codigo);
        articuloNuevo.setNombreProducto(nombre);
        articuloNuevo.setPrecio(new BigDecimal(precio));

        try {
            XMLGregorianCalendar fecha = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            fecha.setYear(anio);
            fecha.setMonth(mes);
            fecha.setDay(dia);
            articuloNuevo.setFechaEnvio(fecha);
        } catch (DatatypeConfigurationException ex) {
            System.err.println("DatatypeConfigurationException");
        }

        Articulos articulos = pedidoType.getArticulos();
        List<Articulos.Articulo> listaArticulos = articulos.getArticulo();
        try {
            listaArticulos.add(articuloNuevo);

        } catch (UnsupportedOperationException e) {
            System.err.println("UnsupportedOperationException");
        } catch (NullPointerException e) {
            System.err.println("NullPointerException");
        } catch (IllegalArgumentException e) {
            System.err.println("IllegalArgumentException");
        }

        return articuloNuevo;

    }

    /**
     * Método para modificar una dirección de un pedido.
     *
     * @param pedidoType PedidoType pedidoType.
     * @param nombre String nombre.
     * @param pais String pais.
     * @param calle String calle.
     * @param ciudad String ciudad.
     * @param provincia String provincia.
     * @param codigoPostal String codigoPostal.
     * @return true si la operación ha sido satisfactoria.
     */
    @Override
    public boolean modificarDireccion(PedidoType pedidoType, String nombre,
            String pais, String calle, String ciudad, String provincia, String codigoPostal) {

        Direccion direccion = pedidoType.getFacturarA();
        // Establecemos los datos
        direccion.setNombre(nombre);
        direccion.setCalle(calle);
        direccion.setCiudad(ciudad);
        direccion.setProvincia(provincia);
        direccion.setCodigoPostal(new BigDecimal(codigoPostal));
        direccion.setPais(pais);

        pedidoType.setFacturarA(direccion);

        return true;
    }

    /**
     * Método para calcular el importe del pedido.
     *
     * @param pedidoType PedidoType.
     * @return totalImportePedido double con el importe total de los articulos.
     */
    @Override
    public double calcularImportePedido(PedidoType pedidoType) {
        Articulos articulos = pedidoType.getArticulos();
        List<Articulos.Articulo> listaArticulos = articulos.getArticulo();

        for (int i = 0; i < listaArticulos.size(); i++) {
            BigDecimal precioArticulos = listaArticulos.get(i).getPrecio();
            double precioArticulosDouble = precioArticulos.doubleValue();
            totalImportePedido += (listaArticulos.get(i).getCantidad() * precioArticulosDouble);

        }

        return totalImportePedido;
    }

    /**
     * Método para borrar un artículo a partir del nombre del artículo.
     *
     * @param pedidoType PedidoType.
     * @param nombre del artículo que queremos borrar.
     * @return true si la operación ha sido satisfactoria.
     */
    @Override
    public boolean borrarArticulo(PedidoType pedidoType, String nombre) {
        Articulos articulos = pedidoType.getArticulos();
        List<Articulos.Articulo> listaArticulos = articulos.getArticulo();
        if (listaArticulos.contains(nombre)) {
            listaArticulos.remove(nombre);

        } else {
            try {
                throw new ExcepcionesAlbaran.NoExisteElProducto("No "
                        + "existe el producto especificado.");
            } catch (ExcepcionesAlbaran.NoExisteElProducto ex) {
                System.out.println(ex.getMessage());
            }
        }
        return true;
    }

    /**
     * Añadir Articulo: Añade un articulo en el pedido controlando que la fecha
     * sea correcta.
     *
     * @param pedidoType PedidoType pedidoType.
     * @param cantidad int cantidad.
     * @param codigo String codigo.
     * @param nombre String nombre.
     * @param precio int precio.
     * @param anio int anio.
     * @param mes int mes.
     * @param dia int dia.
     * @return Articulo.
     */
    @Override
    public Articulo anadirArticuloAmpliado(PedidoType pedidoType, int cantidad,
            String codigo, String nombre, int precio, int anio, int mes, int dia) {

        objectFactory = new ObjectFactory();

        Articulo articuloNuevo = objectFactory.createArticulosArticulo();
        articuloNuevo.setCantidad(cantidad);
        articuloNuevo.setCodigo(codigo);
        articuloNuevo.setNombreProducto(nombre);
        articuloNuevo.setPrecio(new BigDecimal(precio));

        try {
            XMLGregorianCalendar fecha = DatatypeFactory.newInstance().newXMLGregorianCalendar();
            fecha.setYear(anio);
            fecha.setMonth(mes);
            fecha.setDay(dia);
            //Meter como parámetro un gregorian calendar
            /**
             * ... para meter por ejemplo varias direcciones, lo considera como
             * un array y siempre poner al final y adán me acaba de salvar la
             * vida
             */
            if ((fecha.getDay() < 1 && fecha.getDay() > 31) || (fecha.getMonth() < 1
                    && fecha.getMonth() > 12) || (fecha.getYear() < 1989 && fecha.
                    getYear() > 2030)) {
                try {
                    throw new ExcepcionesAlbaran.ErrorFecha("La fecha no es correcta.");
                } catch (ExcepcionesAlbaran.ErrorFecha ex) {
                    System.out.println(ex.getMessage());
                }
            } else {
                articuloNuevo.setFechaEnvio(fecha);
            }
        } catch (DatatypeConfigurationException ex) {
            System.err.println("DatatypeConfigurationException");
        }

        Articulos articulos = pedidoType.getArticulos();
        List<Articulos.Articulo> listaArticulos = articulos.getArticulo();
        try {
            listaArticulos.add(articuloNuevo);

        } catch (UnsupportedOperationException e) {
            System.err.println("UnsupportedOperationException");
        } catch (NullPointerException e) {
            System.err.println("NullPointerException");
        } catch (IllegalArgumentException e) {
            System.err.println("IllegalArgumentException");
        }

        return articuloNuevo;

    }

}
