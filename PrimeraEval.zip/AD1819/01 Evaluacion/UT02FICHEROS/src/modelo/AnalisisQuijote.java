
package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.stream.Stream;

/**
 *
 * @author Shaila
 */
public class AnalisisQuijote {

    /**
     * Método que pasando una ruta cuenta las líneas que tiene un archivo.
     *
     * @param archivo
     * @return
     * @throws FileNotFoundException
     */
    public static int contarLineas(String archivo) throws FileNotFoundException {

        BufferedReader entrada = new BufferedReader(new FileReader(archivo));
        int contadorLineas = 0;
        Stream<String> lines = entrada.lines();
        contadorLineas = (int) lines.count();
        return contadorLineas;
    }

    /**
     * Método que pasando una ruta cuenta las palabras que tiene un archivo.
     *
     * @param archivo
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static int contarPalabrasDelQuijote(String archivo) throws
            FileNotFoundException, IOException {
        String linea = "";
        int numeroPalabrasQuijote = 0;
        //Escribir for control + espacio
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        // Lectura del fichero
        while ((linea = br.readLine()) != null) {
            numeroPalabrasQuijote += linea.split("\\s+|\\n|,").length;
        }
        return numeroPalabrasQuijote;
    }

    /**
     * Método que pasando una ruta y una palabra a buscar cuenta las veces que
     * aparece dicha palabra en el archivo.
     *
     * @param archivo
     * @param palabraBuscar
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static int contarPalabraQuijote(String archivo, String palabraBuscar)
            throws FileNotFoundException, IOException {
        String linea = "";
        int numeroPalabrasQuijote = 0;
        //Escribir for control + espacio
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        // Lectura del fichero
        while ((linea = br.readLine()) != null) {
            String lineaMinusculas = linea.toLowerCase();
//Si en la misma línea aparece dos veces la misma palabra no cuenta la segunda
            if (lineaMinusculas.contains(palabraBuscar)) {
                numeroPalabrasQuijote++;
            }
        }
        return numeroPalabrasQuijote;
    }

    /**
     * Método que pasando una ruta cuenta el número de letras del archivo.
     *
     * @param archivo
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static int contarLetrasQuijote(String archivo) throws
            FileNotFoundException, IOException {
        String linea = "";
        int numeroLetrasQuijote = 0;
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        // Lectura del fichero
        while ((linea = br.readLine()) != null) {

            for (int i = 0; i < linea.length(); i++) {
                if (Character.isAlphabetic(linea.charAt(i))) {

                    numeroLetrasQuijote++;
                }
            }
        }
        return numeroLetrasQuijote;
    }

    /**
     *
     * @param archivo
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<String> escribirQuijoteAlReves(String archivo)
            throws FileNotFoundException, IOException {

        String linea = "";
        ArrayList<String> textoAlreves = new ArrayList<>();
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        FileWriter fw = new FileWriter("archivoReves.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        // Lectura del fichero

        while ((linea = br.readLine()) != null) {
            StringBuilder builder = new StringBuilder(linea);
            StringBuilder ta = builder.reverse();
            textoAlreves.add(ta.toString());
        }

        for (String texto : textoAlreves) {
            bw.write(texto);
        }
        bw.flush();
        bw.close();

        return textoAlreves;
    }

    /**
     * Método para mostrar la cantidad de palabras distintas del Quijote.
     *
     * @param archivo
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static Map<String, Integer> mostrarPalabrasDistintas(String archivo)
            throws FileNotFoundException, IOException {

        Map<String, Integer> contarPalabras = new HashMap<>();
        String linea = "";
        FileReader fr = new FileReader(archivo);
        BufferedReader br = new BufferedReader(fr);

        // Lectura del fichero
        while ((linea = br.readLine()) != null) {
            String[] palabrasMinusculas = linea.toLowerCase().split("\\s+|\\n|,|;");
            List<String> lista = Arrays.asList(palabrasMinusculas);

            for (int i = 0; i < lista.size(); i++) {
                if (!contarPalabras.containsKey(lista.get(i))) {
                    contarPalabras.put(lista.get(i), 1);
                } else if (contarPalabras.containsKey(lista.get(i).equals(" "))) {
                    contarPalabras.remove(lista.get(i));
                } else {
                    int valorActual = contarPalabras.get(lista.get(i));
                    contarPalabras.put(lista.get(i), valorActual + 1);
                }
            }
        }

        return contarPalabras;

    }

    public static int dividirCapitulosQuijote(String archivo, String palabra)
            throws FileNotFoundException, IOException {

        int contarCapitulos = 0;
        String linea = "";

        BufferedReader br = new BufferedReader(new FileReader(archivo));
        BufferedWriter bw = new BufferedWriter(new FileWriter(palabra + contarCapitulos + ".txt"));
        // Lectura del fichero

        while ((linea = br.readLine()) != null) {

            System.out.println(linea + "\n");

            bw.write(linea + "\n");
            if (linea.contains(palabra)) {

                contarCapitulos++;
                bw = new BufferedWriter(new FileWriter(palabra + "_" + contarCapitulos + ".txt"));

                bw.write(linea + "\n");
            }
            linea = br.readLine();
        }
        bw.close();
        return contarCapitulos;

    }
}
