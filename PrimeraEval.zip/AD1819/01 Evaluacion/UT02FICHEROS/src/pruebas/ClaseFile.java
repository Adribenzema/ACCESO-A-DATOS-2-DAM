package pruebas;

import java.io.*;

/**
 *
 * @author Shaila
 */
public class ClaseFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //File archivo = new File("ejemplo_archivo");
        File archivo = new File("bin");

        //mostrar la ruta absoluta del archivo
        System.out.println(archivo.getAbsolutePath());

        //mirar si existe una carpeta
        System.out.println("Existe el archivo ejemplo_archivo: "
                + archivo.exists());
        
        System.out.println("Hola");
        //programa que entre en una carpeta y mire lo que hay
        File ruta = new File("C:\\Users\\Shaila\\Downloads\\WEB");

        System.out.println(ruta.getAbsolutePath());

        //List devuelve un array de Strings con los nombres y directorios de la ruta especificada
        //si hay un directorio dentro que nos diga lo que tiene
        String[] nombresArchivos = ruta.list();
        for (int i = 0; i < nombresArchivos.length; i++) {
            System.out.println(nombresArchivos[i]);
            File nuevaRuta = new File(ruta.getAbsolutePath(), nombresArchivos[i]);

            if (nuevaRuta.isDirectory()) {
                String[] nombresArchivosSubcarpetas = ruta.list();
                for (int j = 0; j < nombresArchivosSubcarpetas.length; j++) {
                    System.out.println(nombresArchivosSubcarpetas[j]);

                }
            }
        }
        System.out.println("Hola");
        //crear un nuevo directorio C:\Users\Shaila\Downloads\WEB
        //para asegurarte compatibilidad con otros SO
        File rutas = new File("C:" + File.separator + "Users" + File.separator
                + "Shaila" + File.separator + "Downloads" + File.separator + "WEB"
                + File.separator + "crearCarpeta");
        //para crear un nuevo directorio mkdir
        rutas.mkdir();
        //para crear un nuevo archivo meter la extensión en el constructor

        File rutasArchivo = new File("C:" + File.separator + "Users" + File.separator
                + "Shaila" + File.separator + "Downloads" + File.separator + "WEB"
                + File.separator + "crearCarpeta" + File.separator + "crearCarpeta.txt");
        String archivoDestino = rutasArchivo.getAbsolutePath();
        try {
            rutasArchivo.createNewFile();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        Escribiendo acceder = new Escribiendo();
        acceder.escribir(archivoDestino);
        
        //Más Métodos de la clase File
        System.out.println("¿Existe?"+rutasArchivo.exists());
        System.out.println("¿Se puede leer?"+rutasArchivo.canRead());
        System.out.println("¿Se puede escribir?"+rutasArchivo.canWrite());
        File rutasArchivos = new File("C:" + File.separator + "Users" + File.separator
                + "Shaila" + File.separator + "Downloads" + File.separator + "WEB"
                + File.separator + "crearCarpeta" + File.separator + 
                "crearCarpeta1"+ File.separator + "crearCarpeta2"+ 
                File.separator + "crearCarpeta3");
        System.out.println("¿Crear VARIOS directorios?"+rutasArchivos.mkdirs());
        System.out.println("¿Renombrar? "+rutasArchivo.renameTo(new File("C:" + File.separator + "Users" + File.separator
                + "Shaila" + File.separator + "Downloads" + File.separator + "WEB"
                + File.separator + "crearCarpeta" + File.separator + "crearCarpetaBis.txt")));
        
        rutasArchivo.delete();
    }

}
