
import entity.Cliente;
import entity.Cuenta;
import entity.ExcepcionesBanco;
import entity.ExcepcionesBanco.ErrorExcepcion;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Shaila
 */
public class ClienteDAOImplementacion implements ClienteDAO {

    private Session sesionActual;
    private Transaction tx;

    /**
     * Constructor vacío.
     */
    public ClienteDAOImplementacion() {
    }

    private void iniciarOperacion() throws HibernateException {
        sesionActual = HibernateSesion.getSessionFactory().openSession();
        tx = sesionActual.beginTransaction();
    }

    public void desconectarHibernate() throws HibernateException {
        HibernateSesion.cerrarSesion();
    }

    private void suspenderCambios(HibernateException he) {
        tx.rollback();
        throw new HibernateException("Se ha revertido un error", he);
    }

    //Este método sí alteran la BD y por tanto ejecutan un commit() para la transacción
    public long crearContacto(Cliente cliente) throws HibernateException,
            ErrorExcepcion {
        long id = 0;
        try {
            iniciarOperacion();
            id = (Long) sesionActual.save(cliente);
            tx.commit();
            //Preguntar
            if (true) {
              throw new ErrorExcepcion("Error al crear el cliente.");  
            }
            
        } catch (HibernateException he) {
            suspenderCambios(he);
            throw he;
        } catch (ErrorExcepcion ex) {
            System.out.println(ex.getMessage());

        } finally {
            sesionActual.close();
        }
        return id;
    }

    @Override
    public boolean traspaso(Cliente clienteCuentaOrigen, Cliente clienteCuentaDestino, int cantidad) throws ExcepcionesBanco.ErrorExcepcion {

        
        
        return false;
    }

    @Override
    public boolean trasnferencia(Cliente clienteCuentaOrigen, Cliente cliente2CuentaDestino, int cantidad) throws ExcepcionesBanco.ErrorExcepcion {
        return false;

    }

    @Override
    public Cuenta crearCuenta(String numeroCuenta, int saldo, String divisa, Cliente cliente) throws ExcepcionesBanco.ErrorExcepcion {
        return null;

    }

}
