package modelo;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author Shaila
 */
public class OperacionesFicheros {

    private File[] rutasFicheros;

    /**
     * Método para listar ficheros en función de tres parámetros. Si la ruta
     * está vacia buscara en la raíz en función del OS. Si ordenadosPorTamaño es
     * True retornará los nombres y tamaño ordenados por tamaño. Si
     * soloDirectorios es True retornará solo los nombres de los directorios.
     *
     * @param ruta
     * @param ordenadosPorTamanio
     * @param soloDirectorios
     * @return array de ficheros
     */
    public File[] listarFicheros(String ruta, boolean ordenadosPorTamanio,
            boolean soloDirectorios) throws MisExcepciones.NoEsUnDirectorioNoSePuedeListar,
            MisExcepciones.CarpetaVacia {
        File[] lista = null;
        File archivos = new File(ruta);

        if (ruta.equals("")) {
            rutasFicheros = File.listRoots();
        }
        lista = archivos.listFiles();

        if (!archivos.isDirectory()) {
            throw new MisExcepciones.NoEsUnDirectorioNoSePuedeListar("La "
                    + "ruta no es un directorio, no se puede listar.");
        }
        if (lista.length == 0) {
            throw new MisExcepciones.CarpetaVacia("La carpeta está vacía.");
        }
        if (ordenadosPorTamanio == true) {
            Arrays.sort(lista, new Comparator<File>() {
                @Override
                public int compare(File fichero1, File fichero2) {
                    if (fichero1.length() < fichero2.length()) {
                        return 1;
                    } else if (fichero1.length() > fichero2.length()) {
                        return -1;
                    } else {
                        return 0;
                    }
                }
            });
        }

        if (soloDirectorios == true) {
            for (int i = 0; i < lista.length; i++) {
                if (lista[i].isDirectory() == true) {
                    System.out.println(lista[i].toString());
                    System.out.println(lista[i].length());
                }
            }
        } else {
            for (int i = 0; i < lista.length; i++) {
                System.out.println(lista[i].toString());
                System.out.println(lista[i].length());
            }
        }
        return lista;
    }

    /**
     * Método para crear directorios en función de la ruta de origen y la lista
     * de directorios.
     *
     * @param rutaOrigen
     * @param listaDirectorios
     * @return número de directorios creados.
     */
    public int crearDirectorio(File rutaOrigen, ArrayList<String> listaDirectorios) {
        int contadorCreados = 0;
        if (!rutaOrigen.exists()) {
            try {
                throw new MisExcepciones.NoExisteRuta();
            } catch (MisExcepciones.NoExisteRuta ex) {
                System.out.println("La ruta no existe.");
            }
        }
        for (String listaDirectorio : listaDirectorios) {
            File nuevoDirectorio = new File(rutaOrigen + "/" + listaDirectorio.toString());
            if (nuevoDirectorio.exists()) {
                try {
                    throw new MisExcepciones.YaExisteDirectorio();
                } catch (MisExcepciones.YaExisteDirectorio ex) {
                    System.out.println("El directorio " + listaDirectorio + " ya existe.");
                }
            }
            nuevoDirectorio.mkdir();
            contadorCreados++;
        }
        return contadorCreados;
    }

    /**
     * Método para cambiar la extensión de los archivos si los encuentra.
     *
     * @param ruta
     * @param extensionAntigua
     * @param extensionNueva
     * @return número de archivos modificados.
     */
    public int cambiarExtensionFicheros(File ruta, String extensionAntigua,
            String extensionNueva) throws MisExcepciones.NoEsFile,
            MisExcepciones.NoExisteRuta {
        int contadorModificados = 0;

        File[] otroFile = ruta.listFiles();
        for (int i = 0; i < otroFile.length; i++) {
            if (otroFile[i].getName().contains(extensionAntigua)) {

                String nombreArchivoSinExtension = "";
                String nombreArchivo = ruta.getName();
                //Es el último valor porque puede haber más de un punto
                for (int j = 0; j < nombreArchivo.length(); j++) {
                    nombreArchivoSinExtension = nombreArchivo.substring(0,
                            nombreArchivo.lastIndexOf(".") - 1);
                }
                if (!ruta.exists()) {
                    throw new MisExcepciones.NoExisteRuta("La ruta no existe.");
                }

                for (int k = 0; k < ruta.length(); k++) {
                    File fichero = new File(nombreArchivoSinExtension + "." + extensionAntigua);
                    File fichero2 = new File(nombreArchivoSinExtension + "." + extensionNueva);

                    boolean exito = fichero.renameTo(fichero2);
                    if (!exito) {
                        System.out.println("Error intentando cambiar el nombre de fichero.");
                    }
                }
                contadorModificados++;
            }

        }
        return contadorModificados;
    }

    /*Utilizando la clase File crear un proyecto en Netbeans que liste los 
    contenidos de un directorio.*/
    /**
     * Método para listar el contenido de un directorio incluso si tiene más
     * directorios dentro.
     *
     * @param ruta
     */
    public void listarRecursivoFicheros(String ruta) {
        File archivos = new File(ruta);
        File[] nombresArchivo = archivos.listFiles();
        for (int i = 0; i < nombresArchivo.length; i++) {
            if (nombresArchivo[i].isFile()) {
                System.out.println(nombresArchivo[i].getName());
            }
            if (nombresArchivo[i].isDirectory()) {
                File archivoDirectorio = new File(nombresArchivo[i].getPath());
                System.out.println(archivoDirectorio.getName());
                listar(archivoDirectorio.getAbsolutePath());
            }
        }
    }

    /**
     * Método para listar archivos de forma recursiva
     *
     * @param nuevaRuta
     */
    public static void listar(String nuevaRuta) {
        File archivosNuevaRuta = new File(nuevaRuta);
        File[] nombresArchivosSubcarpetas = archivosNuevaRuta.listFiles();

        for (int j = 0; j < nombresArchivosSubcarpetas.length; j++) {
            System.out.println(nombresArchivosSubcarpetas[j].getName());

        }
    }
}
