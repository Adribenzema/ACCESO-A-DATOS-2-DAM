package logica;


import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import modelo.OperacionesAlbaran;

/**
 *
 * @author Shaila
 */
public class AlbaranMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JAXBException {

        //Funciona
        JAXBElement jAXBElement = OperacionesAlbaran.getInstance().
                unmarshalDocument("jaxb.albaran", "albaran.xml");
        OperacionesAlbaran.getInstance().marshalDocument(jAXBElement);

        
        

    }

}
