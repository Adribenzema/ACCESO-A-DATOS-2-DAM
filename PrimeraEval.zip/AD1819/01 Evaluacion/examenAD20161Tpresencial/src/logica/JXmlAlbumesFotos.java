package logica;

import java.io.File;
import javax.xml.bind.JAXBElement;
import jaxb.fotosBinding.AlbumesFotos;
import modelo.ExcepcionesAlbumesFotos.MarshalExcepcion;
import modelo.MetodosAlbumesFotos;

/**
 *
 * @author Shaila
 */
public class JXmlAlbumesFotos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            //String rutaFichero = "diccionario2.json";
            MetodosAlbumesFotos metodosAlbumesFotos = new MetodosAlbumesFotos("jaxb.fotosBinding");
            File documentoXML = new File("fotos.xml");
            JAXBElement jaxbElement = metodosAlbumesFotos.unMarshall(documentoXML);//metodo unmarshalizador

            AlbumesFotos albumesFotos = (AlbumesFotos) jaxbElement.getValue();//castear al tipo del nodo "raíz"
            //OPERACIONES
            /**
             * Cuente el total de fotografías con una ISO que se pasa como
             * parámetro.
             */
            System.out.println("Total de fotografías " + metodosAlbumesFotos.totalFotografiasConIso(albumesFotos, "400"));
            System.out.println("Resultado " + metodosAlbumesFotos.cambiarEmailDeAutor(albumesFotos, "String"));
            /**
             * Genere un Map donde K es el nombre del álbum y V es el total de
             * fotos del álbum.
             */
            System.out.println("Map " + metodosAlbumesFotos.generarInformeAlbumes(albumesFotos));

//MARSHALIZAR
            File ficheroSalida = new File("miXMLmodificadoFotos.xml");//xml de salida nuevo modificado
            metodosAlbumesFotos.marshalizar(jaxbElement, ficheroSalida);//metodo marshalizador

        } catch (MarshalExcepcion ex) {
            System.out.println(ex.getMessage());
        }
    }
}
