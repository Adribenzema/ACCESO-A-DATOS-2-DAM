/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.File;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBElement;
import jaxb.bibliotecaBinding.Biblioteca;
import jaxb.bibliotecaBinding.PrestamoType;


/**
 *
 * @author Shaila
 */
public interface InterfaceBiblioteca {

    public JAXBElement unMarshall(File documentoXML) throws ExcepcionesBiblioteca.UnmarshalExcepcion;

    public boolean marshall(JAXBElement jaxbElement, File ficheroSalida) throws ExcepcionesBiblioteca.MarshalExcepcion;

    public boolean insertarPrestamosEnBiblioteca(PrestamoType prestamoType);

    public boolean darDeBajaUnSocioEnBiblioteca(Biblioteca biblioteca, String codigoSocio)
            throws ExcepcionesBiblioteca.NoExisteSocioExcepcion;

    public Map<String, List<String>> generarMapCodigoSocioConListaLibrosPrestados(Biblioteca biblioteca);

    public List<String> retrasosSocios(Biblioteca biblioteca, int dia, int mes, int anio) throws ExcepcionesBiblioteca.FechaIncorrectaException;
}
