package modelo;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonWriter;

/**
 *
 * @author Shaila
 */
public class JsonMetodosBiblioteca {

    /**
     * Método para leer un fichero Json al que se le pasa por parámetro dicho
     * fichero.
     *
     * @param documentoJson
     * @return un objeto JsonObject.
     */
    public static JsonObject leerJson(String documentoJson) {
        JsonObject diccionarioEspanol = null;
        try {
            JsonReader jsonReader;

            InputStream fis = new FileInputStream(documentoJson);
            jsonReader = Json.createReader(fis);
            diccionarioEspanol = jsonReader.readObject();

            jsonReader.close();

            fis.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return diccionarioEspanol;

    }

    /**
     * Último paso, crear un fichero.
     *
     * @param rutaFichero
     * @param JsonArrayBuilder libros
     */
    public static void crearFichero(String rutaFichero, JsonArrayBuilder libros) {
        //Construimos un JsonArray
        JsonArray arrayJsonLibros = libros.build();

        //Creamos un FileWriter para el archivo de salida
        FileWriter ficheroSalida = null;
        try {
            ficheroSalida = new FileWriter(rutaFichero);
            //Creamos un JsonWriter para crear el archivo Json
            JsonWriter jsonWriter = Json.createWriter(ficheroSalida);
            //Escribimos el array de Json
            jsonWriter.writeArray(arrayJsonLibros);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                ficheroSalida.flush();
                ficheroSalida.close();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

    /**
     * Crear libros. Crea un JSONObject con los datos necesarios. Creamos un
     * método que devuelva un JsonObjectBuilder y le pasamos por parámetro los
     * datos necesarios para crear un libro.
     *
     * @param calle
     * @param numero
     * @param piso
     * @param escalera
     * @param cp
     * @param ciudad
     * @return
     */
    public static JsonObject crearLibros(String ISBN, String titulo,
            String autor, int numeroPaginas, String fechaPublicacion,
            String prestadoSiNo, String fechaDevolucion) {

        return Json.createObjectBuilder()
                .add("ISBN", ISBN)
                .add("titulo", titulo)
                .add("autor", autor)
                .add("numeroPaginas", numeroPaginas)
                .add("fechaPublicacion", fechaPublicacion)
                .add("prestadoSiNo", prestadoSiNo)
                .add("fechaDevolucion", fechaDevolucion).build();

    }
    public static JsonArrayBuilder unirLibros(List<JsonObject> listaLibros) {
        JsonArrayBuilder createArrayBuilder = Json.createArrayBuilder();

        for (JsonObject libros : listaLibros) {
            createArrayBuilder.add(libros);
        }

        return createArrayBuilder;
    }
    /**
     * Método que genera un Map cuya clave es el código del socio y su value es
     * una lista con los títulos de los libros prestados.
     *
     * @param jsonObject
     * @return
     */
    public static Map<String, List<String>> generarMap(JsonObject jsonObject) {
        List<String> listaTitulosLibrosPrestados = new ArrayList<>();
        Map<String, List<String>> informacionSociosYlibrosPrestadosEnBiblioteca = new HashMap<>();
        String codigoSocio = null, titulo;

        JsonArray jsonArray = jsonObject.getJsonObject("biblioteca").getJsonObject("prestamos").getJsonArray("prestamo");
        for (int contadorBiblioteca = 0; contadorBiblioteca < jsonArray.size(); contadorBiblioteca++) {
//Meto en un JsonArray con lo que voy a trabajar
            codigoSocio = jsonArray.getJsonObject(contadorBiblioteca).getString("codigoSocio");
            titulo = jsonArray.getJsonObject(contadorBiblioteca).getString("titulo");
            listaTitulosLibrosPrestados.add(titulo);
        }
        informacionSociosYlibrosPrestadosEnBiblioteca.put(codigoSocio, listaTitulosLibrosPrestados);

        return informacionSociosYlibrosPrestadosEnBiblioteca;

    }
}
