package modelo;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.diccionarioBinding.DiccionarioEspanol;
import jaxb.diccionarioBinding.PalabraType;
import jaxb.diccionarioBinding.SinonimoType;
import modelo.ExcepcionesPalabras.MarshalExcepcion;

/**
 *
 * @author Shaila
 */
public class MetodosPalabras implements PalabrasInterface {

    private JAXBContext jaxbCtx = null;

    public MetodosPalabras(String packageName) {
        try {
            jaxbCtx = JAXBContext.newInstance(packageName);
        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Método unmarshalizador. Obtenemos un objeto de la etiqueta padre del XML,
     * obteniendo todos sus hijos (su contenido)
     *
     * @param documentoXML
     * @return
     */
    @Override
    public JAXBElement unMarshall(File documentoXML) {
        JAXBElement jaxbElement = null;
        try {
            Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            jaxbElement = unmarshaller.unmarshal(new StreamSource(new java.io.File(documentoXML.toString())), DiccionarioEspanol.class);

        } catch (JAXBException ex) {
            System.out.println(ex.getMessage());
        }

        return jaxbElement;
    }

    /**
     * Método marshalizador. Genera un XML a partir del JAXB
     *
     * @param jaxbElement
     * @param ficheroSalida donde volcamos los datos
     * @return true si esta todo correcto; false si hay algun problema
     * @throws jaxb_albaran.Excepciones.MarshalExcepcion
     */
    @Override
    public boolean marshalizar(JAXBElement jaxbElement, File ficheroSalida) throws MarshalExcepcion {
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance("jaxb.diccionarioBinding");
            Marshaller marshaller;
            marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);//Controla si hay que formatear el XML para leerlo mejor      
            marshaller.marshal(jaxbElement, ficheroSalida);//Muestra el contenido del objeto en salida estandar
            return true;
        } catch (javax.xml.bind.JAXBException ex) {

            return false;
        }
    }

    /**
     * Método para contar el total de definiciones que contienen una determinada
     * palabra.
     *
     * @param diccionarioEspanol
     * @param grafia
     * @return numero total de definiciones.
     */
    @Override
    public int totalDefiniciones(DiccionarioEspanol diccionarioEspanol, String grafia) {

        for (PalabraType palabra : diccionarioEspanol.getPalabra()) {
            if (palabra.getGrafia().equals(grafia)) {
                return palabra.getDefinicion().size();
            }
        }
        
        return -1;
    }

    /**
     * Variante anterior metiendo la palabra.
     *
     * @param diccionarioEspanol
     * @param palabra
     * @return numero total de definiciones.
     */
    public int totalDefinicionesBis(DiccionarioEspanol diccionarioEspanol, String palabra) {
        int contadorDefiniciones = 0;
        for (int i = 0; i < diccionarioEspanol.getPalabra().size(); i++) {
            for (int j = 0; j < diccionarioEspanol.getPalabra().get(i).getDefinicion().size(); j++) {
                if (diccionarioEspanol.getPalabra().get(i).getDefinicion().get(j).equalsIgnoreCase(palabra)) {
                    contadorDefiniciones++;
                }
            }
        }
        return contadorDefiniciones;
    }

    /**
     * Método para borrar todas las traducciones de un determinado idioma (ej.
     * PT) y lo grabe en otro fichero.
     *
     * @param diccionarioEspanol
     * @param idioma
     * @return boolean con el resultado de la operación.
     */
    @Override
    public boolean borrarTraduccionesIdioma(DiccionarioEspanol diccionarioEspanol, String idioma) {

        for (int i = 0; i < diccionarioEspanol.getPalabra().size(); i++) {
            for (int j = 0; j < diccionarioEspanol.getPalabra().get(i).getTraducciones().getTraduccion().size(); j++) {
                /*diccionarioEspanol.getPalabra().get(i).getTraducciones().
                getTraduccion().get(j).getIdiomaTraduccion().equalsIgnoreCase(idioma);*/
                if (diccionarioEspanol.getPalabra().get(i).getTraducciones().
                        getTraduccion().get(j).getIdiomaTraduccion().contains(idioma)) {
                    diccionarioEspanol.getPalabra().get(i).getTraducciones().getTraduccion().remove(j);

                }

            }
        }
        File ficheroSalida = new File("miXMLmodificadoDiccionariosMetodo.xml");
        File documentoXML = new File("diccionario.xml");
        JAXBElement jaxbElement = unMarshall(documentoXML);//metodo unmarshalizador
        try {
            marshalizar(jaxbElement, ficheroSalida);
        } catch (MarshalExcepcion ex) {
            Logger.getLogger(MetodosPalabras.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;

    }

    /**
     * Retornar para una determinada palabra todos los sinónimos seguidos de sus
     * definiciones.
     *
     * @param diccionarioEspanol
     * @param palabra
     * @return
     */
    //DUDAS
    @Override
    public Map<SinonimoType, String> sinonimosPalabra(DiccionarioEspanol diccionarioEspanol,
            String palabra) {
        Map<SinonimoType, String> informacionPalabras = new HashMap<>();

        for (int i = 0; i < diccionarioEspanol.getPalabra().size(); i++) {
            if (diccionarioEspanol.getPalabra().get(i).getGrafia().equalsIgnoreCase(palabra)) {
                for (int j = 0; j < diccionarioEspanol.getPalabra().get(i).getSinonimos()
                        .getSinonimo().size(); j++) {
                    SinonimoType sinonimo = diccionarioEspanol.getPalabra().get(i).getSinonimos()
                            .getSinonimo().get(j);
                    String grafia = diccionarioEspanol.getPalabra().get(i).getSinonimos()
                            .getSinonimo().get(j).getGrafia();
                    if (!informacionPalabras.containsKey(sinonimo)) {
                        informacionPalabras.put(sinonimo, grafia);
                    }

                }
            }

        }

        return informacionPalabras;

    }

    /*Generar un Map<K,V> donde K es el idioma de traducción y V es el total de 
    traducciones que hay.*/
    /**
     * Método que genera un hashmap con el idioma de traduccion por clave y el
     * número de veces que se repite el idioma.
     *
     * @param diccionarioEspanol
     * @return
     */
    public Map<String, Integer> generarInformeTraducciones(DiccionarioEspanol diccionarioEspanol) {

        Map<String, Integer> informacionGrafia = new HashMap<>();

        for (int i = 0; i < diccionarioEspanol.getPalabra().size(); i++) {
            for (int j = 0; j < diccionarioEspanol.getPalabra().
                    get(i).getTraducciones().getTraduccion().size(); j++) {

                String idiomaTraduccion = diccionarioEspanol.getPalabra().
                        get(i).getTraducciones().getTraduccion().get(j).getIdiomaTraduccion();

                if (!informacionGrafia.containsKey(idiomaTraduccion)) {
                    informacionGrafia.put(idiomaTraduccion, (1));
                } else {

                    informacionGrafia.put(idiomaTraduccion, (informacionGrafia.get(idiomaTraduccion) + 1));

                    
                }

            }
        }

        return informacionGrafia;

    }

}
