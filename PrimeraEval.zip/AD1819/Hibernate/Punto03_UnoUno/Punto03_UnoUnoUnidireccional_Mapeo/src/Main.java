
import entidades.Direccion;
import entidades.Persona;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {

    private static Session session;
    private static Persona persona01;
    private static Direccion direccion01;

    /**
     * La entidad Dirección está ligada unidireccionalmente a Persona, de tal
     * forma que si se borra una persona, se borra automáticamente su dirección
     * asociada. Esta relación se especifica en el hbm de la Persona, dentro de
     * las etiquetas <id>
     * - Descomentar crearDatos(), ejecutar el programa y comprobar que se han 
     * creado tanto la Persona como la Dirección asociada
     * -Comentar crearDatos(), descomentar borrarDatos() y ejecutar el programa.
     * Comprobar que se ha borrado la persona y también, de forma automática, la
     * dirección que tenía asociada
     * @param args 
     */
    public static void main(String[] args) {

        SessionFactory sessionFactory = HibernateSesion.getSessionFactory();
        session = sessionFactory.openSession();
        
        //crearDatos();
        //borrarDatos();

        session.close();
        sessionFactory.close();
    }

    private static void crearDatos() {
        direccion01 = new Direccion("Calle de la Paz", "12345");
        persona01 = new Persona("Ana Cueto", direccion01);

        session.beginTransaction();
        session.persist(direccion01);
        session.persist(persona01);
        session.getTransaction().commit();
        System.out.println("Se han añadido los datos con éxito a la base \"hibernaterelaciones\".");
    }

    private static void borrarDatos() {
        try {
            session.beginTransaction();
        persona01 = (Persona) session.get(Persona.class, (long) 1);
        session.delete(persona01);
        session.getTransaction().commit();
        System.out.println("Se han eliminado los datos satisfactoriamente");
        } catch (IllegalArgumentException ie) {
            throw new IllegalArgumentException("No existe ningún objeto Persona con el ID seleccionado", ie);
        }
    }

}
