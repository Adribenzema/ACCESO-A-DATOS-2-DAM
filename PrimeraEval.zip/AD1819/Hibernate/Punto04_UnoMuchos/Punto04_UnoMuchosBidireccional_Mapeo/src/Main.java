
import entidades.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
    
    private static Session session;
    private static Transaction tx;

    public static void main(String[] args) {
        
        SessionFactory sessionFactory = HibernateSesion.getSessionFactory();
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        //crearDatos();
        //borrarDatos(Persona.class,1);
        
        tx.commit();
        session.close();
        HibernateSesion.cerrarSesion();
    }
    
    private static void crearDatos() {
        Map<Integer,Libro> libros01 = new HashMap<>();
        libros01.put(1957, new Libro("Justine"));
        libros01.put(1958, new Libro("Balthazar"));
        libros01.put(1959, new Libro("Mountolive"));
        libros01.put(1960, new Libro("Clea"));
        Persona persona01 = new Persona("Lawrence Durrell");
        persona01.setLibros(libros01);
        Collection<Libro> values = libros01.values();
        for (Libro value : values) {
            value.setPersona(persona01);
        }
        
        Map<Integer,Libro> libros02 = new HashMap<>();
        libros02.put(1869, new Libro("Guerra y Paz"));
        libros02.put(1877, new Libro("Anna Karenina"));
        Persona persona02 = new Persona("Lev Tolstoi");
        persona02.setLibros(libros02);
        Collection<Libro> values2 = libros02.values();
        for (Libro value : values2) {
            value.setPersona(persona02);
        }
        
        System.out.println("Datos añadidos correctamente" + System.lineSeparator());
        session.persist(persona01);
        session.persist(persona02);
    }
        
    private static <T> void borrarDatos(Class<T> t, int idObjeto) {
        try {
            T objetoRecuperado = (T) session.get(t, (long) idObjeto);
            session.delete(objetoRecuperado);
            System.out.println("Datos borrados satisfactoriamente" + System.lineSeparator());
        } catch (IllegalArgumentException iae) {
            System.out.println("No existe una persona con el ID introducido");
            iae.printStackTrace();
        }
    }
    
}
