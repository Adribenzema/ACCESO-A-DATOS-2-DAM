package logica;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.JsonMetodos;

/**
 *
 * @author Shaila
 */
public class JSonLibros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String rutaFichero = "libros.json";
//1)Modificar el ejemplo JSON para que 
        /**
         * a.Cree un fichero con una salida como la del fichero libros.json. Lo
         * entendí
         */
        try {
            JsonMetodos.crearFichero("salidaLibrosShaila");
        } catch (IOException ex) {
            System.err.println("error ficchero");
        }
        /**
         * Lea el fichero libros.json y cuente el total de libros.
         */
        try {
            System.out.println("Número de libros: " + JsonMetodos.contarLibrosDeAutores("libros.json"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JSonLibros.class.getName()).log(Level.SEVERE, null, ex);
        }

        /**
         * c.Lea el fichero libros.json y muestre el título de todos los libros.
         */
        try {
            System.out.println("Título de todos los libros: "
                    + JsonMetodos.mostrarTodosLibrosAutores("libros.json"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JSonLibros.class.getName()).log(Level.SEVERE, null, ex);
        }
        /**
         * d.Lea el fichero libros.json y muestre el nombre del autor 1 del
         * libro 2
         */
        try {
            System.out.println("Nombre autor del libro 2: " + JsonMetodos.mostrarAutor(rutaFichero, 1, 0));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JSonLibros.class.getName()).log(Level.SEVERE, null, ex);
        }

        /**
         * e.Calcule el valor de los libros en stock.
         */
        try {
            System.out.println("Valor de los libros en stock: " + JsonMetodos.
                    calculoDelValorDeLosLibrosEnStock(rutaFichero));
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
