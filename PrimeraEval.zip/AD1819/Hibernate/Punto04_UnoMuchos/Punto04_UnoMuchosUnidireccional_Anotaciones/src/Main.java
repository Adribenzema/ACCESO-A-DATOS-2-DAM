
import entidades.*;
import java.util.Arrays;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
    
    private static Session session;
    private static Transaction tx;

    public static void main(String[] args) {
        
        SessionFactory sessionFactory = HibernateSesion.getSessionFactory();
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        //crearDatos();
        //borrarDatos(1);
        
        tx.commit();
        session.close();
        HibernateSesion.cerrarSesion();
    }
    
    private static void crearDatos() {
        List<Libro> libros01 = Arrays.asList(
                new Libro("Justine"),
                new Libro("Balthazar"),
                new Libro("Mountolive"),
                new Libro("Clea")
        );
        Persona persona01 = new Persona("Lawrence Durrell");
        persona01.setLibros(libros01);
        List<Libro> libros02 = Arrays.asList(
                new Libro("Guerra y Paz"),
                new Libro("Anna Karenina")
        );
        Persona persona02 = new Persona("Lev Tolstoi");
        persona02.setLibros(libros02);
        
        System.out.println("Datos añadidos correctamente" + System.lineSeparator());
        session.persist(persona01);
        session.persist(persona02);
    }
    
    private static void borrarDatos(int idPersona) {
        try {
            Persona persona = (Persona) session.get(Persona.class, (long) idPersona);
            session.delete(persona);
            System.out.println("Datos borrados satisfactoriamente" + System.lineSeparator());
        } catch (IllegalArgumentException iae) {
            System.out.println("No existe una persona con el ID introducido");
            iae.printStackTrace();
        }
    }
    
}
