package logica;

import java.io.File;
import javax.xml.bind.JAXBElement;
import jaxb.diccionarioBinding.DiccionarioEspanol;
import modelo.ExcepcionesPalabras.MarshalExcepcion;
import modelo.MetodosPalabras;

/**
 *
 * @author Shaila
 */
public class JXmlPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            //String rutaFichero = "diccionario.json";
            MetodosPalabras metodosPalabras = new MetodosPalabras("jaxb.diccionarioBinding");
            File documentoXML = new File("diccionario.xml");
            JAXBElement jaxbElement = metodosPalabras.unMarshall(documentoXML);//metodo unmarshalizador

            DiccionarioEspanol diccionarioEspanol = (DiccionarioEspanol) jaxbElement.getValue();//castear al tipo del nodo "raíz"
            //OPERACIONES

            /*Contar el total de definiciones que contienen una determinada.*/
            System.out.println("Total definiciones " + (metodosPalabras.totalDefiniciones(diccionarioEspanol, "String")));
            System.out.println("Total definiciones bis " + (metodosPalabras.totalDefinicionesBis(diccionarioEspanol, "String")));

            /*Borrar todas las traducciones de un determinado idioma (ej. PT) y lo grabe en otro fichero.*/
            System.out.println("Borrar " + metodosPalabras.borrarTraduccionesIdioma(diccionarioEspanol, "PT"));

            /**
             * Retornar para una determinada palabra todos los sinónimos
             * seguidos de sus definiciones.
             */
            System.out.println("Sinonimos " + metodosPalabras.sinonimosPalabra(diccionarioEspanol, "String"));

            /*
            Generar un Map<K,V> donde K es el idioma de traducción y V es el total de traducciones que hay.
             */
              System.out.println("Map " + metodosPalabras.generarInformeTraducciones(
                      diccionarioEspanol));

//MARSHALIZAR
            File ficheroSalida = new File("miXMLmodificadoDiccionarios.xml");//xml de salida nuevo modificado
            metodosPalabras.marshalizar(jaxbElement, ficheroSalida);//metodo marshalizador

        } catch (MarshalExcepcion ex) {
            System.out.println(ex.getMessage());
        }
    }
}
