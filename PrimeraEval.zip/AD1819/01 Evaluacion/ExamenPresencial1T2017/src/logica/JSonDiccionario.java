package logica;

import javax.json.JsonObject;
import modelo.JsonMetodos;

/**
 *
 * @author Shaila
 */
public class JSonDiccionario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String rutaFichero = "diccionario.json";
        JsonObject jsonObject = JsonMetodos.leerJson(rutaFichero);

        System.out.println("Contar Total Definiciones Palabra Determinada " + JsonMetodos.
                contarTotalDefinicionesPalabraDeterminada(jsonObject, "Shaila"));
        
        System.out.println("Map " + JsonMetodos.
        generarGrafia(jsonObject));
         
        System.out.println("Lista " + JsonMetodos.
        generarLista(jsonObject));
        
    }
}
