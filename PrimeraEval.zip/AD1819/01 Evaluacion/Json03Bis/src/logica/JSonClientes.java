package logica;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.xml.bind.JAXBElement;
import jaxb.clientesBinding.Clientes;
import jaxb.clientesBinding.TipoDireccion;
import modelo.GestionJAXB;
import modelo.Metodos;

/**
 *
 * @author Shaila
 */
public class JSonClientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /**
         * Apartado 1: Crear un JSON con datos.
         *
         * 1)	Crear cliente. Crea un JSONObject con los datos necesarios (pasar
         * una lista de direcciones) 2)	Crear clientes. Crea un JSONObject con
         * los datos necesarios (pasar una lista de cliente)
         *
         */
        //Después de hacer el build viene la muerte, no podemos cambiar nada
        /*String rutaFichero = "clientesShaila.json";
        
        //Creo una direccion
        JsonObjectBuilder direccion1 = Metodos.crearDireccion("Sor Sabina", "9",
        0, "-", 33940, "El Entrego");
        //Creo otra direccion
        JsonObjectBuilder direccion2 = Metodos.crearDireccion("Colón", "1",
        2, "-", 33940, "El Entrego");
        
        //Puedo hacer un for para crear la misma direccion
        //Agrego las direcciones a una lista y le paso lo que me devuelve el método anterior -->JsonObjectBuilder
        List<JsonObjectBuilder> listaDirecciones = new ArrayList<>();
        
        //Meto en la lista las direcciones
        //listaDirecciones.add(Metodos.crearDireccion("Sor Sabina", "9",0, "-", 33940, "El Entrego"));
        //listaDirecciones.add(Metodos.crearDireccion("Colón", "1",2, "-", 33940, "El Entrego"));
        listaDirecciones.add(direccion1);
        listaDirecciones.add(direccion2);
        
        //Uno las dos direcciones
        JsonArrayBuilder unirDirecciones = Metodos.unirDirecciones(listaDirecciones);
        
        //Creo un cliente
        JsonObject cliente1 = Metodos.crearClientes("Perez", "Fernandez", unirDirecciones, "665934374");
        //Creo un segundo cliente, para simplificar meto las mismas direcciones de antes
        JsonObject cliente2 = Metodos.crearClientes("Perez", "Castelao", unirDirecciones, "653280604");
        
        //Creamos una lista de clientes
        List<JsonObject> listaClientes = new ArrayList<>();
        
        //Añadimos los clientes anteriormente creados a la lista de clientes,
        //podemos hacerlo directamente pero para no liarnos, lo hacemos paso por paso
        listaClientes.add(cliente1);
        listaClientes.add(cliente2);
        
        //Unimos los clientes
        JsonArrayBuilder unirClientes = Metodos.unirClientes(listaClientes);
        Metodos.crearFichero(rutaFichero, unirClientes);*/
        /**
         * Apartado 2: Crear un JSON con datos XML. Utilizando las clases
         * creadas en el bind crear los métodos:
         *
         * 3)	Crear JSON completo. Crea un JSONObject con los datos procedentes
         * del XML. (Adaptar los métodos anteriores) 4)	Almacenar JSON en
         * fichero. Almacena el JSONObject en un fichero.
         *
         */
        //El siguiente paso es crear el Binding
        //Binding Name:	nombre del xsd
        //Select File:	algo.xsd
        //Packge Name:	jaxb.nomBinding
        //XML a JSON
        //Instanciamos
        GestionJAXB gestionJAXB = new GestionJAXB("jaxb.clientesBinding");
        File documentoXML = new File("clientes.xml");

        /*        //llamamos al método unmarshalizar y le pasamos el xml correspondiente
        JAXBElement unMarshall = gestionJAXB.unMarshall(documentoXML);
        //Creo un nuevo cliente cogiendo de la unmarshalización mediante getValue(); (Como el del combobox)
        Clientes clientes = (Clientes) unMarshall.getValue();
        
        //Creamos una lista de JsonObject
        List<JsonObject> listaJsonClientes = new ArrayList<>();
        //Clientes por lo visto es una lista de clientes
        //List<Clientes.Cliente> cliente = clientes.getCliente(); //ejemplo
        //recorremos la lista
        for (Clientes.Cliente cliente1 : clientes.getCliente()) {
        //Creamos una lista de direcciones para luego añadirselas al cliente
        List<JsonObjectBuilder> listaDirecciones = new ArrayList<>();
        // TipoDireccion sale del Binding que hice
        //TipoDireccion tipoDireccion;
        //tipoDireccion.getCalle, se que es una lista --> List<TipoDireccion> direccion = cliente1.getDireccion();
        //Lo recorro
        for (TipoDireccion tipoDireccion : cliente1.getDireccion()) {
        //Creo una direccion y la meto en mi lista de direcciones para luego metersela al cliente
        listaDirecciones.add(Metodos.crearDireccion(tipoDireccion.getCalle(),
        tipoDireccion.getNumero(), tipoDireccion.getPiso(),
        tipoDireccion.getEscalera(), tipoDireccion.getCp(), tipoDireccion.getCiudad()));
        }
        
        //Metemos en nuestra lista de JsonClientes a un nuevo cliente
        listaJsonClientes.add(
        Metodos.crearClientes(cliente1.getApellido().get(0),
        cliente1.getApellido().get(1), Metodos.unirDirecciones(listaDirecciones), cliente1.getTelefono()));
        }*/
        
        //Metodos.crearFichero("Movidas.json", Metodos.unirClientes(listaJsonClientes));
        //Creamos el json
        Metodos.crearFichero("PruebaMetodo.json", Metodos.unirClientes(Metodos.xmlToJson("jaxb.clientesBinding", "clientes.xml")));

         Metodos.jsontoXml("PruebaMetodo.json", "jaxb.clientesBinding", "clientes.xml");


    }

}
