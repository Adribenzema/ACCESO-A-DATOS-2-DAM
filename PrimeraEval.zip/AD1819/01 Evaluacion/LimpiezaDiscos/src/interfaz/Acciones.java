package interfaz;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import logica.*;
import modelo.MisExcepcionesPractica;

/**
 *
 * @author Shaila
 */
public class Acciones extends javax.swing.JFrame {

    private static final String RUTA_LOGO = ".."+File.separator+"imgs"+File.separator+"images.jpg";
    private String seleccionUnidad = "";
    private String extension = "";
    private String opcion = "";

    /**
     * Creates new form acciones
     */
    public Acciones(java.awt.Frame parent, boolean modal, String seleccionUnidad) {
        //Establecer el título de la aplicación
        this.seleccionUnidad = seleccionUnidad;
        initComponents();
        buttonGroupTamanio.add(jRadioButtonPeque);
        buttonGroupTamanio.add(jRadioButtonMediano);
        buttonGroupTamanio.add(jRadioButtonGrande);
        setTitle("LIMPIEZA DE UNIDADES");
        ControladorGestionUnidades.getInstance();
        //Establecer el logo del a aplicación
        setIconImage(new ImageIcon(getClass().getResource(RUTA_LOGO)).getImage());
        setLocationRelativeTo(null);
        jButtonEliminarDirectoriosVacios.setText("<html><p>ELIMINAR</p> "
                + "<p>DIRECTORIOS</p>VACÍOS</html>");
        jButtonEliminarFicherosAntiguos.setText("<html><p>ELIMINAR</p> "
                + "<p>FICHEROS</p> "
                + "ANTIGÜOS</html>");
        jButtonEliminarFicherosSegunCategoria.setText("<html><p>ELIMINAR</p>"
                + "<p>ARCHIVOS</p>"
                + "DOC/IMG/VIDEO</html>");
        jButtonEliminarFicherosTamanio.setText("<html><p>ELIMINAR</p>"
                + "<p>FICHEROS</p>"
                + " TAMAÑO </html>");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupTamanio = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButtonEliminarDirectoriosVacios = new javax.swing.JButton();
        jButtonEliminarFicherosSegunCategoria = new javax.swing.JButton();
        jButtonEliminarFicherosTamanio = new javax.swing.JButton();
        jButtonSalir = new javax.swing.JButton();
        jRadioButtonPeque = new javax.swing.JRadioButton();
        jRadioButtonGrande = new javax.swing.JRadioButton();
        jRadioButtonMediano = new javax.swing.JRadioButton();
        jButtonEliminarFicherosAntiguos = new javax.swing.JButton();
        jSpinnerFecha = new javax.swing.JSpinner();
        jLabelSeleccion = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListAborrar = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonEliminarDirectoriosVacios.setBackground(new java.awt.Color(204, 204, 255));
        jButtonEliminarDirectoriosVacios.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonEliminarDirectoriosVacios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarDirectoriosVaciosActionPerformed(evt);
            }
        });

        jButtonEliminarFicherosSegunCategoria.setBackground(new java.awt.Color(204, 204, 255));
        jButtonEliminarFicherosSegunCategoria.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonEliminarFicherosSegunCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarFicherosSegunCategoriaActionPerformed(evt);
            }
        });

        jButtonEliminarFicherosTamanio.setBackground(new java.awt.Color(204, 204, 255));
        jButtonEliminarFicherosTamanio.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonEliminarFicherosTamanio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonEliminarFicherosTamanioMouseClicked(evt);
            }
        });
        jButtonEliminarFicherosTamanio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarFicherosTamanioActionPerformed(evt);
            }
        });

        jButtonSalir.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalir.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonSalir.setText("SALIR");
        jButtonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalirActionPerformed(evt);
            }
        });

        jRadioButtonPeque.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jRadioButtonPeque.setText("PEQUEÑO");

        jRadioButtonGrande.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jRadioButtonGrande.setText("GRANDE");

        jRadioButtonMediano.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jRadioButtonMediano.setText("MEDIANO");
        jRadioButtonMediano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMedianoActionPerformed(evt);
            }
        });

        jButtonEliminarFicherosAntiguos.setBackground(new java.awt.Color(204, 204, 255));
        jButtonEliminarFicherosAntiguos.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jButtonEliminarFicherosAntiguos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarFicherosAntiguosActionPerformed(evt);
            }
        });

        jSpinnerFecha.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, null, java.util.Calendar.DAY_OF_WEEK_IN_MONTH));

        jLabelSeleccion.setFont(new java.awt.Font("Dialog", 3, 16)); // NOI18N
        jLabelSeleccion.setText("Va a borrar:");

        jScrollPane1.setViewportView(jListAborrar);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonEliminarFicherosSegunCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonEliminarDirectoriosVacios, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelSeleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jRadioButtonGrande)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jRadioButtonMediano)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jRadioButtonPeque)
                                                .addGap(109, 109, 109)
                                                .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addContainerGap(81, Short.MAX_VALUE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButtonEliminarFicherosTamanio, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButtonEliminarFicherosAntiguos, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButtonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 546, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonEliminarDirectoriosVacios, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonEliminarFicherosSegunCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jLabelSeleccion, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonEliminarFicherosTamanio, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonEliminarFicherosAntiguos, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jRadioButtonPeque)
                            .addComponent(jSpinnerFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addComponent(jRadioButtonMediano)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButtonGrande)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonEliminarDirectoriosVaciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarDirectoriosVaciosActionPerformed
        DefaultListModel dlm = new DefaultListModel();
        try {

            for (String u : ControladorListados.getInstance().listarDirectoriosVaciosR(seleccionUnidad)) {
                dlm.addElement(u);
                jListAborrar.setModel(dlm);
            }

            int confirmación = JOptionPane.showConfirmDialog(this, "¿Quiere "
                    + "borrar los directorios vacíos?",
                    "Confirmación", JOptionPane.YES_NO_CANCEL_OPTION);
            if (confirmación == JOptionPane.YES_OPTION) {
                try {
                    ControladorGestionUnidades.getInstance().eliminarDirectoriosVaciosR(seleccionUnidad);
                    JOptionPane.showMessageDialog(this, "Se ha borrado el registro.",
                            "Borrar.", JOptionPane.INFORMATION_MESSAGE);
                } catch (MisExcepcionesPractica.CarpetaLlena | MisExcepcionesPractica.NoTieneNada | IOException ex) {
                    System.out.println(ex.getMessage());
                }
            } else if (confirmación == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(this, "No se ha borrado el registro.",
                        "Borrar.", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (MisExcepcionesPractica.CarpetaLlena | MisExcepcionesPractica.NoTieneNada | IOException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            for (String u : ControladorListados.getInstance().listarDirectoriosVaciosR(seleccionUnidad)) {
                dlm.addElement("");
                jListAborrar.setModel(dlm);
            }
        } catch (MisExcepcionesPractica.CarpetaLlena ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MisExcepcionesPractica.NoTieneNada ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonEliminarDirectoriosVaciosActionPerformed

    public String filtrarCategoria(String opcion) {

        switch (opcion.toString()) {
            case "documentos":
                String[] extensionDocumento = {".doc", ".docx", ".txt", ".pdf"};
                extension = (String) JOptionPane.showInputDialog(null,
                        "Selecciona una extensión", "Elegir",
                        JOptionPane.QUESTION_MESSAGE, null, extensionDocumento,
                        extensionDocumento[0]);
                break;
            case "imagenes":
                String[] extensionImagen = {".jpg", ".png", ".tiff"};
                extension = (String) JOptionPane.showInputDialog(null,
                        "Selecciona una extensión", "Elegir",
                        JOptionPane.QUESTION_MESSAGE, null, extensionImagen,
                        extensionImagen[0]);
                break;
            case "videos":
                String[] extensionVideo = {".mp4", ".mov", ".avi"};
                extension = (String) JOptionPane.showInputDialog(null,
                        "Selecciona una extensión", "Elegir",
                        JOptionPane.QUESTION_MESSAGE, null, extensionVideo,
                        extensionVideo[0]);
                break;
        }
        return extension;
    }
    private void jButtonEliminarFicherosSegunCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarFicherosSegunCategoriaActionPerformed

        try {
            String[] tipoArchivo = {"documentos", "imagenes", "videos"};
            opcion = (String) JOptionPane.showInputDialog(null, "Selecciona un tipo de "
                    + "archivo", "Elegir", JOptionPane.QUESTION_MESSAGE, null,
                    tipoArchivo, tipoArchivo[0]);
            extension = filtrarCategoria(opcion);

            DefaultListModel dlm = new DefaultListModel();
            for (String u : ControladorListados.getInstance().
                    listarFicherosSegunCategoriaR(seleccionUnidad, opcion, extension)) {
                dlm.addElement(u);
                jListAborrar.setModel(dlm);
            }
            int confirmación = JOptionPane.showConfirmDialog(this,
                    "¿Quiere borrar el registro?",
                    "Confirmación", JOptionPane.YES_NO_CANCEL_OPTION);
            if (confirmación == JOptionPane.YES_OPTION) {
                try {
                    ControladorGestionUnidades.getInstance().
                            eliminarFicherosSegunCategoriaR(seleccionUnidad, opcion, extension);
                    JOptionPane.showMessageDialog(this, "Se ha borrado el registro.",
                            "Borrar.", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            } else if (confirmación == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(this, "No se ha borrado el registro.",
                        "Borrar.", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButtonEliminarFicherosSegunCategoriaActionPerformed

    private void jButtonEliminarFicherosTamanioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarFicherosTamanioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonEliminarFicherosTamanioActionPerformed

    private void jButtonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalirActionPerformed

        this.dispose();

    }//GEN-LAST:event_jButtonSalirActionPerformed

    private void jRadioButtonMedianoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMedianoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonMedianoActionPerformed

    private void jButtonEliminarFicherosTamanioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonEliminarFicherosTamanioMouseClicked
        try {
            String tamanio = "";
            if (jRadioButtonGrande.isSelected()) {
                tamanio = "grande";
            } else if (jRadioButtonMediano.isSelected()) {
                tamanio = "mediano";
            } else if (jRadioButtonPeque.isSelected()) {
                tamanio = "pequeño";
            }
            DefaultListModel dlm = new DefaultListModel();
            for (String u : ControladorListados.getInstance().
                    listarFicherosGranTamanioR(seleccionUnidad, tamanio)) {
                dlm.addElement(u);
                jListAborrar.setModel(dlm);
            }
            int confirmación = JOptionPane.showConfirmDialog(this,
                    "¿Quiere borrar el registro?",
                    "Confirmación", JOptionPane.YES_NO_CANCEL_OPTION);
            if (confirmación == JOptionPane.YES_OPTION) {
                try {
                    ControladorGestionUnidades.getInstance().
                            eliminarFicherosGranTamanioR(seleccionUnidad, tamanio);
                    JOptionPane.showMessageDialog(this, "Se ha borrado el registro.",
                            "Borrar.", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (confirmación == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(this, "No se ha borrado el registro.",
                        "Borrar.", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButtonEliminarFicherosTamanioMouseClicked

    private void jButtonEliminarFicherosAntiguosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarFicherosAntiguosActionPerformed

        try {
            Date fechaActual = (Date) (jSpinnerFecha.getValue());
            System.out.println(fechaActual);

            DefaultListModel dlm = new DefaultListModel();
            for (String u : ControladorListados.getInstance().
                    listarFicherosAntiguosR(seleccionUnidad, fechaActual)) {
                dlm.addElement(u);
                jListAborrar.setModel(dlm);
            }
            int confirmación = JOptionPane.showConfirmDialog(this,
                    "¿Quiere borrar el registro?",
                    "Confirmación", JOptionPane.YES_NO_CANCEL_OPTION);
            if (confirmación == JOptionPane.YES_OPTION) {

                try {
                    ControladorGestionUnidades.getInstance().
                            eliminarFicherosAntiguosR(seleccionUnidad, fechaActual);
                    JOptionPane.showMessageDialog(this, "Se ha borrado el registro.",
                            "Borrar.", JOptionPane.INFORMATION_MESSAGE);
                } catch (ParseException ex) {
                    Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else if (confirmación == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(this, "No se ha borrado el registro.",
                        "Borrar.", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (ParseException ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Acciones.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButtonEliminarFicherosAntiguosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupTamanio;
    private javax.swing.JButton jButtonEliminarDirectoriosVacios;
    private javax.swing.JButton jButtonEliminarFicherosAntiguos;
    private javax.swing.JButton jButtonEliminarFicherosSegunCategoria;
    private javax.swing.JButton jButtonEliminarFicherosTamanio;
    private javax.swing.JButton jButtonSalir;
    private javax.swing.JLabel jLabelSeleccion;
    private javax.swing.JList<String> jListAborrar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButtonGrande;
    private javax.swing.JRadioButton jRadioButtonMediano;
    private javax.swing.JRadioButton jRadioButtonPeque;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinnerFecha;
    // End of variables declaration//GEN-END:variables
}
