
import entity.Cliente;
import entity.Cuenta;
import entity.ExcepcionesBanco;



/**
 *
 * @author Shaila
 */
public interface ClienteDAO {

    /**
     * Los traspasos deben de ser entre cuentas del mismo cliente.
     *
     * @param cuentaOrigen
     * @param cuentaDestino
     * @param cantidad
     * @throws entity.ExcepcionesBanco.ErrorExcepcion
     */
    public boolean traspaso(Cliente clienteCuentaOrigen, Cliente clienteCuentaDestino, int cantidad) throws ExcepcionesBanco.ErrorExcepcion;
/**
 * Las trasnferencias deben de ser entre cuentas del distinto cliente.
 * @param cuentaOrigen
 * @param cuentaDestino
 * @param cantidad
 * @throws entity.ExcepcionesBanco.ErrorExcepcion 
 */
    public boolean trasnferencia(Cliente clienteCuentaOrigen, Cliente cliente2CuentaDestino, int cantidad) throws ExcepcionesBanco.ErrorExcepcion;
/**
 * 
 * @param id
 * @param numeroCuenta
 * @param saldo
 * @param divisa
 * @return
 * @throws entity.ExcepcionesBanco.ErrorExcepcion 
 */
    public Cuenta crearCuenta(String numeroCuenta, int saldo, String divisa, Cliente cliente) throws ExcepcionesBanco.ErrorExcepcion;
}
