package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Shaila
 */
@Entity
@Table(name = "movimiento")
public class Movimiento implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Para que autogenere el id
    private long idMovimiento;
    private int cantidad;
    private String concepto;
    private Date fecha;

    /**
     * En movimiento no haríamos nada más.
     */
    public Movimiento() {
    }

    /**
     * Quitamos el id del constructor para que lo genere automaticamente y
     * ponemos valor autogenerado
     *
     * @param cantidad
     * @param concepto
     * @param fecha
     */
    public Movimiento(int cantidad, String concepto, Date fecha) {
        this.cantidad = cantidad;
        this.concepto = concepto;
        this.fecha = fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public long getIdMovimiento() {
        return idMovimiento;
    }

    public void setIdMovimiento(long idMovimiento) {
        this.idMovimiento = idMovimiento;
    }

}
