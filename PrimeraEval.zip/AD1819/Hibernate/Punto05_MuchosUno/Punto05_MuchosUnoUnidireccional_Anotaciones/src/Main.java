
import entidades.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {

    private static Session openSession;

    public static void main(String[] args) {

        SessionFactory sessionFactory = HibernateSesion.getSessionFactory();
        openSession = sessionFactory.openSession();

        crearDatos();

        openSession.close();
        HibernateSesion.cerrarSesion();
    }

    private static void crearDatos() {
        Transaction tx = null;
        try {
            tx = openSession.beginTransaction();
            CadenaTelevisiva cadenaTelevisiva = new CadenaTelevisiva("Canal Sotrondio");
            Televidente televidente01 = new Televidente("Ana", cadenaTelevisiva);
            Televidente televidente02 = new Televidente("Roberto", cadenaTelevisiva);
            Televidente televidente03 = new Televidente("María", cadenaTelevisiva);
            openSession.save(cadenaTelevisiva);
            openSession.save(televidente01);
            openSession.save(televidente02);
            openSession.save(televidente03);
            tx.commit();
            System.out.println("Datos guardados");
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        }
    }

}
