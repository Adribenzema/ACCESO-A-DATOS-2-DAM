package modelo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;

/**
 *
 * @author Shaila
 */
public class JsonMetodos {

    /**
     * Método para crear un archivo json con los autores y los títulos de los
     * libros.
     *
     * @param rutaFichero nombre del fichero donde se va a crear el json.
     * @throws IOException
     */
    public static void crearFichero(String rutaFichero) throws IOException {

        JsonObject libro1 = Json.createObjectBuilder()
                .add("titulo", "Tralara")
                .add("totalPaginas", 520)
                .add("precio", 100)
                .add("autores", Json.createArrayBuilder()//creamos el corchete
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Andres")
                                .add("apellido", "Fernandez")
                        )//},  
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Luisa")
                                .add("apellido", "Perez")
                        )//}, 
                )//],
                .add("generos", Json.createArrayBuilder()//generos:[
                        .add(Json.createObjectBuilder()//creamos{
                                .add("generos", "drama")
                        )//},
                        .add(Json.createObjectBuilder()
                                .add("genero", "romantico")
                        )//},

                )//]
                .build();//para cerrarlo:  }]

        JsonObject libro2 = Json.createObjectBuilder()
                .add("titulo", "Tralara")
                .add("totalPaginas", 520)
                .add("precio", 100)
                .add("autores", Json.createArrayBuilder()//creamos el corchete
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Andres")
                                .add("apellido", "Fernandez")
                        )//},  
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Luisa")
                                .add("apellido", "Perez")
                        )//}, 
                )//],
                .add("generos", Json.createArrayBuilder()//generos:[
                        .add(Json.createObjectBuilder()//creamos{
                                .add("generos", "drama")
                        )//},
                        .add(Json.createObjectBuilder()
                                .add("genero", "romantico")
                        )//},

                )//]
                .build();//para cerrarlo:  }]

        JsonObject libro3 = Json.createObjectBuilder()
                .add("titulo", "Tralara")
                .add("totalPaginas", 520)
                .add("precio", 100)
                .add("autores", Json.createArrayBuilder()//creamos el corchete
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Andres")
                                .add("apellido", "Fernandez")
                        )//},  
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Luisa")
                                .add("apellido", "Perez")
                        )//}, 
                )//],
                .add("generos", Json.createArrayBuilder()//generos:[
                        .add(Json.createObjectBuilder()//creamos{
                                .add("generos", "drama")
                        )//},
                        .add(Json.createObjectBuilder()
                                .add("genero", "romantico")
                        )//},

                )//]
                .build();//para cerrarlo:  }]

        JsonObject libro4 = Json.createObjectBuilder()
                .add("titulo", "Tralara")
                .add("totalPaginas", 520)
                .add("precio", 100)
                .add("autores", Json.createArrayBuilder()//creamos el corchete
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Andres")
                                .add("apellido", "Fernandez")
                        )//},  
                        .add(Json.createObjectBuilder()
                                .add("nombre", "Luisa")
                                .add("apellido", "Perez")
                        )//}, 
                )//],
                .add("generos", Json.createArrayBuilder()//generos:[
                        .add(Json.createObjectBuilder()//creamos{
                                .add("generos", "drama")
                        )//},
                        .add(Json.createObjectBuilder()
                                .add("genero", "romantico")
                        )//},

                )//]
                .build();//para cerrarlo:  }]
        //crea Array
        JsonArray arrayJsonLibros = Json.createArrayBuilder().add(libro1)
                .add(libro2).add(libro3).add(libro4)
                .build();

        // Escribe el fichero Json
        FileWriter ficheroSalida = new FileWriter(rutaFichero);
        JsonWriter jsonWriter = Json.createWriter(ficheroSalida);
        jsonWriter.writeArray(arrayJsonLibros);
        ficheroSalida.flush();
        ficheroSalida.close();

    }

    /**
     * Método interno para leer ficheros JSON.
     *
     * @param rutaFichero
     * @return
     * @throws FileNotFoundException
     */
    private static JsonArray leerFicheroJSON(String rutaFichero) throws FileNotFoundException {
        FileReader entrada = new FileReader(rutaFichero);//Creamos un file reader para leer el archivo
        JsonReader jsonReader = Json.createReader(entrada);
        JsonArray arrayJSON = jsonReader.readArray();
        return arrayJSON;
    }

    /**
     * Método para contar el número de libros de los autores. Primero tenemos
     * que crear un método que nos lea el fichero Json.
     *
     * @param rutaFichero
     * @return entero con el número de libros.
     */
    public static int contarLibrosDeAutores(String rutaFichero) throws FileNotFoundException {

        JsonArray leerFicheroJSON = leerFicheroJSON(rutaFichero);
        return leerFicheroJSON.size();

    }

    /**
     * Método para mostros los autores de todos los libros.
     *
     * @param rutaFichero
     * @return
     * @throws FileNotFoundException
     */
    public static List<String> mostrarTodosLibrosAutores(String rutaFichero) throws FileNotFoundException {
        List<String> listaTitulos = new ArrayList<String>();
        JsonArray leerFicheroJSON = leerFicheroJSON(rutaFichero);

        for (int i = 0; i < leerFicheroJSON.size(); i++) {

            JsonObject jsonObject = leerFicheroJSON.getJsonObject(i);
            listaTitulos.add(jsonObject.getString("titulo"));

        }
        return listaTitulos;
    }

    /**
     * Método para mostro un autor determinado.
     *
     * @param rutaFichero
     * @param autor
     * @param libro
     * @return
     * @throws FileNotFoundException
     */
    public static String mostrarAutor(String rutaFichero, int autor, int libro) throws FileNotFoundException {
        JsonArray leerFicheroJSON = leerFicheroJSON(rutaFichero);

        JsonObject jsonObject = leerFicheroJSON.getJsonObject(autor);
        return jsonObject.getJsonArray("autores").getJsonObject(libro).getString("nombre");

    }

    /**
     * Método para calcular los valores de los libros que hay en stock.
     *
     * @param rutaFichero
     * @return
     * @throws FileNotFoundException
     */
    public static int calculoDelValorDeLosLibrosEnStock(String rutaFichero) throws FileNotFoundException {
        JsonArray leerFicheroJSON = leerFicheroJSON(rutaFichero);
        
        int precio = 0;
        for (int i = 0; i < leerFicheroJSON.size(); i++) {
            JsonObject jsonObject = leerFicheroJSON.getJsonObject(i);
            precio += jsonObject.getInt("precio");
        }

        return precio;

    }
}
