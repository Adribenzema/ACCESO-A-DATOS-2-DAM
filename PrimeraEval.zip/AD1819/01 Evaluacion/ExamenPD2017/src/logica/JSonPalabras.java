package logica;

import javax.json.JsonObject;
import modelo.JsonMetodos;


/**
 *
 * @author Shaila
 */
public class JSonPalabras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String rutaFichero = "diccionario2.json";
        /*        MetodosPalabras gajxb = new MetodosPalabras("jaxb.diccionario2Binding");
        JAXBElement unMarshall = gajxb.unMarshall(new File("diccionario2.xml"));
        
        DiccionarioEspanol diccionarioEspanol = (DiccionarioEspanol) unMarshall.getValue();
        
        List<PalabraType> palabra = diccionarioEspanol.getPalabras().getPalabra();*/
        //JSON
        JsonObject jsonObject = JsonMetodos.leerJson(rutaFichero);
        /**
         * Contar el total de sinónimos y el total de antónimos que contienen
         * una determinada palabra.
         */
        System.out.println("Contar Total Sinonimos y Antonimos " + JsonMetodos.
                contarTotalSinonimosYAntonimos(jsonObject, "String"));
        /**
         * Generar un Map donde K es la grafía de la palabra y V es el total de
         * sinónimos con porcentaje de similitud superior a 80%.
         */
        System.out.println("Map " + JsonMetodos.generarGrafia(jsonObject));
        
        /**
         * Generar un JSON con la grafía de las palabras añadidas hace menos de
         * 3 días.
         * Me falta por entender esta parte.
         */
        /*List<JsonObject> listapalabras = new ArrayList();
        JsonMetodos.crearFichero("Prueba.json", JsonMetodos.crearArrayPalabras(listapalabras));*/
        JsonMetodos.generarJson3D(jsonObject, "Prueba.json");

    }
}
