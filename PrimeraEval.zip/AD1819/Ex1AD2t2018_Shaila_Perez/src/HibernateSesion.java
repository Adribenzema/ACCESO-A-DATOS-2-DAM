
import entity.*;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Shaila
 */
public class HibernateSesion {

    private static StandardServiceRegistry serviceRegistry;
    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {

        if (sessionFactory != null) {
            return sessionFactory;
        } else {
            try {
                Configuration configuration = new Configuration();
                configuration
                        .addAnnotatedClass(Cliente.class)
                        .addAnnotatedClass(Sucursal.class)
                        .addAnnotatedClass(Cuenta.class)
                        .addAnnotatedClass(Direccion.class)
                        .addAnnotatedClass(Movimiento.class)
                        .configure("hibernate.cfg.xml");
                StandardServiceRegistryBuilder serviceBuilder = new StandardServiceRegistryBuilder();
                serviceRegistry = serviceBuilder.applySettings(configuration.getProperties()).build();
                sessionFactory = configuration.buildSessionFactory(serviceRegistry);
            } catch (HibernateException he) {
                he.printStackTrace();
            } finally {
                return sessionFactory;
            }
        }

    }

    public static void cerrarSesion() {
        if (sessionFactory != null && serviceRegistry != null) {
            sessionFactory.close();
            StandardServiceRegistryBuilder.destroy(serviceRegistry);
        }
    }

}
