package modelo;

/**
 *
 * @author Shaila
 */
public class MisExcepcionesPractica {

    public static class NoTieneNada extends Exception {

        public NoTieneNada() {

        }

        public NoTieneNada(String msg) {
            super(msg);
        }
    }

    public static class NoEsFile extends Exception {

        public NoEsFile() {

        }

        public NoEsFile(String msg) {
            super(msg);
        }
    }

    public static class ExisteRuta extends Exception {

        public ExisteRuta() {

        }

        public ExisteRuta(String msg) {
            super(msg);
        }
    }

    public static class NoExisteRuta extends Exception {

        public NoExisteRuta() {

        }

        public NoExisteRuta(String msg) {
            super(msg);
        }
    }

    public static class YaExisteDirectorio extends Exception {

        public YaExisteDirectorio() {

        }

        public YaExisteDirectorio(String msg) {
            super(msg);
        }
    }

    public static class NoEsUnDirectorioNoSePuedeListar extends Exception {

        public NoEsUnDirectorioNoSePuedeListar() {

        }

        public NoEsUnDirectorioNoSePuedeListar(String msg) {
            super(msg);
        }
    }

    public static class CarpetaLlena extends Exception {

        public CarpetaLlena() {
        }

        public CarpetaLlena(String string) {
            super(string);
        }

    }
}
