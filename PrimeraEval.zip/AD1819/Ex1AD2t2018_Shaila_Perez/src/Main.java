
import entity.Cliente;
import entity.ExcepcionesBanco;
import entity.Sucursal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Shaila
 */
public class Main {

    private static ClienteDAOImplementacion cdao;
    private static List<Cliente> clientes = new ArrayList();
    private static List<Long> ids = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExcepcionesBanco.ErrorExcepcion {
        cdao = new ClienteDAOImplementacion();

        crearUsuarios();

    }

    private static void crearUsuarios() throws ExcepcionesBanco.ErrorExcepcion {
        Sucursal sucursal = new Sucursal();
        clientes = (Arrays.asList(
                new Cliente("76953668s", "Ana", "Perez", sucursal),
                new Cliente("76953661s", "Pepe", "Martinez", sucursal),
                new Cliente("76953662s", "Lucas", "Fernandez", sucursal),
                new Cliente("76953663s", "Susana", "Castelao", sucursal)
        ));
        for (Cliente cliente : clientes) {
            cdao.crearContacto(cliente);
        }

    }


}
