package logica;

import java.io.File;
import javax.xml.bind.JAXBElement;
import jaxb.bibliotecaBinding.Biblioteca;
import jaxb.bibliotecaBinding.PrestamoType;
import modelo.ExcepcionesBiblioteca;
import modelo.MetodosBiblioteca;

/**
 *
 * @author Shaila
 */
public class JXmlBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExcepcionesBiblioteca.UnmarshalExcepcion, ExcepcionesBiblioteca.FechaIncorrectaException, ExcepcionesBiblioteca.MarshalExcepcion, ExcepcionesBiblioteca.NoExisteSocioExcepcion {
        MetodosBiblioteca metodosBiblioteca = new MetodosBiblioteca("jaxb.bibliotecaBinding");
        File documentoXML = new File("BIBLIOTECA.xml");
        JAXBElement jaxbElement = metodosBiblioteca.unMarshall(documentoXML);//metodo unmarshalizador

        Biblioteca biblioteca = (Biblioteca) jaxbElement.getValue();//castear al tipo del nodo "raíz"
        //OPERACIONES
        PrestamoType nuevoPrestamo = metodosBiblioteca.crearPrestamoType("ISBN", "titulo", "codigoSocio", "nombreSocio", "apellidoSocio", 11, 12, 2018);
        metodosBiblioteca.insertarPrestamosEnBiblioteca(nuevoPrestamo);
       
        metodosBiblioteca.darDeBajaUnSocioEnBiblioteca(biblioteca, "Prueba");

        System.out.println("Map " + metodosBiblioteca.generarMapCodigoSocioConListaLibrosPrestados(biblioteca));
        metodosBiblioteca.retrasosSocios(biblioteca, 11, 12, 2018);
        //MARSHALIZAR
        File ficheroSalida = new File("miXMLmodificado.xml");//xml de salida nuevo modificado
        metodosBiblioteca.marshall(jaxbElement, ficheroSalida);//metodo marshalizador

    }

}
