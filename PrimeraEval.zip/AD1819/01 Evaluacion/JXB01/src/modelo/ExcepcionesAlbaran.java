package modelo;

/**
 *
 * @author Shaila
 */
public class ExcepcionesAlbaran {

    public static class NoExisteElProducto extends Exception {

        public NoExisteElProducto() {

        }

        public NoExisteElProducto(String msg) {
            super(msg);
        }
    }

    public static class ErrorFecha extends Exception {

        public ErrorFecha() {

        }

        public ErrorFecha(String msg) {
            super(msg);
        }
    }
}
